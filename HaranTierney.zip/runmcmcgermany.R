exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R")
germany.data <- readSimpleData(paste(exactdir,"/germany",sep=""))
germany.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
germany.proppars <- list(multtdf=50,muh=5,sigmah=0.45,muc=2.9,sigmac=0.2,tdfh=50,tdfc=50)
germany.logbound <- -14583.24
germany.mixprob <- list(logpi0=log(1),logpi1=-germany.logbound)
germany.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

############################################################################################################
## run block MCMC
############################################################################################################
set.seed(1)
#germany.mixprob <- list(logpi0=log(1),logpi1=-rej$newlogbound) # in case log bound has changed
mcmcrun=blockMCMC(NUMSAMP=50000,proppars=germany.proppars,coord=c(1,2,9,96,17,104,58,145),data=germany.data,prior=germany.prior,outfile="germanymcmcout",writeevery=1)
write(mcmcrun$accrate,"germanymcmcacc")
