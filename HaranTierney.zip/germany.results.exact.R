exactdir <- "/home/mharan/exact/"
source("../multreg/mcse.R")
germany.data <- readSimpleData(paste(exactdir,"germany",sep=""))
germany.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
germany.proppars <- list(multtdf=50,muh=5,sigmah=0.45,muc=2.9,sigmac=0.2,tdfh=50,tdfc=50)
germany.logbound <- -14583.24
germany.mixprob <- list(logpi0=log(1),logpi1=-germany.logbound)

#rej.time <- system.time(rej <- rejsamp(10,germany.proppars,coord=c(1,2,9,96,17,104,58,145),germany.data,germany.prior,logbound=germany.logbound,changebound=TRUE))

## run until 100 samples returned
rej.time <- system.time(rej <- rejsamp(100,germany.proppars,coord=c(1,2,9,96,17,104,58,145),germany.data,germany.prior,logbound=germany.logbound,changebound=FALSE,FIXEDNUM=TRUE))
dput(rej,"germany.rej")
dput(rej.time,"germany.rej.time")

germany.temp.par <- list(p=0.5,q=0.5,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(100,germany.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),germany.data,germany.prior,germany.temp.par,germany.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"germany.perf1")
dput(perf.time,"germany.perf1.time")

germany.temp.par <- list(p=0.6,q=0.4,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(100,germany.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),germany.data,germany.prior,germany.temp.par,germany.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"germany.perf2")
dput(perf.time,"germany.per2.time")

germany.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(100,germany.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),germany.data,germany.prior,germany.temp.par,germany.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"germany.perf3")
dput(perf.time,"germany.perf3.time")

germany.temp.par <- list(p=0.2,q=0.8,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(100,germany.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),germany.data,germany.prior,germany.temp.par,germany.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"germany.perf5")
dput(perf.time,"germany.perf5.time")
#> perf$acc
#[1] 0.04659832
germany.temp.par <- list(p=0.9,q=0.1,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(100,germany.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),germany.data,germany.prior,germany.temp.par,germany.mixprob,FIXEDNUM=TRUE))
dput(perf,"germany.perf6")
dput(perf.time,"germany.perf6.time")

germany.temp.par <- list(p=0.8,q=0.2,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(100,germany.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),germany.data,germany.prior,germany.temp.par,germany.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"germany.perf4")
dput(perf.time,"germany.perf4.time")

