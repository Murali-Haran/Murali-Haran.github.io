## WORK THROUGH TOY EXAMPLE IN DETAIL
## estimating normalizing constant
## file:
source("normconst.R")
data <- readSimpleData("three")
prior <- list(alphah=1,betah=100,alphac=1, betac=50)
NUMSAMP <- 100
proppars <- list(multtdf=50,muh=4.65,sigmah=1,muc=4.15,sigmac=1.1,tdfh=50,tdfc=50)
#temp.par <- list(p=1/3,q=1/3,nstar=1)  # for simulated tempering/perfect sampling
temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

data <- readSimpleData("breastcancer")
prior <- list(alphah=1,betah=100,alphac=1, betac=50)
NUMSAMP <- 100
proppars <- list(multtdf=50,muh=-4.83,sigmah=0.2,muc=-5.17,sigmac=0.25,tdfh=50,tdfc=50)
#temp.par <- list(p=1/3,q=1/3,nstar=1)  # for simulated tempering/perfect sampling
temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

## estimate bounding constant for ratio log(P/R)
logK <- findbound(2000,proppars,data,prior)
-107.950 # three data

## estimate normalizing constant for P
const <- findnorm(10000,proppars,data,prior)
> const$est
[1] 3.645295e-48
> log(3.645295e-48)
[1] -109.2339 # three data
constMW <- findnormMW(10000,proppars,data,prior)
> constMW$logest
[1] -109.1548 # three data

## breastcancer data
system.time(const <- findnorm(10000,proppars,data,prior,3573.883))
> const$logest
[1] -3166.159
> system.time(const <- findnormMW(10000,proppars,data,prior,3573.883))
> const$logest
[1] -3194.134
logK <- findbound(2000,proppars,data,prior)
> logK
          [,1]
[1,] -3164.930
> exp(-3166.159+3164.93)
[1] 0.292585  ## seems too high (nearly 30% acceptance rates)
> exp(-3194.134+3164.93)
[1] 2.074264e-13 ## seems way too low

## block independence chain acceptance rates

## based on above estimates, acceptance rate should be normconst/boundingconst, exp(log(normconst)-log(bound))
exp(-109.2306+107.950)
[1] 0.2778705
## repeatedly running rejection sampler and adjusting constant gives
exp(-109.2306+106.593)
[1] 0.07153274
## run rejection sampler and see if acc. rate is comparable
## Somewhat close though above calculation overestimates it (7.1 versus 5.5)
rej <- rejsamp(10000,proppars,data,prior,-106.593)
> rej$acc
[1] 0.0552
> rej$notin
[1] 0
> postmode
$par
[1] 96.693509108 23.514158982 -0.022686267  0.028492669  0.004886184
[6]  0.074936326 -0.065168195 -0.101237238
 
$val
          [,1]
[1,] -111.5842
> blah <- optim(postmode$par,neglogP.eval)
> blah
$par
[1] 114.181385365  44.606817223   0.001802059   0.006298736  -0.023001585
[6]   0.026524295   0.010584034  -0.026027548
 
$value
[1] 111.0021

> findpostmode(boo$samp,data,prior)
$par
[1] 153.846469749  56.061274337   0.030857630  -0.015254251  -0.019416152
[6]   0.002715980   0.043921236   0.002788670
 
$val
          [,1]
[1,] -111.1695
 
> findpostmeansd(boo$samp,data,prior)
$mean
[1] 126.51468280  62.30254048   0.00870280   0.01316218  -0.02848611
[6]   0.01000147  -0.00714553  -0.04582161
 
$sd
[1] 108.8154804  53.0515419   0.1116019   0.1145933   0.1244002   0.1464813
[7]   0.1484315   0.1791946

## NOTE: as logC, we use -108.5140 (obtained empirically), but this is similar to ratio,i.e., log(P/R)
blk <- blockMCMC(100,proppars,data,prior,-108.5140)
> findpostmode(blk$samp,data,prior)
$par
[1] 74.14303135 54.61043175  0.05325790  0.02979048  0.09076731 -0.09807055
[7] -0.04324137 -0.02212307
> logP.rej(boo$par,data,prior)
          [,1]
[1,] -112.4024
$mean
[1] 114.685647965  69.415731895   0.017655920   0.085381430   0.014569519
[6]   0.003574112  -0.026289723  -0.036743138
 
$sd
[1] 77.9513939 66.2684263  0.1043275  0.1010387  0.1034054  0.1332162  0.1110089
[8]  0.1630892
> logP.rej(boo$mean,data,prior)
          [,1]
[1,] -111.5352

## CONCLUSION: finding the mode for even this 8 dimensional distribution is tricky!
## MC estimate gives (log) max=-111.5842, optimizer gives (log) max=-111.0021
## if optimizer started at a different place, say
[1]  1.0000000  1.0000000  0.4874291  0.7383247  0.5757814 -0.3053884  1.5117812
[8]  0.3898432
# then, it lands at -118.0640
$par
[1]  1.36179972  3.85054135 -0.01055147  0.09649706 -0.04779983  0.07300866
[7] -0.03776279 -0.08387084
 
$value
[1] 118.0640

> sim <- simtemp(NUMREG=100,proppars,logK,data,prior,temp.par,coord=FALSE)

> findpostmode(blk$samp,data,prior)
$par
[1] 143.54777458  41.05404712   0.01510503   0.03454977   0.05034261
[6]  -0.03894648  -0.01970516  -0.14718080
 
$val
          [,1]
[1,] -111.5625




## estimate same number by integrating (since problem is simple)
boo <- adapt(8,c(0,0,rep(-10,6)), c(10,10,rep(10,6)),functn=P.eval)
       value       relerr       minpts       lenwrk        ifail
9.644593e-51  0.009997308     18073311       622601            0
> 1/9.644593e-51
[1] 1.036850e+50

boo <- adapt(8,c(0,0,rep(-100,6)), c(100,100,rep(100,6)),functn=P.eval)
boo
        value        relerr        minpts        lenwrk         ifail
6.336208e-137             0          6055           161             0

=> 1.578231e+136, NOT THE SAME AS 3.330533e-48
set.seed(1)
startval <- c(1,1,rnorm(6))
blah <- optim(startval,neglogP.eval)
$par
[1]  2.02280672  2.63682397 -0.12310227 -0.10410537 -0.15592979  0.13597842
[7]  0.14259785  0.03529993
$value
[1] 117.8589

So, maximized logP value is -117.8589, so maximized P is 6.524242e-52.
 
## checking normalizing constants
dltfun <- function(tauc) return(exp(logdlt.nor(tauc,meanlog=muc,sdlog=sigmac,t.df=50)))
> boo <- integrate(dltfun,0,100000)
> boo
1 with absolute error < 6e-05

#logR.fast(blah$par,multt.df,muh,sigmah,t.df1,muc,sigmac,t.df2,setup=create.setup(data))
#logR.slow(blah$par,multt.df,muh,sigmah,t.df1,muc,sigmac,t.df2,setup=create.setup(data))
mysetup <- create.setup(data)
logR.fast(blah$par,multt.df,muh,sigmah,t.df1,muc,sigmac,t.df2,setup=mysetup)

bar <- adapt(8,c(0,0,rep(-100,6)), c(100,100,rep(100,6)),functn=R.eval)
qux <- optim(startval,neglogR.eval)
$par
[1]  2.633465e+00  2.125033e+02  1.396072e-02 -4.236187e-04 -2.108775e-02
[6]  3.880246e+01  7.549021e+01 -1.254539e+02
 
$value
[1] 8.49403

neglogratio.eval <- function(x)
  {
    val <- -1*(logP.eval(x)-logR.eval(x))
    cat(val," ")
    return(val)
  }
bestK <- optim(startval,neglogratio.eval)
$value
[1] 14.42090
 
normconst.R(mysetup$N,multt.df,muh,sigmah,t.df1,muc,sigmac,t.df2)


### to see how a normalizing constant behaves as a function
## eg. N(0,sigmasq)
gaussian.normconst <- function(sigma)
  return(1/(sqrt(2*pi)*sigma))

xs <- seq(0.1,10,by=0.01)
ys <- sapply(xs,gaussian.normconst)
plot(xs,ys)
## NOTE: normalizing constants can be treated as functions of random variables
## if the parameters that go into the normalizing constants are random variables
## (often the case in Bayesian models)
