N=100000
set.seed(1)
mcmc.time=system.time((mcmcout=blockMCMC(NUMSAMP=N,proppars=infant.proppars,coord=c(1,2,9,96,17,104,58,145),data=infant.data,prior=infant.prior,outfile="mcmcout.infant",writeevery=1)))
