# COFIPS: geographic identification  
# TOTAPOP: total population
# TOTBIR: total number of births  
# TOTAL_DEAT: total number of infant deaths   
# Actual: actual infant mortality rates (deaths per 1000 births) 
# Expected: expected infant mortality rates (as above)
# X_COORD: x coordinate   
# Y_COORD: y coordinate

## infant mortality data: 454 dimensions
infant.dat = read.table("infantdata.txt",header=TRUE,sep="\t")
infant.data.R = cbind(infant.dat$TOTAL_DEAT,infant.dat$Expected)
infant.data.R = infant.data.R[-c(455),] # delete last row
## replace 0's with 0.5's
infant.data.R[infant.data.R[,1]==0,]=0.5

infant.matrix=read.table("infantmatrix.txt")
## matrix is symmetric (checked using /extra/mharan/MNexact/is.symmetric.R: is.symmetric(infant.matrix))
## diagonal needs to contain number of neighbors for each region
for (i in 1:nrow(infant.matrix))
  {
    adj=(infant.matrix[i,]==1) # adjacencies have been coded as 1's
    infant.matrix[i,adj]=-1 # recode to -1s
    cat("num =",sum(adj),"\n")
    infant.matrix[i,i]=sum(adj) # set diagonal to number of neighbors
  }

infant.matrix=as.matrix(infant.matrix) # (also checked if matrix is valid Q matrix: is.Q(infant.matrix))

## write data 
write.table(infant.data.R, file = "infant.data.R", sep = " ",row.names=FALSE,col.names=FALSE)
## write Q matrix
write.table(infant.matrix, file = "infant.Q", sep = " ",row.names=FALSE,col.names=FALSE)

