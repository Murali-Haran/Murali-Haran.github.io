if (!exists("exactdir"))
  exactdir <- "/home/mharan/exact" # location of directory with functions for exact sampling
source(paste(exactdir,"/newmodel2.functions.R",sep=""))
source(paste(exactdir,"/band.chol.R",sep="")) # for band choleski
## this version of perfect tempering for Model 1
## uses only the distributions H0 (on atom) and H1 (target)
#toytemp.par <- list(p=1/3,q=1/3,nstar=1) # nstar=1 since only 2 distributions are used
# corrected version (Apr.6, 2003)
logalphatwiddle <- function(n,nprime,temp.par)
  {
    logval <- -9999

    p <- temp.par$p
    q <- temp.par$q
    
#    if ((n==nprime) || ((n==0) && (nprime==1)) ||  ((n==1) && (nprime==0)))
    if (((n==0) && (nprime==0)) || ((n==1) && (nprime==1)))
      logval <- 0

    if ((n==0) && (nprime==1))
      logval <- log(temp.par$q)-log(temp.par$p)

    if ((n==1) && (nprime==0))
      logval <- log(temp.par$p)-log(temp.par$q)

    if (logval==-9999)
      {
        cat("logalphatwiddle: error - invalid input\n")
        break;
      }
    else
      return(logval)
  }

# when in current state (x,n)
# obtain new state (xprime,nprime) using u1,u2 ~ Unif(0,1)
# input: (x,n,u1,u2),
# mu.prev (previous mean), cholinv.prev: choleski of proposal precision matrix at previous iteration,
# IMPORTANT: both mu.prev, cholinv.prev are permuted (for minimized bandwidth)
# multtdf,muh,sigmah,tdfh,muc,sigmac,tdfc (proposal parameters),
# data, prior (for logP.rej)
# setup=matrices, vectors that will be used/reused in the algorithm (unchanged throughout)

# output: (xprime, nprime) (new state),
# mu.prev (mean at this iteration), cholinv.prev: choleski of proposal precision matrix at this iteration
# IMPORTANT: both mu.prev, cholinv.prev are permuted (for minimized bandwidth)
# numh0, numh1 : number of proposals from h0, h1 respectively
STupdate <- function(x.prev,n,u1,u2,logP.prev,logQ.prev,proppars,logK,data,prior,temp.par,setup)
  {
    numh0 <- 0# number of proposals from h0
    numh1 <- 0 # number of proposals from h1
    numacc <- 0 # number of times a proposal was accepted
    
# equivalent to previous method of sampling, but easier to follow
    if (n==0)
      {
        if (u1 < (1-temp.par$p))
          nprime <- 0
        else
          nprime <- 1
      }
    if (n==1)
      {
#        if (u1 < (1-temp.par$p)) #edited out Apr.6,2003
        if (u1 < (1-temp.par$q))
          nprime <- 1
        else
          nprime <- 0
      }

    # given the proposal for tempering level, propose value (X_t) at new tempering level
    # and decide whether to accept this joint proposal
    N <- setup$N
    # sampling (xprime,nprime)
    if (nprime==0)
      {
        # sample from atom
        zero.samp <- c(rep(0,(2*N+2)), 0)
        if (n==0)
          return(list(samp=zero.samp,logP.prev=NA,logQ.prev=NA,numh0=1,numh1=0,numacc=1)) # return with prob. 1
        else # if n==1
          {
            # alpha=(Q/K*P)*(p/q)
            logalpha <- logQ.prev - logP.prev +logK + log(temp.par$p)-log(temp.par$q)
            if (u2<logalpha)
              return(list(samp=zero.samp,logP.prev=NA,logQ.prev=NA,numh0=1,numh1=0,numacc=1))#move to 0
            else
              return(list(samp=c(x.prev,n),logP.prev=logP.prev,logQ.prev=logQ.prev,numh0=1,numh1=0,numacc=1))#stay at 1
          }
      }

    if (nprime==1)
      {
        prop <- seqsamp(proppars,setup)
        # get matrices etc. with everything already permuted
        samp <- prop$samp 
        logP.val <- logP.rej(samp,data,prior) # done with unpermuted version of sample, data
        logQ.val <- prop$logR.val 
        
         # alpha((x,n),(xprime,nprime))=(P/K*Q)*q/p
        logalpha <- logP.val-logQ.val-logK+log(temp.par$q)-log(temp.par$p)

        if (n==0) # if previous state was the atom
          {
            if (log(u2)<= logalpha) # accept sample from h1
              return(list(samp=c(samp,1),logP.prev=logP.val,logQ.prev=logQ.val,numh0=0,numh1=1,numacc=1))
            else # stay at atom
              return(list(samp=c(rep(0,2*N+2),0),logP.prev=NA,logQ.prev=NA,numh0=0,numh1=1,numacc=0))
          }

        if (n==1) # if previous state was at same temperature (1)
          {
            # need to use calculations about previous sample
            logalpha <- logP.val-logQ.val + logQ.prev - logP.prev
            if (log(u2)<= logalpha)
              return(list(samp=c(samp,1),logP.prev=logP.val,logQ.prev=logQ.val,numh0=0,numh1=1,numacc=1))
            else
              return(list(samp=c(x.prev,1),logP.prev=logP.prev,logQ.prev=logQ.prev,numh0=0,numh1=1,numacc=0))
          }            
      }
  }

# u1 is unif. r.v. that determines the proposal (whether to move up, down or stay at same level)
# u2 is unif. r.v. that determines acceptance of proposal
RWupdate <- function(m,u1,u2,temp.par)
  {
    d <- m
    if (u1 < temp.par$p)
      mprime <- m + 1
    else
      if (u1 > (1-temp.par$q))
        mprime <- m - 1
    else
      mprime <- m

    if ((0<=mprime) && (mprime <= temp.par$nstar))
      {
        logval <- logalphatwiddle(m, mprime)
        if (log(u2) < logval)
          d <- mprime
      }

    return(d)
  }

# to get function rt.mod for sampling from t-distribution
# phase 1: to determine taustar (hitting time for Dt process)
# result of this phase :
# (i) get taustar. Z_t is then run from -taustar to 0 (i.e., Z[1] to Z[taustar+1])
# Z[taustar+1] is then Z_0.
# Run Z_0 to Z_S (S arbitrary)
# All Z_i's between Z_1 and Z_S (Z[taustar+2] to Z[taustar+1+S])
# s.t. N[i]==nstar, are the samples of interest
# (ii) keep uniforms, U1_(-taustar) to U1_S, and U2_(-taustar) to U2_S.

phase1 <- function(T=1,data,temp.par)
  {
    N <- nrow(data$data)
    
# begin initialization
    nstar <- temp.par$nstar
    t <- T
    D <- temp.par$nstar
    a <- 0 # initial value
    currlen <- T+a+1

    V1 <- rep(0,currlen-1)
    V2 <- rep(0,currlen-1)

    for (i in 1:(currlen-1))
      {
        V1[i] <- runif(1) # need only one set of uniforms for D_(a=0)
        V2[i] <- runif(1)
      }
   
    Dprev <- rep(0,currlen)   # D_(a=0), needs currlen-1 V1s, V2s

    Dprev[1] <- temp.par$nstar # initialize to nstar
    for (i in 2:currlen)
      Dprev[i] <- RWupdate(Dprev[(i-1)],V1[i-1],V2[i-1])
# end initialization
    
    termflag <- 0 # if set to 1, done (condition (A) on pg.8 is satisfied)

    while (!termflag) # until flag for termination is raised (until termflag==1)
      {
        a <- a + 1
        simulflag <- 0 # if set to 1, need to simulate new D_(a) (condition (B) or (C) is satisfied)
        while (!simulflag) # until next simulation (incrementing a by 1)
          {
            currlen <- T+a+1
            V1 <- c(runif(1),V1) # need one new uniform r.v.
            V2 <- c(runif(1),V2) # need one new uniform r.v.
            Dcurr <- rep(NA,currlen) # initialize to missing values
            Dcurr[1] <- temp.par$nstar # first value is nstar
            for (i in 2:currlen)
              {

                Dcurr[i] <- RWupdate(Dcurr[(i-1)],V1[i-1],V2[i-1])
                if (Dcurr[i]==0) # if D 'hits' 0, we are done!!
                  {
                    taustar <- currlen-i # hitting time (-taustar=time before t=0)
                    simulflag <- 1 # to get out of while(!simulflag) loop
                    termflag <- 1  # to get out of while(!termflag) loop
                    break
                  }
                
                if (i==currlen) # t=0
                  {
                    simulflag <- 1 # did not hit 0 before time t=0
                    Dprev <- Dcurr # hold onto current process for next iteration
                    break
                  }

                  if (Dcurr[i]==Dprev[i-1]) # curr. D couples with prev.D
                  #  (=> curr. D is not going anywhere interesting either)
                  {
                    simulflag <- 1 # next iteration: need new D_t
                    Dcurr[i:currlen] <- Dprev[(i-1):(currlen-1)] # copy values from previous r.w.(identical)
                    Dprev <- Dcurr # hold onto current process for next iteration
                    break
                  }
              }
          }
      }
    return(list(taustar=taustar,V1=V1[(currlen-taustar):(currlen-1)],V2=V2[(currlen-taustar):(currlen-1)]))
  }
# phase 2
# given results from phase1, obtain samples of interest
# as soon as Z_0 is produced, we do an accept-reject (based on whether N_0=level of target distr.)
phase2.ind <- function(taustar,V1,V2,proppars,logK=logK,data,prior,setup,temp.par)
{
  if ((length(V1) < taustar) || (length(V2) < taustar))
    {
      cat("phase2: taustar, V1, V2 incompatible\n")
      return(1)
    }

# using taustar and the uniform r.v.s from above to simulate Z_0
  N <- nrow(data$data)
  Zequi <- c(rep(0,(2*N+2)),0) # initialize Zequi to (N+1) zeros for x, followed by 1 zero for n
  logP.prev <- NA # initialize to null since there we start with h_0 distr. which is a distribution on an atom
  logQ.prev <- NA
  Zequi.h0 <- 0 # number of samples produced from h0
  Zequi.h1 <- 0 # number of samples produced from h1

  if (taustar!=0) # if taustar is 0, do not have to run the chain forward to time 0
    for (i in 1:taustar) # run chain forward from t=-taustar to t=0 (taustar no. of steps)
      {
        # need to run chain forward using unifs from phase 1
        newsamp <-  STupdate(Zequi[1:((2*N)+2)],Zequi[(2*N)+3],V1[i],V2[i],logP.prev,logQ.prev,proppars,logK,data,prior,temp.par,setup)
        logP.prev <- newsamp$logP.prev
        logQ.prev <- newsamp$logQ.prev

        Zequi <- newsamp$samp
        # keep track of samples from h0, h1 respectively
        Zequi.h0 <- Zequi.h0 + newsamp$numh0
        Zequi.h1 <- Zequi.h1 + newsamp$numh1
      }
# running chain from stationary distribution, Z_0 ~ H to Z_S
  Zstat <- Zequi # initialize to the first sample from H
  if (Zstat[(2*N)+3]==1) # if sample is from distribution of interest
    return(list(samp=Zstat[1:((2*N)+2)], numh0=Zequi.h0, numh1=Zequi.h1))
  else 
    return(list(samp=c(), numh0=Zequi.h0, numh1=Zequi.h1))
}

# function that takes as input: dataset, priors, rejection sampling envelope (with bounds)
# produces independent samples via perfect sampling

# this function that puts phase1 and phase2 together
perfect <- function(NUMSAMP=1000,proppars,logK,data,prior,temp.par)
{
# independent samples from perfect tempering sampler
  samp.perf.ind <- c()
  taustar.perf <- c()
  num.perf <- 0
  numh0 <- 0
  numh1 <- 0

  setup <- create.setup(data) # all the relevant matrices etc. that will be used/reused for sampling
  for (i in 1:NUMSAMP)
    {
      phase1.res <- phase1(1)
      taustar.perf <- c(taustar.perf,phase1.res$taustar)
      phase2.res <- phase2.ind(phase1.res$taustar, phase1.res$V1, phase1.res$V2,proppars,logK,data,prior,setup)
      
      if (!is.null(phase2.res$samp)) # if a sample was returned
        {
          num.perf <- num.perf+1
          samp.perf.ind <- rbind(samp.perf.ind,phase2.res$samp)
        }
      numh0 <- numh0+phase2.res$numh0
      numh1 <- numh1+phase2.res$numh1
    }
  # samp.perf are the perfect samples
  # num.perf is the number of perfect samples obtained (number of rows of samp.perf)
  # totsamp is the total number of samples produced in the simulated tempering chains
  # numh0 is number of samples produced from h0 distr.
  # numh1 is number of samples produced from h1 distr.
  return(list(samp=samp.perf.ind,num.perf=num.perf,numh0=numh0,numh1=numh1,totsamp=sum(taustar.perf),NUMSAMP=NUMSAMP,acc=num.perf/numh1,taustar.perf=taustar.perf))
}

## simpler/cleaner version of STupdate
## modified on Aug.19, 2004, following Moller and Nicholls more closely
simtempupdate <- function(x.prev,n.prev,u1,u2,logP.prev,logQ.prev,proppars,data,prior,temp.par,mixprob,setup)
  {
    ## default new state is current state (if proposal is not accepted below)
    x.new <- x.prev
    n.new <- n.prev
    numacc <- 0
    logalpha <- NA # in case proposal (nprime) is invalid
    proph0 <- 0 #proposal from h0
    proph1 <- 0 # not a proposal from h1
    
    ## proposal for tempering level
    if (u1<temp.par$p)
      nprime <- n.prev+1 
    else
      if (u1>(1-temp.par$q))
        nprime <- n.prev-1
      else
        nprime <- n.prev

    ## given tempering level proposal, proposal for values at that level
    if (nprime==0)
      {
        ## propose value (X_t) at new tempering level
        xprime <- c(rep(NA,(2*setup$N+2))) # atom (with probability 1)
        proph0 <- 1 #proposal from h0
        proph1 <- 0 # not a proposal from h1

        ## computing acceptance probabilities
        if (n.prev==0) # proposed 0->0 move
          {
            logP.val <- NA
            logQ.val <- NA
            logalpha <- 0 # accept with prob. 1
          }
        else # proposed 1->0 move
          {
            logP.val <- NA
            logQ.val <- NA
            logalpha <- (mixprob$logpi0+logQ.prev+log(temp.par$p))-(mixprob$logpi1+logP.prev+log(temp.par$q))
          }
      }
    else
      if (nprime==1)
        {
          x.prop <- seqsamp(proppars,setup) # draw from R
          xprime <- x.prop$samp
          proph0 <- 0 #not a proposal from h0
          proph1 <- 1 #proposal from h1
          
          ## computing acceptance probabilities
          if (n.prev==0) # proposed 0->1 move
            {
              logP.val <- logP.rej(xprime,data,prior)
              logQ.val <- x.prop$logR.val 
              logalpha <- (mixprob$logpi1+logP.val+log(temp.par$q))-(mixprob$logpi0+logQ.val+log(temp.par$p))
            }
          else # proposed 1->1 move
            {
              logP.val <- logP.rej(xprime,data,prior)
              logQ.val <- x.prop$logR.val 
              logalpha <- (logP.val+logQ.prev)-(logQ.val+logP.prev)
            }
        }
#    cat("when n.prev,nprime=",n.prev,nprime,"\n")
#    cat("logalpha=",logalpha,"when n.prev,nprime=",n.prev,nprime,"\n")
    
    ## accept-reject step only done for valid proposals, i.e. level=0 or 1
    if ((nprime==0) || (nprime==1))
      if (log(u2)<logalpha)
        {
          x.new <- xprime
          n.new <- nprime
          logP.prev <- logP.val
          logQ.prev <- logQ.val
          numacc <- 1
        }

    ## note, if proposal is not accepted above, or if nprime is not a valid tempering level, stay at current state
    
    return(list(samp=c(x.new,n.new),logP.prev=logP.prev,logQ.prev=logQ.prev,proph0=proph0,proph1=proph1,numacc=numacc,logalpha=logalpha))
  }

## simpler/cleaner version of simulated tempering algorithm
## NUMSAMP=number of samples from distribution of interest
## outp <- simtemp(100,proppars,coord=c(1,2,9,544+9,17,544+17,58,544+58),germ.data,germ.prior,germ.temp.par,germ.mixprob)
simtemp <- function(NUMSAMP,proppars,coord,data,prior,temp.par,mixprob,NUMALLSAMP=Inf,u1=NA,u2=NA,needsetup=TRUE,setup=NA,startval=NA,keepsamps=TRUE,keeptemps=TRUE,keepprob=TRUE)
  {
    if ((!is.na(u1[1])) && (!is.na(u2[1]))) # random variates have been provided
      userandvar <- 1 # use random variates (do not generate your own)
      
    N <- nrow(data$data)
    currsamp <- c(rep(NA,(2*N+2)),0) # initialize simulated tempering chain from 'HOT' distribution
    if (!is.na(startval))
      {
        currsamp <- startval # if starting value provided by user
        if (length(currsamp)!=(2*N+3))
          {
            cat("simtemp ERROR: starting value has wrong length\n")
            return(1)
          }
      }
    logP.prev <- NA # initialize to null since there we start with h_0 distr. which is a distribution on an atom
    logQ.prev <- NA
    numproph0 <- 0 # number of proposals produced from h0
    numproph1 <- 0 # number of proposals produced from h1
    numacc <- 0 # number of accepted proposals
    if (needsetup) # if there is no setup already
      setup <- create.setup(data) # all the relevant matrices etc. that will be used/reused for sampling
    samp <- c()

    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)
    state.prev <- 0 # initial state
    
    numsamp <- 0 # count number of samples in right distribution
    inseq <- 0 #  if 0, in sequence of right temperature
    regpts <- c() # keep regeneration points (only includes draws from level 1)
    regptsALL <- c() # keep regeneration points (including draws from level 0)

    numregpts <- 0 # number of regeneration points
    numallsamp <- 1 # number of sample generated (from hot and cold distribution)

    ## keep track of probabilities (prob(0 -> 1), prob(1 -> 0), prob(0 -> 0), prob(1 -> 1)
    if (keepprob)
      {
        logprob00 <- c()
        logprob01 <- c()
        logprob10 <- c()
        logprob11 <- c()
      }
    else
      {
        logprob00 <- NA
        logprob01 <- NA
        logprob10 <- NA
        logprob11 <- NA
      }
      
    ## keep track of temperatures of ALL values from chain (to see how chain moves between 0 and 1)
    if (keeptemps)
      tempstates <- c()
    else
      tempstates <- NA

    ## begin
    while ((numsamp <= NUMSAMP) && (numallsamp <= NUMALLSAMP))# until required number of samples is obtained
      {
        if (userandvar) #
          {
            U1 <- u1[numallsamp]
            U2 <- u2[numallsamp]
          }
        else
          {
            U1 <- runif(1)
            U2 <- runif(1)
          }
        newsamp <-  simtempupdate(currsamp[1:((2*N)+2)],currsamp[(2*N)+3],U1,U2,logP.prev,logQ.prev,proppars,data,prior,temp.par,mixprob,setup)
        logP.prev <- newsamp$logP.prev
        logQ.prev <- newsamp$logQ.prev
        currsamp <- newsamp$samp
        ## keep track of samples from h0, h1 respectively
        numproph0 <- numproph0 + newsamp$proph0
        numproph1 <- numproph1 + newsamp$proph1
        numacc <- numacc + newsamp$numacc
        
        ## keep track of acceptance probs of moves
        if (keepprob)
          {
            if ((state.prev==0) && (newsamp$proph0==1)) # 0->0 proposal
              logprob00 <- c(logprob00,newsamp$logalpha)
            if ((state.prev==0) && (newsamp$proph1==1)) # 0->1 proposal
              logprob01 <- c(logprob01,newsamp$logalpha)
            if ((state.prev==1) && (newsamp$proph0==1)) # 1->0 proposal
              logprob10 <- c(logprob10,newsamp$logalpha)
            if ((state.prev==1) && (newsamp$proph1==1)) # 1->1 proposal
              logprob11 <- c(logprob11,newsamp$logalpha)
          }
        
        if (keeptemps)
          tempstates <- c(tempstates,currsamp[(2*N)+3])
        if (currsamp[(2*N)+3]==1) # if sample is from distribution of interest
          {
            if (keepsamps) # if we need to keep all samples from cold distribution
              samp <- rbind(samp,as.numeric(currsamp[coord])) # Jan.25, 2004
            numsamp <- numsamp+1             ## Feb.17,2004
            ## Feb.17,2004
            if (state.prev==0) # if prev. pt. was a regeneration point (hot distr.)
              {
                regpts <- c(regpts,numsamp) # current draw is beginning of new tour
                regptsALL <- c(regptsALL,numallsamp) # this looks at ALL states of chain (from both level 0 and 1)
                numregpts <- numregpts +1 # increment number of regeneration points
              }
          }
        state.prev <- as.numeric(currsamp[2*N+3])
        numallsamp <- numallsamp+1 # number of sample generated (from hot and cold distribution)
      }

    if (!keepsamps) # if we keep just the last sample (do not keep all samples from cold distribution)
      samp <- rbind(samp,as.numeric(currsamp[coord]))
    
    return(list(samp=samp, numproph0=numproph0,numproph1=numproph1,numsamp=numsamp,totsamp=numallsamp,numreg=numregpts,regptsALL=regptsALL,numacc=numacc,regpts=regpts,logprob00=logprob00,logprob01=logprob01,logprob10=logprob10,logprob11=logprob11,tempstates=tempstates))
  }
    
# Feb.18,2004
# input: coord=coordinate of point selected. If FALSE, then entire
# sample is selected
# Jan.25, 2004: modified so regeneration points can be identified
# if keepprob=1, keep probabilities of all moves
## IMPORTANT: this only keeps samples from distribution of interest (rest are useless, since draws from atom)
simtemp.reg <- function(NUMREG=100,MAXSAMP=1000,coord=NA,temp.par,mixprob,proppars,data,prior,keepprob=TRUE,WHENPRINT=1000)
  {
    N <- nrow(data$data)
    currsamp <- c(rep(NA,(2*N+2)),0) # initialize simulated tempering chain from 'HOT' distribution
    logP.prev <- NA # initialize to null since there we start with h_0 distr. which is a distribution on an atom
    logQ.prev <- NA
    numproph0 <- 0 # number of proposals produced from h0
    numproph1 <- 0 # number of proposals produced from h1
    numacc <- 0 # number of accepted proposals
    setup <- create.setup(data) # all the relevant matrices etc. that will be used/reused for sampling
    samp <- c()

    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)
    # added Jan.25, 2004
    state.prev <- 0 # initial state
    
    numsamp <- 0 # count number of samples in right distribution
    inseq <- 0 #  if 0, in sequence of right temperature
    regpts <- c() # keep regeneration points

    numregpts <- 0 # number of regeneration points
    i <- 1 # number of sample generated (from hot and cold distribution)

    ## keep track of probabilities (prob(0 -> 1), prob(1 -> 0), prob(0 -> 0), prob(1 -> 1)
    if (keepprob)
      {
        logprob00 <- c()
        logprob01 <- c()
        logprob10 <- c()
        logprob11 <- c()
      }

    while ((numregpts<NUMREG) && (i < MAXSAMP)) # until required number of tours/regeneration pts are obtained
      {
##        newsamp <-  STupdate(currsamp[1:((2*N)+2)],currsamp[(2*N)+3],runif(1),runif(1),logP.prev,logQ.prev,proppars,logK,data,prior,temp.par,setup)
        newsamp <-  simtempupdate(currsamp[1:((2*N)+2)],currsamp[(2*N)+3],runif(1),runif(1),logP.prev,logQ.prev,proppars,data,prior,temp.par,mixprob,setup)
        logP.prev <- newsamp$logP.prev
        logQ.prev <- newsamp$logQ.prev

        currsamp <- newsamp$samp
        # keep track of samples from h0, h1 respectively
        numproph0 <- numproph0 + newsamp$proph0
        numproph1 <- numproph1 + newsamp$proph1
        numacc <- numacc + newsamp$numacc

        ## keep track of acceptance probs of moves
        if (keepprob)
          {
            if ((state.prev==0) && (newsamp$proph0==1)) # 0->0 proposal
              logprob00 <- c(logprob00,newsamp$logalpha)
            if ((state.prev==0) && (newsamp$proph1==1)) # 0->1 proposal
              logprob01 <- c(logprob01,newsamp$logalpha)
            if ((state.prev==1) && (newsamp$proph0==1)) # 1->0 proposal
              logprob10 <- c(logprob10,newsamp$logalpha)
            if ((state.prev==1) && (newsamp$proph1==1)) # 1->1 proposal
              logprob11 <- c(logprob11,newsamp$logalpha)
          }
        
        if (currsamp[(2*N)+3]==1) # if sample is from distribution of interest
          {
            samp <- rbind(samp,as.numeric(currsamp[coord])) # Jan.25, 2004
            numsamp <- numsamp+1             ## Feb.17,2004
            ## Feb.17,2004
            if (state.prev==0) # if prev. pt. was a regeneration point (hot distr.)
              {
                regpts <- c(regpts,numsamp) # current draw is beginning of new tour
                numregpts <- numregpts +1 # increment number of regeneration points
                if ((numregpts %% WHENPRINT)==0)
                  {
                    cat("numregpts=",numregpts,"\n")
                    dput(list(samp=samp, numproph0=numproph0,numproph1=numproph1,numsamp=numsamp,totsamp=i,NUMREG=NUMREG,numacc=numacc,regpts=regpts,logprob00=logprob00,logprob01=logprob01,logprob10=logprob10,logprob11=logprob11),"germ.sim.short")
                  }
              }
          }
        state.prev <- as.numeric(currsamp[2*N+3])
        i <- i+1
      }
    
    if (numregpts<NUMREG)
      cat("exit without enough regenerations (",numregpts,"vs",NUMREG,")\n")

    if (keepprob)
      return(list(samp=samp, numproph0=numproph0,numproph1=numproph1,numsamp=numsamp,totsamp=i,NUMREG=NUMREG,numacc=numacc,regpts=regpts,logprob00=logprob00,logprob01=logprob01,logprob10=logprob10,logprob11=logprob11)) # Feb.17,2004
    else
      return(list(samp=samp, numproph0=numproph0,numproph1=numproph1,numsamp=numsamp,totsamp=i,NUMREG=NUMREG,numacc=numacc,regpts=regpts)) # Feb.17,2004
  }

## random walk accept-reject probabilities
logRWacc <- function(curr,prop,temp.par)
  {
    L01 <- temp.par$p
    L10 <- temp.par$q
    
    if (curr==0)
      if (prop==1)
        logprob <- log(L10)-log(L01) # L10/L01
      else  # prop==0
        logprob <- 0 # prob=1

    if (curr==1)
      if (prop==0)
        logprob <- log(L01)-log(L10) # L01/L10
      else # prop==1
        logprob <- 0
    
    return(logprob) 
  }

## phase 1: random walk used to find regeneration time in the past
## input: mixprob=temp
## changed on Aug.19,2004
perfphase1 <- function(mixprob,temp.par)
  {
    noregen <- 1 # 0 if random walk regenerated (hit level 0)
    u1 <- c() # list of uniform random variates
    u2 <- c() # list of uniform random variates
    Tpast <- 1 # time in past where random walk is started
    while (noregen)
      {
        u1 <- c(u1,runif(1))
        u2 <- c(u2,runif(1))

        RWstate <- 1 # always start at level 1 (cold state)
        for (t in Tpast:1)
          {
            if (RWstate==1)
              {
                if (u1[t]> (1-temp.par$q)) # temp.par$q is l(1,0) CHANGED ON AUG.19,2004
                  prop <- 0 # propose 0 w/ prob. q
                else
                  prop <- 1 # propose 0 w/ prob. 1-q
              }
            else # RWstate==0
              {
                cat("perfphase1 ERROR: current state is 0 (not possible)\n")
                return(1)
                if (u1[t]<temp.par$p) # temp.par$p is l(0,1)
                  prop <- 1 # propose 1 w/ prob. p
                else
                  prop <- 0 # propose 0 w/ prob. 1-p
              }
            
            ## accept-reject step
            logprob <- logRWacc(RWstate,prop,temp.par)
            if (log(u2[t])<logprob) 
              RWstate <- prop ## accept move with prob logprob, else stay at same state

            if (RWstate==0)
              {
                noregen <- 0 # it has hit regenerative state
                break
              }
          }

        Tpast <- Tpast+1 # move one step back in time
      }
    Tregen <- t

    return(list(Tregen=Tregen,u1=u1,u2=u2))
  }

## simpler, cleaner version of perfect tempering algorithm
## boo <- perftemp(100,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob)
## if FIXEDNUM is TRUE, run until NUMITER samples are obtained
perftempORIG <- function(NUMITER,proppars,coord,data,prior,temp.par,mixprob,FIXEDNUM=FALSE)
  {
    MAXNUMITER <- 100000000 # a very large number
    setup <- create.setup(data)
    perfsamp <- c()
    hittime <- c()
    coldprop <- 0 # number of cold sample draws proposed
    numperf <- 0 # number of perfect samples returned
    if (FIXEDNUM)
      {
        NUMSAMP <- NUMITER # number of samples wanted is set to NUMITER
        NUMITER <- MAXNUMITER # number of iterations is set to large number
      }
    for (i in 1:NUMITER)
      {
        ## phase 1: random walk used to find regeneration time in the past
        phase1res <- perfphase1(mixprob,temp.par)
        hittime <- c(hittime,phase1res$Tregen)
##        print(phase1res)
        U1 <- rev(phase1res$u1)[-c(1)] # reverse order and remove last element: u1,u2,u3,u4 becomes u3,u2,u1
        U2 <- rev(phase1res$u2)[-c(1)] # reverse order and remove last element: u1,u2,u3,u4 becomes u3,u2,u1
        regentime <- phase1res$Tregen-1
        ## phase 2: using phase 1 regeneration time, and uniform random variates, run sim.temp. chain forward
        phase2res <- simtemp(NUMSAMP=regentime,proppars,coord,data,prior,temp.par,mixprob,NUMALLSAMP=regentime,u1=U1,u2=U2,needsetup=FALSE,setup,keepsamps=FALSE)

##        coldprop <- c(coldprop,phase2res$numproph1)
        coldprop <- coldprop+phase2res$numproph1
        samp <- phase2res$samp
#        cat(phase1res$Tregen,"\n")
#        print(phase2res$tempstates)
        if (!is.na(samp[1]))
          {
            perfsamp <- rbind(perfsamp, samp)
            numperf <- numperf+1
##            cat("numperf=",numperf,"\n")
##            cat("NUMSAMP,FIXEDNUM=",NUMSAMP,FIXEDNUM,"\n")
            if (FIXEDNUM)
              if (numperf==NUMSAMP) # done, exit
                return(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/coldprop))
#                return(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/sum(coldprop)))
          }
        ## periodic output
        if ((i %% 1000)==0) # every 100th iteration
          {
            cat("Iteration=",i,"numperf=",numperf,"\n")
            dput(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/sum(coldprop)),"perf.temp")
          }
      }

    if (numperf==0)
      cat("perftemp: ZERO samples returned! \n")

    if (FIXEDNUM)
      if (numperf<NUMSAMP)
        cat("perftemp: not enough samples returned (",numperf," versus ",NUMSAMP,")\n")
    
    return(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/sum(coldprop)))
  }

## simpler, cleaner version of perfect tempering algorithm (replacing above)
## remove hittime (since this wastes time)
## boo <- perftemp(100,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob)
## if FIXEDNUM is TRUE, run until NUMITER samples are obtained
perftemp <- function(NUMITER,proppars,coord,data,prior,temp.par,mixprob,FIXEDNUM=FALSE)
  {
    MAXNUMITER <- 100000000 # a very large number
    setup <- create.setup(data)
    perfsamp <- c()
    hittime <- c()
    coldprop <- 0 # number of cold sample draws proposed
    numperf <- 0 # number of perfect samples returned
    if (FIXEDNUM)
      {
        NUMSAMP <- NUMITER # number of samples wanted is set to NUMITER
        NUMITER <- MAXNUMITER # number of iterations is set to large number
      }
    for (i in 1:NUMITER)
      {
        ## phase 1: random walk used to find regeneration time in the past
        phase1res <- perfphase1(mixprob,temp.par)
##        hittime <- c(hittime,phase1res$Tregen) # changed on Sep.14
        U1 <- rev(phase1res$u1)[-c(1)] # reverse order and remove last element: u1,u2,u3,u4 becomes u3,u2,u1
        U2 <- rev(phase1res$u2)[-c(1)] # reverse order and remove last element: u1,u2,u3,u4 becomes u3,u2,u1
        regentime <- phase1res$Tregen-1
        ## phase 2: using phase 1 regeneration time, and uniform random variates, run sim.temp. chain forward
        phase2res <- simtemp(NUMSAMP=regentime,proppars,coord,data,prior,temp.par,mixprob,NUMALLSAMP=regentime,u1=U1,u2=U2,needsetup=FALSE,setup,keepsamps=FALSE)

##        coldprop <- c(coldprop,phase2res$numproph1)
        coldprop <- coldprop+phase2res$numproph1
        samp <- phase2res$samp
#        cat(phase1res$Tregen,"\n")
#        print(phase2res$tempstates)
        if (!is.na(samp[1]))
          {
            perfsamp <- rbind(perfsamp, samp)
            numperf <- numperf+1
##            cat("numperf=",numperf,"\n")
##            cat("NUMSAMP,FIXEDNUM=",NUMSAMP,FIXEDNUM,"\n")
            if (FIXEDNUM)
              if (numperf==NUMSAMP) # done, exit
                return(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/coldprop))
#                return(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/sum(coldprop)))
          }
        ## periodic output
        if ((i %% 1000)==0) # every 100th iteration
          {
            cat("Iteration=",i,"numperf=",numperf,"\n")
            dput(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/sum(coldprop)),"perf.temp")
          }
      }

    if (numperf==0)
      cat("perftemp: ZERO samples returned! \n")

    if (FIXEDNUM)
      if (numperf<NUMSAMP)
        cat("perftemp: not enough samples returned (",numperf," versus ",NUMSAMP,")\n")
    
    return(list(samp=perfsamp,hittime=hittime,coldprop=coldprop,numperf=numperf,accrate=numperf/sum(coldprop)))
  }
