exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R")
##source("~/public_html/batchmeans.R")
cancer.data <- readSimpleData(paste(exactdir,"/cancer",sep=""))
cancer.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
cancer.proppars <- list(multtdf=50,muh=4.3,sigmah=2.1,muc=-0.95,sigmac=0.4,tdfh=50,tdfc=50)
cancer.logbound <- 4195.395
cancer.mixprob <- list(logpi0=log(1),logpi1=-cancer.logbound)

############################################################################################################
## run rejection sampler
############################################################################################################
set.seed(1)
#rej <- rejsamp(100000,cancer.proppars,coord=c(1,2,9,96,17,104,58,145),cancer.data,cancer.prior,logbound=-2866.039,changebound=FALSE,MAXTRY=10,FIXEDNUM=FALSE,outfile="rejsamp")
rej <- rejsamp(100000,cancer.proppars,coord=c(1,2,9,96,17,104,58,145),cancer.data,cancer.prior,logbound=cancer.logbound,changebound=FALSE,MAXTRY=10,FIXEDNUM=FALSE,outfile="rejout.cancer")
write(rej$accrate,"rejacc.cancer")
