exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R") # load in important functions
############################################################################################################
## infant mortality data
############################################################################################################
infant.data = readSimpleData("infant")
infant.prior = list(alphah=1,betah=100,alphac=1, betac=50)
infant.logbound = -2869.809
#infant.mixprob = list(logpi0=log(1),logpi1=-infant.logbound)
infant.temp.par = list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
infant.proppars = list(multtdf=50,muh=5.45,sigmah=0.55,muc=3.0,sigmac=0.4,tdfh=50,tdfc=50)

N=10000
## run rejection sampler
set.seed(1)
rej.time=system.time((rejout = rejsamp(N,infant.proppars,coord=c(1,2,9,96,17,104,58,145),infant.data,infant.prior,logbound=-3152.684,changebound=FALSE,outfile="rejout.infant")))
write(rejout$accrate,"rejacc.infant")
write(rej.time,"rejtime.infant")

