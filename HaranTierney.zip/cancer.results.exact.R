source("../multreg/mcse.R")
cancer.data <- readSimpleData(paste(exactdir,"cancer",sep=""))
cancer.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
cancer.proppars <- list(multtdf=50,muh=4.3,sigmah=2.1,muc=-0.95,sigmac=0.4,tdfh=50,tdfc=50)
cancer.logbound <- 4195.395
cancer.mixprob <- list(logpi0=log(1),logpi1=-cancer.logbound)
NUMSAMP <- 1000
#rej.time <- system.time(rej <- rejsamp(NUMSAMP,cancer.proppars,coord=c(1,2,9,96,17,104,58,145),cancer.data,cancer.prior,logbound=cancer.logbound,changebound=TRUE))

## run until 100 samples returned
rej.time <- system.time(rej <- rejsamp(NUMSAMP,cancer.proppars,coord=c(1,2,9,96,17,104,58,145),cancer.data,cancer.prior,logbound=cancer.logbound,changebound=FALSE,FIXEDNUM=TRUE))
dput(rej,"cancer.rej")
dput(rej.time,"cancer.rej.time")

cancer.temp.par <- list(p=0.5,q=0.5,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,cancer.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),cancer.data,cancer.prior,cancer.temp.par,cancer.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"cancer.perf1")
dput(perf.time,"cancer.perf1.time")

cancer.temp.par <- list(p=0.6,q=0.4,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,cancer.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),cancer.data,cancer.prior,cancer.temp.par,cancer.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"cancer.perf2")
dput(perf.time,"cancer.per2.time")

cancer.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,cancer.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),cancer.data,cancer.prior,cancer.temp.par,cancer.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"cancer.perf3")
dput(perf.time,"cancer.perf3.time")

cancer.temp.par <- list(p=0.2,q=0.8,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,cancer.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),cancer.data,cancer.prior,cancer.temp.par,cancer.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"cancer.perf5")
dput(perf.time,"cancer.perf5.time")
#> perf$acc
#[1] 0.04659832

#cancer.temp.par <- list(p=0.8,q=0.2,nstar=1)  # for simulated tempering/perfect sampling
#perf.time <- system.time(perf <- perftemp(NUMSAMP,cancer.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),cancer.data,cancer.prior,cancer.temp.par,cancer.mixprob,FIXEDNUM=TRUE))
###[1] 136.43   1.53 142.71   0.00   0.00
#dput(perf,"cancer.perf4")
#dput(perf.time,"cancer.perf4.time")

#cancer.temp.par <- list(p=0.9,q=0.1,nstar=1)  # for simulated tempering/perfect sampling
#perf.time <- system.time(perf <- perftemp(NUMSAMP,cancer.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),cancer.data,cancer.prior,cancer.temp.par,cancer.mixprob,FIXEDNUM=TRUE))
#dput(perf,"cancer.perf6")
#dput(perf.time,"cancer.perf6.time")
