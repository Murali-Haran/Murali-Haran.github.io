## results from run.exact.germ.R
## Rejection sampler results
rej1 <- dget("rej1.germ.short")
> rej1$notinenv
[1] 0
> rej1$newlogbound
[1] -14583.24
> rej1$acc
[1] 5e-04
## time taken
> 10731.39/3600
[1] 2.980942
# samples/sec
5/10731.39
[1] 0.0004659229

> rej2 <- dget("rej2.germ.short")
> rej2$notinenv
[1] 0
> rej2.time <- dget("rej2.germ.short.time")
> rej2.time
[1] 13253.56  4239.60 18941.97     0.00     0.00
> 6/13253.56
[1] 0.0004527086
# samples/sec
6/13253.56
[1] 0.0004527086

perf2 <- dget("perf2.germ.short")
> dim(perf3$samp)
[1] 2 8
> perf2.time
[1] 3639.05 1174.09 5559.02    0.00    0.00
> 2/3639.05
[1] 0.000549594

perf3 <- dget("perf3.germ.short")
> perf3.time <- dget("perf3.germ.short.time")
> perf3.time
[1] 5647.23 1772.17 7859.91    0.00    0.00
> 2/5647.23
[1] 0.0003541559
