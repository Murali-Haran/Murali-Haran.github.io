source("../multreg/mcse.R")
lips.data <- readSimpleData(paste(exactdir,"lips",sep=""))
lips.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
lips.proppars <- list(multtdf=50,muh=4.6,sigmah=1.1,muc=0.5,sigmac=0.4,tdfh=50,tdfc=50)
lips.logbound <- -324.7209 #-326.031747544955 # -326.4265
lips.mixprob <- list(logpi0=log(1),logpi1=-lips.logbound)
lips.temp.par <- list(p=0.6,q=0.4,nstar=1)  # for simulated tempering/perfect sampling
coordlist <- c(1,2,9,56+9,17,56+17,37,56+37)

## run until 1000 samples returned
rej.time <- system.time(rej <- rejsamp(100,lips.proppars,coord=coordlist,lips.data,lips.prior,logbound=lips.logbound,changebound=FALSE,FIXEDNUM=TRUE))
dput(rej,"lips.rej100")
dput(rej.time,"lips.rej100.time")

perf100.time <- system.time(perf100 <- perftemp(100,lips.proppars,coord=coordlist,lips.data,lips.prior,lips.temp.par,lips.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf100,"lips.perf100")
dput(perf100.time,"lips.perf100.time")

lips.temp.par <- list(p=0.5,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
perf100.time <- system.time(perf100 <- perftemp(100,lips.proppars,coord=coordlist,lips.data,lips.prior,lips.temp.par,lips.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf100,"lips.perf100A")
dput(perf100.time,"lips.perf100.timeA")

lips.temp.par <- list(p=0.8,q=0.2,nstar=1)  # for simulated tempering/perfect sampling
perf100.time <- system.time(perf100 <- perftemp(100,lips.proppars,coord=coordlist,lips.data,lips.prior,lips.temp.par,lips.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf100,"lips.perf100B")
dput(perf100.time,"lips.perf100.timeB")

lips.temp.par <- list(p=0.7,q=0.5,nstar=1)  # for simulated tempering/perfect sampling
perf100.time <- system.time(perf100 <- perftemp(100,lips.proppars,coord=coordlist,lips.data,lips.prior,lips.temp.par,lips.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf100,"lips.perf100C")
dput(perf100.time,"lips.perf100.timeC")
