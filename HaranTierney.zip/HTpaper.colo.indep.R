exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R") # load in important functions

colo.data = readSimpleData("colocancer")
colo.prior = list(alphah=1,betah=100,alphac=1, betac=50)
colo.proppars <- list(multtdf=50,muh=5.68,sigmah=0.7,muc=4.82,sigmac=0.7,tdfh=50,tdfc=50)
colo.logbound <- -4329.682
colo.mixprob <- list(logpi0=log(1),logpi1=-colo.logbound)
colo.temp.par = list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
## run uniformly ergodic block MCMC (independence chain)
N=10000 #10000
set.seed(1)
mcmc.time=system.time((mcmcout=blockMCMC(NUMSAMP=N,proppars=colo.proppars,coord=c(1,2,9,96,17,104,58,145),data=colo.data,prior=colo.prior,outfile="mcmcout.colo",writeevery=1)))
write(mcmcout$accrate,"mcmcacc.colo")
write(mcmc.time,"mcmctime.colo")
