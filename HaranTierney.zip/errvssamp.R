## study how standard error estimates vary with sample size
source("http://www.stat.psu.edu/~mharan/batchmeans.R")
bmerrvssamp = function(samp, g=mean)
  {
    if (length(samp)<100)
      batchsize = 1
    else
      batchsize = length(samp)%/%100

    bmest = c()
    for (i in seq(batchsize,length(samp),by=batchsize))
      {
        thisbm=bm(samp[1:i])
        bmest = c(bmest,thisbm$se)
      }

#    ts.plot(bmest,main=paste("Monte Carlo (cbm) estimates with increasing samples (incr of ",batchsize,")\n",sep=""))
    plot(seq(batchsize,length(samp),by=batchsize),bmest,main=paste("Monte Carlo s.error estimates vs. sample size\n"),type="l",xlab="sample size",ylab="error estimate")
  }

## simple s.error estimates  (iid samples), how they vary with sample size
errvssamp = function(samp, g=mean)
  {
    if (length(samp)<100)
      batchsize = 1
    else
      batchsize = length(samp)%/%100

    err = c()
    for (i in seq(batchsize,length(samp),by=batchsize))
      {
        thiserr=sd(samp[1:i])/sqrt(i)
        err = c(err, thiserr )
      }

#    ts.plot(err,main=paste("Monte Carlo (cbm) estimates with increasing samples (incr of ",batchsize,")\n",sep=""))
    plot(seq(batchsize,length(samp),by=batchsize),err,main=paste("Monte Carlo s.error estimates vs. sample size\n"),type="l",xlab="sample size",ylab="error estimate")
  }

## find sample size at which error first drops below some level
## postbm(mcmcout[,2], 2.5, 1)
postbm = function(samp, thresh, batchsize=NA, g=mean)
  {
    if (length(samp)<1000)
      stop("error: need sample size greater than 1000\n")
    if (is.na(batchsize))
      batchsize = length(samp)%/%100
##    bmest = c()
    cat("batchsize=",batchsize,", threshold=",thresh,"\n")
    for (i in seq(1000,length(samp),by=batchsize))
      {
        thisbm=bm(samp[1:i])
##        cat("thisbm$se=",thisbm$se,"\n")
        if (thisbm$se<thresh)
          {
            cat("threshold ",thresh," attained at i=",i,"\n")
            return(i)
          }
##        bmest = c(bmest,thisbm$se)
      }

#    ts.plot(bmest,main=paste("Monte Carlo (cbm) estimates with increasing samples (incr of ",batchsize,")\n",sep=""))
#    plot(seq(batchsize,length(samp),by=batchsize),bmest,main=paste("Monte Carlo s.error estimates vs. sample size\n"),type="l",xlab="sample size",ylab="error estimate")
  }

## find sample size at which error first drops below some level
## now for iid samples
## postse(rejout[,2], 2.5, 1)
postse = function(samp, thresh, batchsize=1, g=mean)
  {
    if (length(samp)<2)
      stop("error: need sample size greater than 2\n")
    cat("batchsize=",batchsize,", threshold=",thresh,"\n")
    for (i in seq(2,length(samp),by=batchsize))
      {
        thiserr=sd(samp[1:i])/sqrt(i)
##        cat("thisbm$se=",thisbm$se,"\n")
        if (thiserr<thresh)
          {
            cat("threshold ",thresh," attained at i=",i,"\n")
            return(i)
          }
##        bmest = c(bmest,thisbm$se)
      }

#    ts.plot(bmest,main=paste("Monte Carlo (cbm) estimates with increasing samples (incr of ",batchsize,")\n",sep=""))
#    plot(seq(batchsize,length(samp),by=batchsize),bmest,main=paste("Monte Carlo s.error estimates vs. sample size\n"),type="l",xlab="sample size",ylab="error estimate")
  }
