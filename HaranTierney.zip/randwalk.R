## run a random walk on (0,1)
rwalk <- function(walklen,p.prob,q.prob)
  {
    rw <- rep(0,walklen)
    rw[1] <- 1  # start at 1
    i=1
    firsthit=0 # not yet seen 0
    while (i<walklen)
      {
        if (rw[i]==1)
          {
            U=runif(1)
            if (U<q.prob)
              rw[i+1] <- 0
            else
              rw[i+1] <- 1
          }
        if (rw[i]==0)
          {
            U=runif(1)
            if (U<p.prob)
              rw[i+1] <- 1
            else
              rw[i+1] <- 0
          }
        if (!(firsthit)&&(rw[i+1]==0))
          {
            hittime <- i
            firsthit <- 1
          }
        i <- i+1
      }

    return(list(rw=rw,hittime=hittime))
  }

rwalkexp <- function(numrep,rwlen,p.prob,q.prob)
  {
    hittime <- rep(NA,numrep)
    numcold <- rep(NA,numrep)
    for (i in 1:numrep)
      {
        res <- rwalk(rwlen,p.prob,q.prob)
        hittime[i] <- res$hittime
        numcold[i] <- sum(res$rw)
      }

    cat("expected: hitting time=",(1/q.prob),"\n")
    cat("proportion in cold distribution=",p.prob/(p.prob+q.prob),"\n")
    print(summary(hittime))
    print(summary(numcold/rwlen))
  }

##rwalkexp(1000,1000,0.2,0.8)
##expected: hitting time= 1.25
##proportion in cold distribution= 0.2
##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
##  1.000   1.000   1.000   1.277   1.000   5.000
##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
## 0.1710  0.1940  0.2010  0.2016  0.2100  0.2460

##> rwalkexp(1000,1000,0.5,0.7)
##expected: hitting time= 1.428571
##proportion in cold distribution= 0.4166667
##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
##  1.000   1.000   1.000   1.473   2.000   8.000
##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
## 0.3790  0.4080  0.4170  0.4171  0.4260  0.4550
