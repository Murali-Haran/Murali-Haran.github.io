if (!exists("exactdir"))
  exactdir <- "/home/u1/mharan/exact/" # location of directory with functions for exact sampling
# compiling shared library into R
#R SHLIB gpskca.f

# function to minimize bandwidth of a given positive definite
# matrix using the Gibbs-Poole-Stockmeyer-King algorithm from
# http://www.netlib.org/toms/582
# file extracted from 528.txt is gpskca.f
# Params: N, DEGREE, RSTART, CONNEC, OPTPRO, WRKLEN, PERMUT, WORK, BANDWD, PROFIL, ERROR, SPACE

# N (integer) = dim of matrix
# DEGREE (integers of dimension N) = NUMBER OF NON-ZERO OFF-DIAGONAL ENTRIES IN THE  I-TH  ROW OF THE SPARSE MATRIX
# CONNECT (integers of dimension= number of non-zeros in matrix) = THE COLUMN INDICES OF THE NON-ZERO ENTRIES (above) ARE GIVEN IN CONSECUTIVE LOCATIONS IN CONNEC
# , STARTING AT LOCATION  RSTART(I)
# OPTPRO =.FALSE if bandwidth reduction is most important, TRUE => profile reduction is most imp.
# WRKLEN =

# INPUT/OUTPUT
# PERMUT: initial reordering of rows and cols of matrix, usually set to Identity.

# OUTPUT
# WORK (double of dimension 6N+3)
# BANDWD (integer of dimension 1) bandwidth after reordering
# PROFIL profile of matrix
# ERROR = 0 => no problem, else there is a problem
# can now load shared library into "R"
dyn.load(paste(exactdir,"/gpskca.so",sep=""))
band.min <- function(mat)
  {
    N <- dim(mat)[1] # integer
    WRKLEN <- 6*N+3 # specifying work space in FORTRAN

    A <- c(as.matrix(mat))
#    res <- .Fortran("gpskcamod", N=as.integer(N), A=as.double(A), WRKLEN=as.integer(WRKLEN), BANDWD=integer(1), PERMUT=integer(N),ERROR=integer(1))
    res <- .Fortran("gpskcamod", N=as.integer(N), A=as.double(A), WRKLEN=as.integer(WRKLEN), BANDWD=integer(1), PERMUT=integer(N),ORIGPERMUT=integer(N),ERROR=integer(1))
    
#    return(list(bandwd=res$BANDWD,profil=res$PROFIL,permut=res$PERMUT,origpermut=order(res$PERMUT),error=res$ERROR))
    return(list(bandwd=res$BANDWD,profil=res$PROFIL,permut=order(res$PERMUT),origpermut=res$PERMUT,error=res$ERROR))
    # note: permutation returned appears to be the inverse permutation, and vice-versa
    # which is why origpermut=permut and permut=order(permut)
  }
# crude algorithm for finding bandwidth of a matrix
findbw <- function(mat)
{
  N <- dim(mat)[1]
  bw <- N-1

  for (i in N:2)
    {
      indI <- 1:(N-i+1)
      indJ <- i:N

      allzero <- 1 # assume all terms on ith band are zeros
      for (j in 1:length(indI))
        if (mat[indI[j],indJ[j]]!=0)
          allzero <- 0

      if (allzero) # if all terms on ith band are zeros
        bw <- bw-1 # decrement bandwidth, and keep looping
      else
        return(bw)
    }
  return(bw) 
}
