#sampleTHETA.lt2(NUMSAMP=100000,multt.df=50,mu1 = 4.3,sigma1=2.1,t.df1=50,mu2 = -0.95,sigma2=0.4,t.df2=50,K2=4113.091,data=toydata,prior=toyprior)

#source("smrf.R") # this order is vitally important (smrf.R comes before model2.functions.R)
source("model2.functions.R")
source("band.chol.R") # for band choleski
                                        # this version of perfect tempering for Model 1
                                        # uses only the distributions H0 (on atom) and H1 (target)

#toytemp.par <- list(p=1/3,q=1/3,nstar=1) # nstar=1 since only 2 distributions are used

create.setup <- function(data=toydata)
  {
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    # find permutation that minimizes bandwidth: done only once
    source("band.min.R")
    band.min.Q <- band.min(Q)
    permut <- band.min.Q$permut
    rev.permut <- band.min.Q$origpermut
    bw <- band.min.Q$bandwd
    
    # all of the following vectors and matrices are permuted according to above
    Y <- data$data$Y[permut]
    E <- data$data$E[permut]
    etahat <- log(Y/E)
    Vinv <- diag(Y)
    Q <- Q[permut, permut]
    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
    d <- transfmuhat
    Zeros <- matrix(0, N, N)

    setup <- list(Q=Q,N=N,Vinv=Vinv,numadj=numadj,Y=Y,E=E,d=d,Zeros=Zeros,Id=Id,permut=permut,rev.permut=rev.permut,bw=bw)
#    setup <- list(X=X,numadj=numadj,muhat=muhat,N=N)

    return(setup)
  }
# corrected version (Apr.6, 2003)
logalphatwiddle <- function(n,nprime,temp.par=toytemp.par)
  {
    logval <- -9999

    p <- temp.par$p
    q <- temp.par$q
    
#    if ((n==nprime) || ((n==0) && (nprime==1)) ||  ((n==1) && (nprime==0)))
    if (((n==0) && (nprime==0)) || ((n==1) && (nprime==1)))
      logval <- 0

    if ((n==0) && (nprime==1))
      logval <- log(temp.par$q)-log(temp.par$p)

    if ((n==1) && (nprime==0))
      logval <- log(temp.par$p)-log(temp.par$q)

    if (logval==-9999)
      {
        cat("logalphatwiddle: error - invalid input\n")
        break;
      }
    else
      return(logval)
  }

# when in current state (x,n)
# obtain new state (xprime,nprime) using u1,u2 ~ Unif(0,1)
# input: (x,n,u1,u2),
# mu.prev (previous mean), cholinv.prev: choleski of proposal precision matrix at previous iteration,
# IMPORTANT: both mu.prev, cholinv.prev are permuted (for minimized bandwidth)
# multt.df,mu.tau1,sigma.tau1,tau.t.df1,mu.tau2,sigma.tau2,tau.t.df2 (proposal parameters),
# data, prior (for logP.rej)
# setup=matrices, vectors that will be used/reused in the algorithm (unchanged throughout)

# output: (xprime, nprime) (new state),
# mu.prev (mean at this iteration), cholinv.prev: choleski of proposal precision matrix at this iteration
# IMPORTANT: both mu.prev, cholinv.prev are permuted (for minimized bandwidth)
# numh0, numh1 : number of proposals from h0, h1 respectively
STupdate <- function(x.prev,n,u1,u2,logP.prev,logQ.prev,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK=logK,data=toydata,prior=toyprior,temp.par=toytemp.par,setup)
  {
    numh0 <- 0# number of proposals from h0
    numh1 <- 0 # number of proposals from h1
    numacc <- 0 # number of times a proposal was accepted
    
    # equivalent to previous method of sampling, but easier to follow
    if (n==0)
      {
       if (u1 < (1-temp.par$p))
         nprime <- 0
       else
         nprime <- 1
     }

    if (n==1)
      {
#        if (u1 < (1-temp.par$p)) #edited out Apr.6,2003
        if (u1 < (1-temp.par$q))
          nprime <- 1
        else
          nprime <- 0
      }

    # given the proposal for tempering level, propose value (X_t) at new tempering level
    # and decide whether to accept this joint proposal
    N <- setup$N
    # sampling (xprime,nprime)
    if (nprime==0)
      {
        # sample from atom
        zero.samp <- c(rep(0,(2*N+2)), 0)
        if (n==0)
          return(list(samp=zero.samp,logP.prev=NA,logQ.prev=NA,numh0=1,numh1=0,numacc=1)) # return with prob. 1
        else # if n==1
          {
            # alpha=(Q/K*P)*(p/q)
            logalpha <- logQ.prev - logP.prev +logK + log(temp.par$p)-log(temp.par$q)
            if (u2<logalpha)
              return(list(samp=zero.samp,logP.prev=NA,logQ.prev=NA,numh0=1,numh1=0,numacc=1))#move to 0
            else
              return(list(samp=c(x.prev,n),logP.prev=logP.prev,logQ.prev=logQ.prev,numh0=1,numh1=0,numacc=1))#stay at 1
          }
      }

    if (nprime==1)
      {
        # get matrices etc. with everything already permuted
        Q <- setup$Q
        Y <- setup$Y
        d <- setup$d
        Zeros <- setup$Zeros
        Id <- setup$Id
        permut <- setup$permut
        rev.permut <- setup$rev.permut
        Vinv <- setup$Vinv
        bw <- setup$bw
        nu <- multt.df # for convenience
        # end setup
        
        # sample from envelope
        taucand <- c(rlt(1,meanlog=mu1,sdlog=sigma1,t.df1),
                     rlt(1,meanlog=mu2,sdlog=sigma2,t.df2))
        tauh <- taucand[1]
        tauc <- taucand[2]
        
        # fast choleski decomposition of Sigmainv (precision matrix)
        U11 <- diag(sqrt(Y+tauh))
        U12 <- diag(Y/sqrt(Y+tauh))

        temp <- (Vinv+tauc*Q) - diag(Y^2/(Y+tauh))
        U22 <- chol.band(temp, bw) # band choleski decomp.
        U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
        # if desired precision is sigmainv, the matrix in Multi-t=sigmainv*(nu/(nu-2))
        # so, need to correct for degrees of freedom
        cor.df <- (nu/(nu-2))
        U <- U*sqrt(cor.df)
        
        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
        m <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
        # now need to 'correct back'
        # m= cov.matrix*(nu-2)/nu * d, but we want, m=cov.matrix*d
        m <- m*nu/(nu-2)
        
        z <- as.matrix(rnorm(2*N)) # normal(0,1) r.v.s
        y <- backsolve(U, z, upper.tri = TRUE, transpose = FALSE)#y~N(0,B^(-1))
        s <- rchisq(1,nu)
            
        w <- y/sqrt(s/nu) # w ~ MT(0, B^(-1))
        r <- m+w # r ~ MT(m, B^(-1))
        x.new <- r[c(rev.permut, N+rev.permut)] # x ~ MT(A^(-1)b, A^(-1))
        samp <- c(tauh, tauc,x.new)
        logP.val <- logP.rej(samp,data,prior) # done with unpermuted version of sample, data

        # evaluating the multivariate-t density at the sampled value
        logdet <- sum(log(diag(U))) # log(det(Sigma^(-1))^(0.5))
        temp.val <- U%*%(r-m) # U%*%(r-m)
        temp.val <- t(temp.val)%*%temp.val # (r-m)^T B (r-m)
        
        # important: note, in formula below, we have 2N (not N), because
        # dimension of Multi-t is 2N
        logQ.THETA.val <- logdet-0.5*(nu+2*N)*log(1 + (1/nu)*temp.val) 
        logQ.tau.val <- logbivdlt(c(tauh,tauc),mu1,sigma1,t.df1,mu2,sigma2,t.df2)
        logQ.val <- logQ.tau.val+logQ.THETA.val
        
         # alpha((x,n),(xprime,nprime))=(P/K*Q)*q/p
        logalpha <- logP.val-logQ.val-logK+log(temp.par$q)-log(temp.par$p)
#            logprob <- c(logprob,logprob.val)
#        U <- runif(1)

        if (n==0) # if previous state was the atom
          {
            if (log(u2)<= logalpha) # accept sample from h1
              {
#                print("0 -> 1")
                return(list(samp=c(samp,1),logP.prev=logP.val,logQ.prev=logQ.val,numh0=0,numh1=1,numacc=1))
              }
            else # stay at atom
              {
#                print("0 -> 0(prev)")
                return(list(samp=c(rep(0,2*N+2),0),logP.prev=NA,logQ.prev=NA,numh0=0,numh1=1,numacc=0))
              }
          }

        if (n==1) # if previous state was at same temperature (1)
          {
            # need to use calculations about previous sample
            logalpha <- logP.val-logQ.val + logQ.prev - logP.prev
            if (log(u2)<= logalpha)
              {
#                print("1 -> 1")
                return(list(samp=c(samp,1),logP.prev=logP.val,logQ.prev=logQ.val,numh0=0,numh1=1,numacc=1))
              }
            else
              {
#                print("1 -> 1(prev)")
                return(list(samp=c(x.prev,1),logP.prev=logP.prev,logQ.prev=logQ.prev,numh0=0,numh1=1,numacc=0))
              }
          }            
      }
  }

# u1 is unif. r.v. that determines the proposal (whether to move up, down or stay at same level)
# u2 is unif. r.v. that determines acceptance of proposal
RWupdate <- function(m,u1,u2,temp.par=toytemp.par)
  {
    d <- m
    if (u1 < temp.par$p)
      mprime <- m + 1
    else
      if (u1 > (1-temp.par$q))
        mprime <- m - 1
    else
      mprime <- m

    if ((0<=mprime) && (mprime <= temp.par$nstar))
      {
        logval <- logalphatwiddle(m, mprime)
        if (log(u2) < logval)
          d <- mprime
      }

    return(d)
  }

# to get function rt.mod for sampling from t-distribution
# phase 1: to determine taustar (hitting time for Dt process)
# result of this phase :
# (i) get taustar. Z_t is then run from -taustar to 0 (i.e., Z[1] to Z[taustar+1])
# Z[taustar+1] is then Z_0.
# Run Z_0 to Z_S (S arbitrary)
# All Z_i's between Z_1 and Z_S (Z[taustar+2] to Z[taustar+1+S])
# s.t. N[i]==nstar, are the samples of interest
# (ii) keep uniforms, U1_(-taustar) to U1_S, and U2_(-taustar) to U2_S.

phase1 <- function(T=1,data=toydata,temp.par=toytemp.par)
  {
    N <- nrow(data$data)
    
# begin initialization
    nstar <- temp.par$nstar
    t <- T
    D <- temp.par$nstar
    a <- 0 # initial value
    currlen <- T+a+1

    V1 <- rep(0,currlen-1)
    V2 <- rep(0,currlen-1)

    for (i in 1:(currlen-1))
      {
        V1[i] <- runif(1) # need only one set of uniforms for D_(a=0)
        V2[i] <- runif(1)
      }
   
    Dprev <- rep(0,currlen)   # D_(a=0), needs currlen-1 V1s, V2s

    Dprev[1] <- temp.par$nstar # initialize to nstar
    for (i in 2:currlen)
      Dprev[i] <- RWupdate(Dprev[(i-1)],V1[i-1],V2[i-1])
# end initialization
    
    termflag <- 0 # if set to 1, done (condition (A) on pg.8 is satisfied)

    while (!termflag) # until flag for termination is raised (until termflag==1)
      {
        a <- a + 1
        simulflag <- 0 # if set to 1, need to simulate new D_(a) (condition (B) or (C) is satisfied)
        while (!simulflag) # until next simulation (incrementing a by 1)
          {
            currlen <- T+a+1
            V1 <- c(runif(1),V1) # need one new uniform r.v.
            V2 <- c(runif(1),V2) # need one new uniform r.v.
            Dcurr <- rep(NA,currlen) # initialize to missing values
            Dcurr[1] <- temp.par$nstar # first value is nstar
            for (i in 2:currlen)
              {

                Dcurr[i] <- RWupdate(Dcurr[(i-1)],V1[i-1],V2[i-1])
                if (Dcurr[i]==0) # if D 'hits' 0, we are done!!
                  {
                    taustar <- currlen-i # hitting time (-taustar=time before t=0)
                    simulflag <- 1 # to get out of while(!simulflag) loop
                    termflag <- 1  # to get out of while(!termflag) loop
                    break
                  }
                
                if (i==currlen) # t=0
                  {
                    simulflag <- 1 # did not hit 0 before time t=0
                    Dprev <- Dcurr # hold onto current process for next iteration
                    break
                  }

                  if (Dcurr[i]==Dprev[i-1]) # curr. D couples with prev.D
                  #  (=> curr. D is not going anywhere interesting either)
                  {
                    simulflag <- 1 # next iteration: need new D_t
                    Dcurr[i:currlen] <- Dprev[(i-1):(currlen-1)] # copy values from previous r.w.(identical)
                    Dprev <- Dcurr # hold onto current process for next iteration
                    break
                  }
              }
          }
      }
    return(list(taustar=taustar,V1=V1[(currlen-taustar):(currlen-1)],V2=V2[(currlen-taustar):(currlen-1)]))
  }
# phase 2
# given results from phase1, obtain samples of interest
# as soon as Z_0 is produced, we do an accept-reject (based on whether N_0=level of target distr.)
phase2.ind <- function(taustar,V1,V2,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK=logK,data=toydata,prior=toyprior,setup,temp.par=toytemp.par)
{
  if ((length(V1) < taustar) || (length(V2) < taustar))
    {
      cat("phase2: taustar, V1, V2 incompatible\n")
      return(1)
    }

# using taustar and the uniform r.v.s from above to simulate Z_0
  N <- nrow(data$data)
  Zequi <- c(rep(0,(2*N+2)),0) # initialize Zequi to (N+1) zeros for x, followed by 1 zero for n
  logP.prev <- NA # initialize to null since there we start with h_0 distr. which is a distribution on an atom
  logQ.prev <- NA
  Zequi.h0 <- 0 # number of samples produced from h0
  Zequi.h1 <- 0 # number of samples produced from h1

  if (taustar!=0) # if taustar is 0, do not have to run the chain forward to time 0
    for (i in 1:taustar) # run chain forward from t=-taustar to t=0 (taustar no. of steps)
      {
        # need to run chain forward using unifs from phase 1
        newsamp <-  STupdate(Zequi[1:((2*N)+2)],Zequi[(2*N)+3],V1[i],V2[i],logP.prev,logQ.prev,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK,data,prior,temp.par,setup)
        logP.prev <- newsamp$logP.prev
        logQ.prev <- newsamp$logQ.prev

        Zequi <- newsamp$samp
        # keep track of samples from h0, h1 respectively
        Zequi.h0 <- Zequi.h0 + newsamp$numh0
        Zequi.h1 <- Zequi.h1 + newsamp$numh1
      }
# running chain from stationary distribution, Z_0 ~ H to Z_S
  Zstat <- Zequi # initialize to the first sample from H
  if (Zstat[(2*N)+3]==1) # if sample is from distribution of interest
    return(list(samp=Zstat[1:((2*N)+2)], numh0=Zequi.h0, numh1=Zequi.h1))
  else 
    return(list(samp=c(), numh0=Zequi.h0, numh1=Zequi.h1))
}

# function that takes as input: dataset, priors, rejection sampling envelope (with bounds)
# produces independent samples via perfect sampling

# this function that puts phase1 and phase2 together
perfect <- function(NUMSAMP=1000,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK,data=toydata,prior=toyprior,temp.par=toytemp.par)
{
# independent samples from perfect tempering sampler
  samp.perf.ind <- c()
  taustar.perf <- c()
  num.perf <- 0
  numh0 <- 0
  numh1 <- 0

  setup <- create.setup(data) # all the relevant matrices etc. that will be used/reused for sampling
  for (i in 1:NUMSAMP)
    {
      phase1.res <- phase1(1)
      taustar.perf <- c(taustar.perf,phase1.res$taustar)
      phase2.res <- phase2.ind(phase1.res$taustar, phase1.res$V1, phase1.res$V2,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK,data,prior,setup)
      
      if (!is.null(phase2.res$samp)) # if a sample was returned
        {
          num.perf <- num.perf+1
          samp.perf.ind <- rbind(samp.perf.ind,phase2.res$samp)
        }
      numh0 <- numh0+phase2.res$numh0
      numh1 <- numh1+phase2.res$numh1
    }
  # samp.perf are the perfect samples
  # num.perf is the number of perfect samples obtained (number of rows of samp.perf)
  # totsamp is the total number of samples produced in the simulated tempering chains
  # numh0 is number of samples produced from h0 distr.
  # numh1 is number of samples produced from h1 distr.
  return(list(samp=samp.perf.ind,num.perf=num.perf,numh0=numh0,numh1=numh1,totsamp=sum(taustar.perf),NUMSAMP=NUMSAMP,acc=num.perf/numh1,taustar.perf=taustar.perf))
}

# simulated tempering algorithm, using STupdate above
simtemp <- function(NUMSAMP=1000,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK,data=toydata,prior=toyprior,temp.par=toytemp.par)
  {
    N <- nrow(data$data)
    currsamp <- c(rep(0,(2*N+2)),0) # initialize simulated tempering chain
    logP.prev <- NA # initialize to null since there we start with h_0 distr. which is a distribution on an atom
    logQ.prev <- NA
    numh0 <- 0 # number of proposals produced from h0
    numh1 <- 0 # number of proposals produced from h1
    numacc <- 0 # number of accepted proposals
    setup <- create.setup(data) # all the relevant matrices etc. that will be used/reused for sampling
    samp <- c()
    
    for (i in 1:NUMSAMP) 
      {
        # need to run chain forward using unifs from phase 1
 #(x.prev,n,u1,u2,logP.prev,logQ.prev,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK=logK,data=toydata,prior=toyprior,temp.par=toytemp.par,setup)
        newsamp <-  STupdate(currsamp[1:((2*N)+2)],currsamp[(2*N)+3],runif(1),runif(1),logP.prev,logQ.prev,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK,data,prior,temp.par,setup)
        logP.prev <- newsamp$logP.prev
        logQ.prev <- newsamp$logQ.prev

        currsamp <- newsamp$samp
        # keep track of samples from h0, h1 respectively
        numh0 <- numh0 + newsamp$numh0
        numh1 <- numh1 + newsamp$numh1
        numacc <- numacc + newsamp$numacc

        if (currsamp[(2*N)+3]==1) # if sample is from distribution of interest
          samp <- rbind(samp,as.numeric(currsamp[1:((2*N)+2)])) # Apr.26,2003
#          samp <- rbind(samp,currsamp[1:((2*N)+2)])

#        cat(currsamp[(2*N)+3],"\n")
      }

    return(list(samp=samp, numh0=numh0,numh1=numh1,NUMSAMP=NUMSAMP,numacc=numacc))
  }

# block MCMC algorithm using an independence chain with the same proposals as in the
# simulated tempering algorithm
blockMCMC <- function(NUMSAMP=1000,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,logK,data=toydata,prior=toyprior)
  {
    # setup
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    # find permutation that minimizes bandwidth: done only once
    source("band.min.R")
    band.min.Q <- band.min(Q)
    permut <- band.min.Q$permut
    rev.permut <- band.min.Q$origpermut
    bw <- band.min.Q$bandwd
    
    # all of the following vectors and matrices are permuted according to above
    Y <- data$data$Y[permut]
    E <- data$data$E[permut]
    etahat <- log(Y/E)
    Vinv <- diag(Y)
    Q <- Q[permut, permut]
    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
    d <- transfmuhat
    Zeros <- matrix(0, N, N)
    nu <- multt.df # for convenience
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # end setup
    acc <- 0 # number of times a proposal was accepted
    MC.samp <- matrix(0, NUMSAMP, 2*N+2)
    for (i in 1:NUMSAMP)
      {
                                        # sample from envelope
        taucand <- c(rlt(1,meanlog=mu1,sdlog=sigma1,t.df1),
                     rlt(1,meanlog=mu2,sdlog=sigma2,t.df2))
        tauh <- taucand[1]
        tauc <- taucand[2]
        # fast choleski decomposition of Sigmainv (precision matrix)
        U11 <- diag(sqrt(Y+tauh))
        U12 <- diag(Y/sqrt(Y+tauh))

        temp <- (Vinv+tauc*Q) - diag(Y^2/(Y+tauh))
        U22 <- chol.band(temp, bw) # band choleski decomp.
        U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
        # if desired precision is sigmainv, the matrix in Multi-t=sigmainv*(nu/(nu-2))
        # so, need to correct for degrees of freedom
        cor.df <- (nu/(nu-2))
        U <- U*sqrt(cor.df)
        
        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
        m <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
        # now need to 'correct back'
        # m= cov.matrix*(nu-2)/nu * d, but we want, m=cov.matrix*d
        m <- m*nu/(nu-2)
        
        z <- as.matrix(rnorm(2*N)) # normal(0,1) r.v.s
        y <- backsolve(U, z, upper.tri = TRUE, transpose = FALSE)#y~N(0,B^(-1))
        s <- rchisq(1,nu)
        w <- y/sqrt(s/nu) # w ~ MT(0, B^(-1))
        r <- m+w # r ~ MT(m, B^(-1))
        x.new <- r[c(rev.permut, N+rev.permut)] # x ~ MT(A^(-1)b, A^(-1))
        samp <- c(tauh, tauc,x.new)
        logP.val <- logP.rej(samp,data,prior)

        # evaluating the multivariate-t density at the sampled value
        logdet <- sum(log(diag(U))) # log(det(Sigma^(-1))^(0.5))
        temp.val <- U%*%(r-m) # U%*%(r-m)
        temp.val <- t(temp.val)%*%temp.val # (r-m)^T B (r-m)
        
        # important: note, in formula below, we have 2N (not N), because
        # dimension of Multi-t is 2N
        logQ.THETA.val <- logdet-0.5*(nu+2*N)*log(1 + (1/nu)*temp.val) 
        logQ.tau.val <- logbivdlt(c(tauh,tauc),mu1,sigma1,t.df1,mu2,sigma2,t.df2)
        logQ.val <- logQ.tau.val+logQ.THETA.val
        if (i==1) # first sample generated
          {
            logalpha <- 0 # alpha=1 (always accept)
            logP.prev <- logP.val
            logQ.prev <- logQ.val
          }
        else
          logalpha <- logP.val-logQ.val+logQ.prev-logP.prev
        
        U <- runif(1)
        if (log(U)<= logalpha) # accept sample
          {
            MC.samp[i,] <- samp
            logP.prev <- logP.val
            logQ.prev <- logQ.val
            acc <- acc+1
          }
        else
          MC.samp[i,] <- MC.samp[(i-1),] # previous sample
      }

    return(list(samp=MC.samp, acc=acc))
  }

# function to see how the samples from the envelope behave
sampleenv <- function(B=1000,multt.df,mu.tau1,sigma.tau1,tau.t.df1,mu.tau2,sigma.tau2,tau.t.df2,data=toydata,prior=toyprior)
{
  Vinv <- diag(data$data$Y)
  Y <- data$data$Y
  V <- diag(1/data$data$Y)
  Q <- data$Q
  N <- nrow(data$data)
  M <- N-1
  Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
  numadj <- sum(Q==-1)/2
  A <- matrix(0,numadj,N)
  muhat <- c(log(data$data$Y/data$data$E),rep(0,N+numadj))
  
  k <- 0
  for (i in 1:N)
    for (j in i:N)
      if (Q[i,j]==-1)
        {
          k <- k+1
          A[k,i] <- -1
          A[k,j] <- 1
        }
#    print(A)
# create design matrix
  X <- rbind(cbind(Id,Id),
             cbind(-1*Id,matrix(0,N,N)), 
             cbind(matrix(0,numadj,N),A))

  allsamp <- c()
  for (i in 1:B)
    {
        # sample from envelope
      taucand <- c(rlt(1,meanlog=mu.tau1,sdlog=sigma.tau1,tau.t.df1),
                   rlt(1,meanlog=mu.tau2,sdlog=sigma.tau2,tau.t.df2))
      tauh <- taucand[1]
      tauc <- taucand[2]
      
      gammainv.mat <- diag(c(data$data$Y, rep(tauh,N), rep(tauc,numadj)))
      
#      var.mat <- try(solve(t(X)%*%gammainv.mat%*%X)) # Apr.2,2002: changed to 'try'
      Cmat <- rbind(cbind((Vinv+tauh*Id), Vinv),
                    cbind(Vinv, (Vinv+tauc*Q)))
      A22 <- solve(Vinv + tauc*Q - diag(Y*(1/(Y+tauh))*Y))
      temp <- solve(Vinv+tauc*Q)
      A11 <- solve(Vinv+tauh*Id - Vinv%*%temp%*%Vinv)
      A12 <- -diag(1/(Y+tauh))%*%Vinv%*%A22
      A21 <- t(A12)
      
      var.mat <- rbind(cbind(A11, A12),cbind(A21,A22))
      
     if (is.null(class(var.mat))) # only proceed if no error, else generate a new sample
        {
          mu.mat <- var.mat%*%(t(X)%*%gammainv.mat%*%muhat)
                                        #            cat("tauh,tauc=",tauh,tauc,"\n")
        
          samp <- c(tauh,tauc,rmultt(mu.mat,var.mat,multt.df))
                                        #            cat("before logprob.val\n")
        }

      allsamp <- rbind(allsamp,samp)
    }
}
