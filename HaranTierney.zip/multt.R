# var.mat is the var-covariance matrix for the multivariate-t
# it is NOT the matrix that is in the distribution function
# The variance of multi-t is Sigma*(n/(n-2)) where
# Sigma is the matrix in the d.fn. and n is the chisq d.o.f.
# To get the right cov. matrix, we multiply Sigma by (n-2)/n

rmultt <- function(mn,var.mat,chisq.df)
  {
    if (is.matrix(mn))
      {
        dim1 <- dim(mn)[1]
        dim2 <- dim(mn)[2]
      }

    if (is.vector(mn))
      {
        dim1 <- length(mn)
        dim2 <- 1
      }
    
    if (dim2!=1)
      {
        cat("rmultt: input mean is not a vector\n")
        return(1)
      }

    if ( (dim1!=(dim(var.mat)[1])) || (dim1!=(dim(var.mat)[2])))
      {
        cat("rmultt: mean and variance have incompatible dimensions\n")
        return(1)
      }

    norm.indep <- rnorm(dim1) # generates dim1 N(0,1)'s
#    norm.indep <- rep(1,dim1) #test
    chisq.var <- rchisq(1,chisq.df)
#    chisq.var <- 1 #test
    t.indep <- norm.indep/(sqrt(chisq.var/chisq.df)) 

    var.mat <- var.mat*((chisq.df-2)/chisq.df)
    var.chol <- chol(var.mat)# chol(M) gives R s.t. t(R)xR=M
#    norm.var <- t(var.chol)%*%norm.indep + mn
    t.var <- t(var.chol)%*%t.indep + mn

#    cat("y=",t(var.chol)%*%norm.indep,"\n")
#    cat("premult\n")
#    print(t(var.chol))
#    print(norm.indep)
    return(t.var)
  }

# using the library MASS:     mvrnorm(mu=, Sigma)
rmultt.MASS <- function(mn,var.mat,chisq.df)
  {
    library(MASS)
    var.mat <- var.mat*((chisq.df-2)/chisq.df)    
    MN <- mvrnorm(mu=rep(0,length(mn)), Sigma=var.mat)
    chisq.var <- rchisq(1,chisq.df)

    MT <- MN/sqrt(chisq.var/chisq.df) + mn

    return(MT)
  }
    
# test
#test.mn <- c(1,2,3)
#test.var <- matrix(0,3,3)
#test.var[1,] <- c(1,0,0)
#test.var[2,] <- c(0,4,0)
#test.var[3,] <- c(0,0,9)
#test.multt <- rmultt(test.mn, test.var,50)
#test.dmultt <- dmultt(test.multt,test.mn,test.var,50)
  
# obtain the log(density) of the multivariate-t at eval.pts
# given the mean, var-covariance matrix and deg. of freedom of
# chisquare r.v. by which the r.v. was divided.
# NOTE: var.mat is not the SIGMA in the density of multi-t, but the actual variance

# new version, with error handling for logdet function
logdmultt <- function(eval.pts,mn,var.mat,chisq.df)
  {
    nu <- chisq.df
    if (is.matrix(mn))
      {
        dim1 <- dim(mn)[1]
        dim2 <- dim(mn)[2]
      }

    if (is.vector(mn))
      {
        dim1 <- length(mn)
        dim2 <- 1
      }
    
    if (dim2!=1)
      {
        cat("dmultt: input mean is not a vector\n")
        return(1)
      }

    if ( (dim1!=(dim(var.mat)[1])) || (dim1!=(dim(var.mat)[2])))
      {
        cat("dmultt: mean and variance have incompatible dimensions\n")
        return(1)
      }

    k <- dim1
    var.mat <- var.mat*((nu-2)/nu) # adjustment due to d. of freedom

#    consts <- log(gamma((nu+k)/2))-(k/2)*log(pi*nu) - log(gamma(nu/2))
    C <- solve(var.mat)
    differ<- eval.pts-mn
    piece1 <- try(logdet(C))

    if (is.null(class(piece1))) # no error
      piece1 <- 0.5*piece1
    else
      stop("logdmultt:error with logdet\n")

#    cat("logdet(old)=",piece1,"\n")
#    cat("quad(old)=",sum(differ*(C%*%differ)),"\n")
#    cat("differ(old)\n")
#    print(differ)
#    print(eval.pts)
#    print(mn)
    temp <- 1 + (1/nu)*sum(differ*(C%*%differ))
    piece2 <- -((nu+k)/2)*log(temp)

#    cat("IMP(old)=",piece2,"\n")
#    cat("IMP(old)=",-0.5*(nu+k)*log(1 + (1/nu)*sum(differ*(C%*%differ))),"\n")
    t.var <- piece1+piece2

#    cat("piece1=",piece1,"\n")
#    cat("piece2=",piece2,"\n")
    
    return(t.var)
  }

# another version of logdmultt that takes in the
# inverse of the covariance matrix, rather than
# the covariance matrix itself
logdmultt.prec <- function(eval.pts,mn,prec.mat,chisq.df)
  {
    nu <- chisq.df
    if (is.matrix(mn))
      {
        dim1 <- dim(mn)[1]
        dim2 <- dim(mn)[2]
      }

    if (is.vector(mn))
      {
        dim1 <- length(mn)
        dim2 <- 1
      }
    
    if (dim2!=1)
      {
        cat("dmultt: input mean is not a vector\n")
        return(1)
      }

    if ( (dim1!=(dim(prec.mat)[1])) || (dim1!=(dim(prec.mat)[2])))
      {
        cat("dmultt: mean and variance have incompatible dimensions\n")
        return(1)
      }

    k <- dim1
#    var.mat <- var.mat*((nu-2)/nu) # adjustment due to d. of freedom
    prec.mat <- prec.mat*(nu/(nu-2)) # adjustment due to d. of freedom

#    consts <- log(gamma((nu+k)/2))-(k/2)*log(pi*nu) - log(gamma(nu/2))
#    C <- solve(var.mat) # ONLY DIFFERENCE FROM logdmultt.r
    C <- prec.mat #Oct.20th: only change
    differ<- eval.pts-mn
    piece1 <- try(logdet(C))

    if (is.null(class(piece1))) # no error
      piece1 <- 0.5*piece1
    else
      stop("logdmultt:error with logdet\n")

#    print(C)
    temp <- 1 + (1/nu)*sum(differ*(C%*%differ))
    piece2 <- -((nu+k)/2)*log(temp)

    t.var <- piece1+piece2

#    cat("logdet (old)=",piece1,"\n")
#    cat("piece2=",piece2,"\n")
    
    return(t.var)
  }

#test.mn <- c(1,2,3)
#test.var <- matrix(0,3,3)
#test.var[1,] <- c(25,0,0)
#test.var[2,] <- c(0,16,0)
#test.var[3,] <- c(0,0,1)
#test.multt <- matrix(0,1000,3)
#test.dmultt <- rep(0,1000)
#for (i in 1:1000)
#{
#  test.multt[i,] <- rmultt(test.mn, test.var,50)
#  test.dmultt[i] <- exp(logdmultt(test.multt[i,],test.mn,test.var,50))
#}
