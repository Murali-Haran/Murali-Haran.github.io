#exactdir = "/home6/muh10/exact/"
if (!exists("exactdir"))
  exactdir <- "/home/mharan/exact" # location of directory with functions for exact sampling
# read in functions for multivariate-t generation and density
source(paste(exactdir,"/multt.R",sep=""))
# read in functions for log-t generation and density
source(paste(exactdir,"/lt.R",sep=""))
# read in functions for band matrix operations
source(paste(exactdir,"/band.min.R",sep=""))
source(paste(exactdir,"/band.chol.R",sep=""))

source("poissonmrf.R") # functions for MCMC for Poisson MRF

options(show.error.messages = TRUE)

readSimpleData <-  function(name) {
    data <- read.table(paste(name, ".data.R", sep=""));
    names(data) <- c("Y","E")
    N <- nrow(data)
    Q <- matrix(scan(paste(name,".Q",sep="")), N, N)
    list(data=data, Q=Q)
}

create.setup <- function(data)
  {
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    # find permutation that minimizes bandwidth: done only once
    band.min.Q <- band.min(Q)
    permut <- band.min.Q$permut
    rev.permut <- band.min.Q$origpermut
    bw <- band.min.Q$bandwd
    
    # all of the following vectors and matrices are permuted according to above
    Y <- data$data$Y[permut]
    E <- data$data$E[permut]
    etahat <- log(Y/E)
    Vinv <- diag(Y)
    Q <- Q[permut, permut]
    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
    d <- transfmuhat
    Zeros <- matrix(0, N, N)

    setup <- list(Q=Q,N=N,Vinv=Vinv,numadj=numadj,Y=Y,E=E,d=d,Zeros=Zeros,Id=Id,permut=permut,rev.permut=rev.permut,bw=bw)
#    setup <- list(X=X,numadj=numadj,muhat=muhat,N=N)

    return(setup)
  }

## sequential sampler to produce a single draw from proposal distribution
## if evaluatedens=TRUE, also evaluate the proposal density at proposed value
## note: proposal density includes all the normalizing constants
seqsamp <- function(proppars,setup,evaluatedens=TRUE)
  {
    multtdf <- proppars$multtdf
    muh <- proppars$muh
    sigmah <- proppars$sigmah
    muc <- proppars$muc
    sigmac <- proppars$sigmac
    tdfh <- proppars$tdfh
    tdfc <- proppars$tdfc

    ## sample from log-t densities
    tauh <- rlt(1,meanlog=muh,sdlog=sigmah,tdfh)
    tauc <- rlt(1,meanlog=muc,sdlog=sigmac,tdfc)
    ## sample from appropriate multivariate-t, conditional on log-t
    ## setup <- create.setup(data=toydata)
    ## get matrices etc. with everything already permuted
    Q <- setup$Q
    Y <- setup$Y
    d <- setup$d
    Zeros <- setup$Zeros
    Id <- setup$Id
    permut <- setup$permut
    rev.permut <- setup$rev.permut
    Vinv <- setup$Vinv
    bw <- setup$bw
    N <- setup$N
    nu <- multtdf # for convenience
    ## end setup
        
    ## fast choleski decomposition of Sigmainv (precision matrix)
    U11 <- diag(sqrt(Y+tauh))
    U12 <- diag(Y/sqrt(Y+tauh))
    
    temp <- (Vinv+tauc*Q) - diag(Y^2/(Y+tauh))
    U22 <- chol.band(temp, bw) # band choleski decomp.
    U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
    ## if desired precision is sigmainv, the matrix in Multi-t=sigmainv*(nu/(nu-2))
    ## so, need to correct for degrees of freedom
    cor.df <- (nu/(nu-2))
    U <- U*sqrt(cor.df)
        
    v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
    m <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
    ## now need to 'correct back'
    ## m= cov.matrix*(nu-2)/nu * d, but we want, m=cov.matrix*d
    m <- m*nu/(nu-2)
    
    z <- as.matrix(rnorm(2*N)) # normal(0,1) r.v.s
    y <- backsolve(U, z, upper.tri = TRUE, transpose = FALSE)#y~N(0,B^(-1))
    s <- rchisq(1,nu)
    
    w <- y/sqrt(s/nu) # w ~ MT(0, B^(-1))
    r <- m+w # r ~ MT(m, B^(-1))
    x.new <- r[c(rev.permut, N+rev.permut)] # x ~ MT(A^(-1)b, A^(-1))
    samp <- c(tauh, tauc,x.new)

    if (any(apply(as.matrix(samp),1,is.na)))
      cat("NA in sample\n")
    ## DONE SAMPLING

    if (evaluatedens) # compute logR at proposal (do this right away for efficiency reasons)
      {
        ## evaluating KERNEL of multivariate-t density at the sampled value
        logdet <- sum(log(diag(U))) # log(det(Sigma^(-1))^(0.5))
        temp.val <- U%*%(r-m) # U%*%(r-m)
        temp.val <- t(temp.val)%*%temp.val # (r-m)^T B (r-m)
##        const.val <- log(gamma((nu+2*N)/2))-log(gamma(nu/2))-(2*N/2)*log(nu*pi) July 7th change
        const.val <- lgamma((nu+2*N)/2)-lgamma(nu/2)-(2*N/2)*log(nu*pi) # July 7th: use lgamma for numerical stability
        logR.THETA.val <- logdet-0.5*(nu+2*N)*log(1 + (1/nu)*temp.val)+const.val
        logR.tauh.val <- logdlt.nor(tauh,muh,sigmah,tdfh)
        logR.tauc.val <- logdlt.nor(tauc,muc,sigmac,tdfc)
        logR.val <- logR.tauh.val+logR.tauc.val+logR.THETA.val
      }
    else
      logR.val <- FALSE 

    return(list(samp=samp,logR.val=logR.val))
 }

## rejection sampling algorithm using sparse matrix operations
## if changebound=TRUE, rerun rejection sampler with new bounds until no out-of-sample bounds are found
## rej <- rejsamp(1000,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-Inf,changebound=TRUE)
## rej <- rejsamp(1000,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-2866.039,changebound=FALSE)
## if FIXEDNUM is TRUE, run until NUMITER samples are obtained
rejsamp <- function(NUMITER,proppars,coord,data,prior,logbound,changebound=FALSE,MAXTRY=10,FIXEDNUM=FALSE,outfile)
  {
    setup <- create.setup(data)
    ## initialize output file
    write("",outfile) #accept modified May 1, 2007
    
    MAXNUMITER <- 100000000 # a very large number
    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)
    nummonitor=length(coord)
    
    newlogbound <- logbound # initialize (in case there are bound violations)
    numtry <- 1
    runflag <- TRUE # as long as TRUE, keep running the while loop
    if (FIXEDNUM)
      {
        NUMSAMP <- NUMITER # number of samples wanted is set to NUMITER
        NUMITER <- MAXNUMITER # number of iterations is set to large number
      }
    while (runflag && (numtry<MAXTRY))# if changebound is TRUE, need to check that there are no bound violations, and that maximum number of attempts has not been exceeded
      {
        cat("attempt ",numtry," with log(bound)=",newlogbound,"\n")
##        samp <- c() # initialize matrix of samples modified May 1, 2007
        numacc <- 0
        notinenv <- 0# initialize
        for (i in 1:NUMITER)
          {
            prop <- seqsamp(proppars,setup)
            logP.val <- logP.rej(prop$samp,data,prior)
            logR.val <- prop$logR.val
            logratio <- logP.val-logR.val
            U <- runif(1)
            if (logratio>logbound)  # keep track of bound violations
              {
                notinenv <- notinenv+1
                if (logratio>newlogbound)
                  newlogbound <- logratio # keep largest bound violation
                if (changebound) ## exit at first bound violation
                  {
                    logbound <- newlogbound
                    break
                  }
              }
            if (log(U)<(logratio-logbound)) # accept-reject step
              {
                numacc <- numacc+1
                ##samp <- rbind(samp,prop$samp[coord]) #accept # modified May 1, 2007
                write(prop$samp[coord],outfile,ncolumns=nummonitor,append=TRUE) #accept modified May 1, 2007
                if (FIXEDNUM) # if exit after fixed number of samples obtained
                  if (numacc==NUMSAMP) # done, exit
                    return(list(accrate=numacc/i,notinenv=notinenv,newlogbound=newlogbound)) #modified May 1, 2007
##                    return(list(samp=samp,acc=numacc/i,notinenv=notinenv,newlogbound=newlogbound)) modified May 1, 2007
              }
          }
        cat("num samples generated=",i,",numacc=",numacc,"\n")
        numtry <- numtry+1
        if ((!changebound) || (notinenv==0)) # if the bounds are not to be updated, or if no samples were out of bounds
          runflag <- FALSE # quit while loop

      }
    
    if (notinenv>0)
      cat("WARNING: rejection ratio bounds violated\n")
    if (numacc==0) # no samples returned
      cat("WARNING: no samples were accepted\n")
##    return(list(samp=as.matrix(samp),acc=numacc/NUMSAMP,notinenv=notinenv,newlogbound=newlogbound))
##    return(list(samp=samp,acc=numacc/i,notinenv=notinenv,newlogbound=newlogbound))  # May 1, 2007
    return(list(accrate=numacc/i,notinenv=notinenv,newlogbound=newlogbound)) # May 1, 2007
  }

## same as above, except write to file every WRITEEVERY th sample (no rbind operations)
## write to screen every PRINTEVERYth iteration
rejsamp.file <- function(NUMITER,proppars,coord,data,prior,logbound,changebound=FALSE,MAXTRY=10,FIXEDNUM=FALSE,WRITEEVERY=100,outfile="rejout",PRINTEVERY=1000)
  {
    MAXNUMITER <- 100000000 # a very large number
    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)
    
    setup <- create.setup(data)
    newlogbound <- logbound # initialize (in case there are bound violations)
    numtry <- 1
    runflag <- TRUE # as long as TRUE, keep running the while loop
    if (FIXEDNUM)
      {
        NUMSAMP <- NUMITER # number of samples wanted is set to NUMITER
        NUMITER <- MAXNUMITER # number of iterations is set to large number
      }
    while (runflag && (numtry<MAXTRY))# if changebound is TRUE, need to check that there are no bound violations, and that maximum number of attempts has not been exceeded
      {
        cat("attempt ",numtry," with log(bound)=",newlogbound,"\n")
        samp <- c() # initialize matrix of samples
        numacc <- 0
        notinenv <- 0# initialize
        for (i in 1:NUMITER)
          {
            prop <- seqsamp(proppars,setup)
            logP.val <- logP.rej(prop$samp,data,prior)
            logR.val <- prop$logR.val
            logratio <- logP.val-logR.val
            U <- runif(1)
            if (logratio>logbound)  # keep track of bound violations
              {
                notinenv <- notinenv+1
                if (logratio>newlogbound)
                  newlogbound <- logratio # keep largest bound violation
                if (changebound) ## exit at first bound violation
                  {
                    logbound <- newlogbound
                    break
                  }
              }
            if (log(U)<(logratio-logbound)) # accept-reject step
              {
                numacc <- numacc+1
                samp <- rbind(samp,prop$samp[coord]) #accept
                ## new: Sep28,2004
                if (numacc %% WRITEEVERY) # every WRITEEVERYth accepted sample, write to file
                  {
                    write.table(samp,outfile,append=TRUE,row.names=FALSE,col.names=FALSE)
                    samp <- c() # delete previous samples
                  }
                if (FIXEDNUM) # if exit after fixed number of samples obtained
                  if (numacc==NUMSAMP) # done, exit
                    return(list(samp=samp,acc=numacc/i,notinenv=notinenv,newlogbound=newlogbound))
              }
            ## periodic output

            if ((i %% PRINTEVERY)==0) # every PRINTEVERYth iteration
              {
                cat("Iteration=",i,"numacc=",numacc,"\n")
                dput(list(samp=samp,acc=numacc/i,notinenv=notinenv,newlogbound=newlogbound),"rej.temp")
              }
          }
        cat("num samples generated=",i,",numacc=",numacc,"\n")
        numtry <- numtry+1
        if ((!changebound) || (notinenv==0)) # if the bounds are not to be updated, or if no samples were out of bounds
          runflag <- FALSE # quit while loop

      }
    
    if (notinenv>0)
      cat("WARNING: rejection ratio bounds violated\n")
    if (numacc==0) # no samples returned
      cat("WARNING: no samples were accepted\n")
##    return(list(samp=as.matrix(samp),acc=numacc/NUMSAMP,notinenv=notinenv,newlogbound=newlogbound))
    return(list(samp=samp,acc=numacc/i,notinenv=notinenv,newlogbound=newlogbound))
  }
logP.rej <- function(samp,data=toydata,prior=toyprior)
  {
    alphah <- prior$alphah
    betah <- prior$betah
    alphac <- prior$alphac
    betac <- prior$betac

    N <- nrow(data$data)
    M <- N-1
    Y <- data$data$Y
    E <- data$data$E
    Q <- data$Q
   
    tauh <- samp[1]
    tauc <- samp[2]
    theta <- samp[3:(2+N)]
    phi <- samp[(2+N+1):(2+2*N)]

    piece1 <- sum((theta+phi)*Y-E*exp(theta+phi))
    piece2 <- (N/2+alphah-1)*log(tauh)-tauh/betah+(M/2+alphac-1)*log(tauc)-tauc/betac
    piece3 <- -0.5*tauh*sum(theta^2) - 0.5*tauc*t(phi)%*%Q%*%phi

    return(piece1+piece2+piece3)
  }

logQ.rej <- function(samp,mu.mat,var.mat,multt.df,data=toydata,prior=toyprior)
{
    alphah <- prior$alphah
    betah <- prior$betah
    alphac <- prior$alphac
    betac <- prior$betac

    N <- nrow(data$data)
    M <- N-1
    Y <- data$data$Y
    E <- data$data$E
    Q <- data$Q
    Vinv <- diag(data$data$Y)
    V <- diag(1/data$data$Y)
    muhat <- log(data$data$Y/data$data$E)
    Id <- diag(rep(1,N)) # NxN Identity matrix

    tauh <- samp[1]
    tauc <- samp[2]
    theta <- samp[3:(2+N)]
    phi <- samp[(2+N+1):(2+2*N)]
    THETA <- samp[3:(2+2*N)]

    A <- solve(Id+(tauc/tauh)*Q+tauc*V%*%Q)%*%muhat
    THETAHAT <- rbind((tauc/tauh)*Q%*%A, A)
    Cmat <- rbind(cbind((Vinv+tauh*Id), Vinv),
                  cbind(Vinv, (Vinv+tauc*Q)))
    Dmat <- cbind(-2*t(muhat)%*%Vinv,-2*t(muhat)%*%Vinv)
      
    piece1 <- try(logdmultt(THETA,mu.mat,var.mat,multt.df))#-0.5*logdet(var.mat)-t(THETA-mu.mat)%*%solve(var.mat)%*%(THETA-mu.mat)
    if (!(is.null(class(piece1)))) # if there is an error with logdmultt computation
      stop("logQ.rej:logdmultt error\n")
    
    piece2 <- (N/2+alphah-1)*log(tauh)-tauh/betah+(M/2+alphac-1)*log(tauc)-tauc/betac

    piece3 <- try(logdet(tauh*Vinv+tauc*Vinv%*%Q+tauh*tauc*Q))
    if (is.null(class(piece3)))
      piece3 <- -0.5*piece3
    else  # if there is an error with logdet computation
      stop("logQ.rej:logdet error\n")
    
    piece4 <- -0.5*t(THETAHAT)%*%Cmat%*%THETAHAT+Dmat%*%THETAHAT

    return(piece1+piece2+piece3+piece4)
}

# block MCMC algorithm using an independence chain with the same proposals as in the
# simulated tempering algorithm
# simple version
# writevery = when to write to file
blockMCMC <- function(NUMSAMP=100,proppars,coord=NA,data,prior,outfile,writeevery=10)
  {
    writecount=0 # counter that tells you when to write to file
    setup <- create.setup(data)
    # end setup
    acc <- 0 # number of times a proposal was accepted
    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)
    nummonitor=length(coord)
    MCsamp <- matrix(NA,writeevery, nummonitor)  # fixed
    
    ## generate first sample from envelope
    prop <- seqsamp(proppars,setup) # generate a new proposal
    samp <- prop$samp
    i <- 1 # number of samples generated
    write(samp[coord],outfile,ncolumns = nummonitor) # write first sample to file
    
    ## initialize 'previous' values
    logR.prev <- prop$logR.val
    logP.prev <- logP.rej(samp,data,prior)
    prevsamp <- samp[coord]
    
    while (i<=NUMSAMP) 
      {
        prop <- seqsamp(proppars,setup) # generate a new proposal
        samp <- prop$samp
        logR.val <- prop$logR.val
        logP.val <- logP.rej(samp,data,prior)

        U <- runif(1)

        logalpha <- logP.val-logR.val+logR.prev-logP.prev
        
        if (log(U)<= logalpha) # accept sample
          {
            logP.prev <- logP.val
            logR.prev <- logR.val
            acc <- acc+1
            prevsamp <- samp[coord]
            writecount=writecount + 1 # increment counter
#            cat("dim(MCsamp)=",dim(MCsamp),"length(samp[coord])=",length(samp[coord]),"\n")
            MCsamp[writecount,] <- samp[coord] # June 21st: only keep select few parameters
            
            if (writecount==writeevery) # time to write to file
              {
                write(MCsamp,outfile,append=TRUE,ncolumns = nummonitor) 
                writecount=0 # reset counter
              }
          }
        else # reject sample
          {
            writecount=writecount + 1 # increment counter
#            cat("dim(MCsamp)=",dim(MCsamp),"length(samp[coord])=",length(samp[coord]),"length(prevsamp)=",length(prevsamp),"\n")
            MCsamp[writecount,]= prevsamp # previous sample is new state of chain, leave prevsamp untouched
            
            if (writecount==writeevery) # time to write to file
              {
                write(MCsamp,outfile,append=TRUE,ncolumns = nummonitor)
                writecount=0 # reset counter
              }
          }
        
        i <- i+1 # always increment number of samples drawn/proposed
      }

    if (writecount!=0) # some samples have not been written out yet
      write(MCsamp[1:writecount,],outfile,append=TRUE,ncolumns = nummonitor)
    
    ## accrate = number of proposals accepted by Met-Hastings
#    return(list(samp=MCsamp, accrate=acc/i, totsamp=i))## Feb.18,2004
    return(list(accrate=acc/i, totsamp=i))## Feb.18,2004
  }

# block MCMC algorithm using an independence chain with the same proposals as in the
# simulated tempering algorithm
# this version does regenerative simulation
## Sep.27, 2004: change so it can now start at a particular starting value (not just random draw from proposal)
blockMCMC.reg <- function(NUMREG=100,proppars,coord=NA,data,prior,logC,MAXSAMP,WHENPRINT=1000,startval=NA,logR.startval=NA)
  {
    # Feb.18, 2004: for regenerative simulation
##    logC <- -108.5140 # c=1, constant for regenerative simulation
    regpts <- c() # initialize list of regeneration points
    # setup
    setup <- create.setup(data)
    # end setup
    acc <- 0 # number of times a proposal was accepted
    MCsamp <- c() # matrix(0, NUMREG, 2*setup$N+2)

    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)

    numregpts <- 0 # number of regeneration points
    maxlogregprob <- -Inf # initialize
    sumregprob <- 0 # initialize
    i <- 1 # number of sample generated 
    while ((numregpts<NUMREG)&&(i<=MAXSAMP)) # until desired number of regeneration points obtained
      {
        prop <- seqsamp(proppars,setup)
        samp <- prop$samp
        logR.val <- prop$logR.val
        logP.val <- logP.rej(samp,data,prior)

        if (i==1) # first sample generated
          {
            if (is.na(startval[1])) # no starting value provided: Sep.27, 2004
              {
                logalpha <- 0 # alpha=1: always accept the sample from proposal distribution (above)
                logP.prev <- logP.val
                logR.prev <- logR.val
              }
            else # use starting value provided: Sep.27, 2004
              {
                logalpha <- 0  # (starting value is 'accepted', ignore proposal this time)
                logR.val <- logR.startval # user provides this value (usually from previous simulation)
                logP.val <- logP.rej(startval,data,prior)
                logR.prev <- logR.val
                logP.prev <- logP.val
              }
          }
        else
          logalpha <- logP.val-logR.val+logR.prev-logP.prev
        U <- runif(1)
        if (log(U)<= logalpha) # accept sample
          {
            # code for regenerative simulation
            #Feb.18, 2004: generate Bernoulli with appropriate regeneration probability
            logwy <- logP.val-logR.val
            logwx <- logP.prev-logR.prev
##            cat("logval=",logP.val,logR.val,logP.prev,logR.prev,logwy,logwx,"\n")
##            cat(logwx,logwy,logC,"\n")
            if ((logwx>logC) && (logwy>logC))
              logregprob <- max(logC-logwx, logC-logwy)
            else
              if ((logwx<logC) && (logwy<logC))
                logregprob <- max(logwx-logC, logwy-logC)
              else
                logregprob <- 0

            if (logregprob>maxlogregprob)
              maxlogregprob <- logregprob
            
            regbernoulli <- rbinom(1,1,exp(logregprob))
            sumregprob <- sumregprob+exp(logregprob)
##            cat("logregprob=",logregprob,"\n")
            if (regbernoulli) # if regeneration point
              {
                regpts <- c(regpts, i)
                numregpts <- numregpts+1
                if ((numregpts %% WHENPRINT)==0)
                  {
                    cat("numregpts=",numregpts,"\n") # print every 10th regeneration
                    dput(list(samp=MCsamp, accrate=acc/i, avgregprob=sumregprob/acc, regpts=regpts, totsamp=i, avgtour=i/NUMREG),"TEMP.blockMCMC.reg")
                  }            
              }
            # end regeneration stuff
            MCsamp <- rbind(MCsamp,samp[coord]) #June 21st: only keep select few parameters
            logP.prev <- logP.val
            logR.prev <- logR.val
            acc <- acc+1
          }
        else
          MCsamp <- rbind(MCsamp,MCsamp[(i-1),]) # previous sample

        i <- i+1 # always increment number of samples drawn/proposed
      }

    if (numregpts<NUMREG)
      {
        cat("exit without enough regenerations (",numregpts,"vs",NUMREG,")\n")
        cat("max. log(prob.) of regeneration was ",maxlogregprob,"\n")
        cat("number of samples was ",i,"\n")
      }
    ## accrate = number of proposals accepted by Met-Hastings
    ## avgregprob= average probability of regeneration, given an acceptance of the Met-Hastings proposal
    ## regpts=list of regeneration points (where they occur)
    ## avgtour=average length of a tour (between regeneration points)
    return(list(samp=MCsamp, accrate=acc/i, avgregprob=sumregprob/acc, regpts=regpts, totsamp=i, avgtour=i/NUMREG, lastsamp=samp,lastlogR.val=logR.val))## Sep.27,2004
  }

## another version of blockMCMC.
## this version runs until a fixed number of samples is returned, but still keeps track of whether regenerations have occurred
## and when they have occurred
blockMCMC.reg2 <- function(NUMSAMP=100,proppars,coord=NA,data,prior,logC,WHENPRINT=1000,startval=NA,logR.startval=NA)
  {
    # Feb.18, 2004: for regenerative simulation
##    logC <- -108.5140 # c=1, constant for regenerative simulation
    regpts <- c() # initialize list of regeneration points
    # setup
    setup <- create.setup(data)
    # end setup
    acc <- 0 # number of times a proposal was accepted
    MCsamp <- c() # matrix(0, NUMREG, 2*setup$N+2)

    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)

    numregpts <- 0 # number of regeneration points
    maxlogregprob <- -Inf # initialize
    sumregprob <- 0 # initialize
    i <- 1 # number of sample generated 
    while (i<=NUMSAMP) # until desired number of samples are returned
      {
        prop <- seqsamp(proppars,setup)
        samp <- prop$samp
        logR.val <- prop$logR.val
        logP.val <- logP.rej(samp,data,prior)

        if (i==1) # first sample generated
          {
            if (is.na(startval[1])) # no starting value provided: Sep.27, 2004
              {
                logalpha <- 0 # alpha=1: always accept the sample from proposal distribution (above)
                logP.prev <- logP.val
                logR.prev <- logR.val
              }
            else # use starting value provided: Sep.27, 2004
              {
                logalpha <- 0  # (starting value is 'accepted', ignore proposal this time)
                logR.val <- logR.startval # user provides this value (usually from previous simulation)
                logP.val <- logP.rej(startval,data,prior)
                logR.prev <- logR.val
                logP.prev <- logP.val
              }
          }
        else
          logalpha <- logP.val-logR.val+logR.prev-logP.prev
        U <- runif(1)
        if (log(U)<= logalpha) # accept sample
          {
            # code for regenerative simulation
            #Feb.18, 2004: generate Bernoulli with appropriate regeneration probability
            logwy <- logP.val-logR.val
            logwx <- logP.prev-logR.prev
##            cat("logval=",logP.val,logR.val,logP.prev,logR.prev,logwy,logwx,"\n")
##            cat(logwx,logwy,logC,"\n")
            if ((logwx>logC) && (logwy>logC))
              logregprob <- max(logC-logwx, logC-logwy)
            else
              if ((logwx<logC) && (logwy<logC))
                logregprob <- max(logwx-logC, logwy-logC)
              else
                logregprob <- 0

            if (logregprob>maxlogregprob)
              maxlogregprob <- logregprob
            
            regbernoulli <- rbinom(1,1,exp(logregprob))
            sumregprob <- sumregprob+exp(logregprob)
##            cat("logregprob=",logregprob,"\n")
            if (regbernoulli) # if regeneration point
              {
                regpts <- c(regpts, i)
                numregpts <- numregpts+1
                if ((numregpts %% WHENPRINT)==0)
                  {
                    cat("numregpts=",numregpts,"\n") # print every 10th regeneration
                    dput(list(samp=MCsamp, accrate=acc/i, avgregprob=sumregprob/acc, regpts=regpts, totsamp=i, avgtour=i/numregpts),"TEMP.blockMCMC.reg")
                  }            
              }
            # end regeneration stuff
            MCsamp <- rbind(MCsamp,samp[coord]) #June 21st: only keep select few parameters
            logP.prev <- logP.val
            logR.prev <- logR.val
            acc <- acc+1
          }
        else
          MCsamp <- rbind(MCsamp,MCsamp[(i-1),]) # previous sample

        i <- i+1 # always increment number of samples drawn/proposed
      }

    printmsg <- 0 # don't print anything (speed things up)
    if (printmsg)
      if (numregpts<1)
        {
          cat("no regenerations \n")
          cat("max. log(prob.) of regeneration was ",maxlogregprob,"\n")
          cat("number of samples was ",i,"\n")
        }
    ## accrate = number of proposals accepted by Met-Hastings
    ## avgregprob= average probability of regeneration, given an acceptance of the Met-Hastings proposal
    ## regpts=list of regeneration points (where they occur)
    ## avgtour=average length of a tour (between regeneration points)
    return(list(samp=MCsamp, accrate=acc/i, avgregprob=sumregprob/acc, regpts=regpts, totsamp=i, avgtour=i/numregpts, lastsamp=samp,lastlogR.val=logR.val))## Sep.27,2004
  }
# function to see how the samples from the envelope behave
sampleenv <- function(B=1000,proppars,data)
{
  setup <- create.setup(data)
  samp <- matrix(NA, B, 2*setup$N+2)
  
  for (i in 1:B)
    samp[i,] <- seqsamp(proppars,setup)$samp

  return(samp)
}


## OLD FUNCTIONS (not used any more)
# the tau's were sampled from a bivariate-LT(mu1,sigma1,df1,mu2,sigma2,df2) (log-t)
# then, the (theta,phi)s are sampled conditional on the taus from a Multi-t
# a SINGLE accept-reject step is done to sample from the correct distribution
sampleTHETA.lt2 <- function(NUMSAMP,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,K2,data=toydata,prior=toyprior,changeK=F)
  {
    Vinv <- diag(data$data$Y)
    V <- diag(1/data$data$Y)
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    etahat <- log(data$data$Y/data$data$E)
    muhat <- c(etahat,rep(0,N+numadj))
    Y <- data$data$Y
    
#    print(X)      
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
        
    while (notenv) # while there is at least one sample produced outside the envelope
      {
        notenv <- 0 # assume envelope works ok at the start
        numacc <- 0
        logprob <- c()
        
        samp.EXACT <- c() # to hold accepted samples

        allsamp <- c()

#        taulength <- dim(tau)[1] # number of (tauh,tauc) pairs

        for (i in 1:NUMSAMP)
          {
            taucand <- c(rlt(1,meanlog=mu1,sdlog=sigma1,t.df1),
                       rlt(1,meanlog=mu2,sdlog=sigma2,t.df2))
            tauh <- taucand[1]
            tauc <- taucand[2]

            # Dec.8th version (faster than above since only one matrix inversion)
            A22 <- solve(Vinv + tauc*Q - diag(Y*Y/(Y+tauh))) # use sparse matrix alg. for this
            A12 <- -diag(Y/(Y+tauh))%*%A22
            A11 <- diag(1/(Y+tauh))-A12%*%diag(Y/(Y+tauh))
            A21 <- t(A12)
            
            var.mat <- rbind(cbind(A11, A12),cbind(A21,A22))
            
            if (is.null(class(var.mat))) # only proceed if no error, else generate a new sample
              {
                mu.mat <- var.mat%*%transfmuhat
                samp <- c(tauh,tauc,rmultt(mu.mat,var.mat,multt.df))
                logP.val <- logP.rej(samp,data,prior)
                logQ.val <- try(logQ.rej.onestage(samp,mu.mat,var.mat,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,data,prior))
                logprob.val <- logP.val-logQ.val-K2
                logprob <- c(logprob,logprob.val)
                if (logprob.val>0)
                  {
                    cat("not in envelope (log-scale prob=",logprob.val,")\n")
                    notenv <- notenv + 1
                    notenv <- 1
                    if (changeK) # if we are to fix upper bound, quit this loop immediately
                      break
                  }
                else
                  {
                    if (log(runif(1))<logprob.val)
                      {
                        samp.EXACT <- rbind(samp.EXACT,samp)
                        numacc <- numacc+1
                      }
                  }
              }
          }
        
        if (!changeK) # if empirical bound is not to be updated
          {
            if (notenv)
              {
                cat("warning:",notenv,"sample(s) generated outside envelope\n")
              }
            notenv <- 0 # pretend no samples were generated outside the envelope, exit loop
          }
            
        if (notenv) # if at least one sample was generated outside envelope(and bound is to be updated)
          {
            K2 <- K2 + max(logprob) # increase the constant until an envelope is found
            numit <- numit+1
            cat("new K2=",K2,"\n")
          }
        
        cat("numit=",numit,"\n")
      }
    if (numacc==0)
      cat("zero acceptance rate: decrease the value of K2 (try K2=",max(logprob)+K2," for instance)\n")
    return(list(samples=samp.EXACT,acc=numacc,notenv=notenv,NUMSAMP=NUMSAMP,K2=K2,numit=numit,accrate=numacc/NUMSAMP,logprob=logprob))
  }

model2stats <- function(out,getMCse=TRUE)
{
  if (!is.null(out$samples))
    samp <- out$samples
  else
    samp <- out
  
  meanlist <- apply(samp,2,mean)
  sdlist <- apply(samp,2,sd)
  N <- (length(samp[1,])-2)/2
  NUMSAMP <- dim(samp)[1]

  stat.mat <- cbind(meanlist[3:(2*N+2)], sdlist[3:(2*N+2)]) #only thetas,phis
  dimnames(stat.mat) <- c(list(c(paste("theta",1:N,sep="_"), paste("phi",1:N,sep="_")), c("mean","sd")))

  print(stat.mat)
  cat("tau_h",meanlist[1]," ",sdlist[1],"\n")
  cat("tau_c",meanlist[2]," ",sdlist[2],"\n")

  if (!is.null(out$samples))
    cat("number of samples=",out$acc,",","acc rate=",out$acc/out$NUMSAMP,"\n")
  else
    cat("number of samples=",dim(out)[1],"\n")

  if (getMCse)
    {
      mean.MCse <- sdlist/sqrt(NUMSAMP)
      print(sdlist)
      print(sqrt(NUMSAMP))
      sd.MCse <- sqrt(apply(apply(samp,2,function(x) x^2), 2,  sd)/sqrt(NUMSAMP)) # s.dev. of X^2 for each parameter (column) 
    }

  if (getMCse)
    return(list(means=meanlist,sds=sdlist,mean.MCse=mean.MCse,sd.MCse=sd.MCse))
  else
    return(list(means=meanlist,sds=sdlist))
}

# input: samp (matrix of samples, each column corresponding to some
# variable, and rows corresponding to different samples)
# output: ESS (effective sample sizes)
# using initial monotone positive sequence estimator (Geyer, 1992)
stats.MCMC <- function(samp,ind,times=-1)
  {
    MAXLAG <- 50 # never compute more than lag MAXLAG
    if (times>0) # if timing provided, compute ES/s
      calcESpersec<- TRUE
    else
      calcESpersec<- FALSE
    
    ESS <- rep(0,length(ind))
    AC1 <- rep(0,length(ind))
    AC5 <- rep(0,length(ind))
    AC10 <- rep(0,length(ind))
    
    NUMSAMP <- dim(samp)[1] # number of rows
    auto.time <- rep(0,length(ind))
               
    for (i in ind) # for each parameter of interest
      {
        acfs <- acf(samp[,i], type="correlation",plot=FALSE,lag.max=MAXLAG)$acf[,,1]

        Gammas <- acfs[1: (length(acfs)-1)] + acfs[2:length(acfs)]

        k <- 1
        while ((k<length(Gammas)) && (Gammas[k+1]>0) && (Gammas[k]>=Gammas[k+1]))
          k <- k+1

        auto.time[i] <- sum(acfs[1:k])
        ESS[i] <- NUMSAMP/auto.time[i]
        AC1[i] <- acfs[2]
        AC5[i] <- acfs[6]
        AC10[i] <- acfs[11]
      }

    if (calcESpersec)
      return(list(ESS=ESS,auto=auto.time,ESpersec=ESS/times,AC1=AC1,AC5=AC5,AC10,AC10))
    else
      return(list(ESS=ESS,auto=auto.time,AC1=AC1,AC5=AC5,AC10=AC10))
  }
