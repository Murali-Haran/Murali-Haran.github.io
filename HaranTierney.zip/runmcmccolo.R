exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R")
#source("~/public_html/batchmeans.R")
colo.data <- readSimpleData(paste(exactdir,"/colocancer",sep=""))
colo.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
colo.proppars <- list(multtdf=50,muh=5.68,sigmah=0.7,muc=4.82,sigmac=0.7,tdfh=50,tdfc=50)
colo.logbound <- -4329.682
colo.mixprob <- list(logpi0=log(1),logpi1=-colo.logbound)
colo.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

############################################################################################################
## run block MCMC (independence chain)
############################################################################################################
set.seed(1)
#mcmcout=blockMCMC(NUMSAMP=100000,proppars=colo.proppars,coord=c(1,2,9,96,17,104,58,145),data=colo.data,prior=colo.prior,outfile="mcmcsamp",writeevery=100)
mcmcrun=blockMCMC(NUMSAMP=100000,proppars=colo.proppars,coord=c(1,2,9,96,17,104,58,145),data=colo.data,prior=colo.prior,outfile="mcmcout.colo",writeevery=1)
write(mcmcrun$accrate,"mcmcacc.colo")
