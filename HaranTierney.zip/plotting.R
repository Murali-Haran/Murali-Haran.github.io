# functions for sampling from Model 2
# model with two variance components

# read in functions for multivariate-t generation and density
source("multt.R")
# read in functions for log-t generation and density
source("lt.R")

options(show.error.messages = TRUE)

## July 6th
## function to plot the profile of the approximate log posterior
## marginal distribution of the precision parameters
## note: this is being plotted for log-transformed tauh, tauc
plotlogprof <- function(xs,data,prior,plot=TRUE)
  {
    setup <- create.setup(data)
    return(ys)
  }
                           
#toyprior <- list(alphah=1,betah=100,alphac=1, betac=50)
#toyprior <- list(alphah=0.25, betah=0.00025, alphac=0.25,betac=0.0005) #vague priors
# Plot 2-d picture of approximate log-transformed marginal distributions
# fast version using sparse matrix algorithms
#showLogMargins.fast <- function(xs,ys,color="red",twoviews=T,data=toydata,prior=toyprior)
showLogMargins.fast <- function(xs,ys,color="red",data,prior,twoviews=T)
{
  # do the setup below just once
  # everything will be computed in the transformed space
  # (more efficient and identical final result)
  Q <- data$Q
  N <- nrow(data$data)
  M <- N-1
  Id <- diag(rep(1,N)) # NxN Identity matrix
                                        # adjacency matrix
  numadj <- sum(Q==-1)/2

  alphah <- prior$alphah
  alphac <- prior$alphac
  betah <- prior$betah
  betac <- prior$betac
  
  source("band.min.R")
  band.min.Q <- band.min(Q)
  permut <- band.min.Q$permut
  rev.permut <- band.min.Q$origpermut
  bw <- band.min.Q$bandwd

                                        # all of the following vectors and matrices are permuted according to above
  Y <- data$data$Y[permut]
  E <- data$data$E[permut]
  etahat <- log(Y/E)
  Vinv <- diag(Y)
  Q <- Q[permut, permut]
  transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
#  d <- transfmuhat # this is the same as "-0.5*D" in the paper
  D <- -2*t(transfmuhat)
  Zeros <- matrix(0, N, N)

#  source("/HOME/grads/mharan/exact/sparse/band.chol.R") # for band choleski
  source("/home/mharan/exact/band.chol.R") # for band choleski
  # end of setup
  
  z <- matrix(0,length(xs),length(ys))
  
  for (i in 1:dim(z)[1])
    for (j in 1:dim(z)[2])
      {
        exptauh <- exp(xs[i])
        exptauc <- exp(ys[j])
                                        # fast choleski decomposition of Sigmainv (precision matrix)
        U11 <- diag(sqrt(Y+exptauh))
        U12 <- diag(Y/sqrt(Y+exptauh))
        
        temp <- (Vinv+exptauc*Q) - diag(Y^2/(Y+exptauh))
        U22 <- chol.band(temp, bw) # band choleski decomp.
        U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
#        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
        v <- backsolve(U, t(D)*-0.5, upper.tri = TRUE, transpose = TRUE)
        xhat <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d

        piece1 <- (N/2+alphah-1)*log(exptauh)+(M/2+alphac-1)*log(exptauc) - exptauh/betah - exptauc/betac
        logdet <- -1*sum(log(diag(U))) # -1*log(det(Sigma^(-1))^(0.5))=log(det(Sigma)^(0.5))

#        sigmainv <- rbind(cbind(Vinv+exptauh*Id, Vinv), cbind(Vinv, Vinv + exptauc*Q))
        temp.val <- U%*%xhat
        piece2 <- -0.5*t(temp.val)%*%temp.val # -0.5*t(xhat)%*%C%*%xhat
        piece3 <- -0.5*D%*%xhat # -0.5*D%*%xhat
        z[i,j] <- piece1+logdet+piece2 + piece3 + xs[i]+ys[j] # last two pieces added due to Jacobian of log-trans
      }

  if (twoviews)
    {
      par(mfrow=c(1,2))
      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
      
      persp(xs,ys,exp(z-max(z)), col=color,theta=90,xlab="log(tauh)",ylab="log(tauc)",zlab="")
    }
  else
    {
      par(mfrow=c(1,1))
      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
    }
  return(list(xs=xs,ys=ys,zs=exp(z-max(z))))
}

# faster version of showLogMargins.profile
# with a major difference: no optimizing - use mean of other variable instead
# of maximizing w.r.t. the otther variable
# input: xs (list of tauhs), ys (list of taucs)
# show profiles of approximate marginal dist (transformed)
# (log(tauh),log(tauc))|Y
showLogMargins.profile.fast <- function(xs,ys,start.val=2,data=toydata,prior=toyprior)
{
  xs.prof <- rep(0,length(xs))
  ys.prof <- rep(0,length(ys))

  xs.mean <- mean(xs)
  ys.mean <- mean(ys)

  # do the setup below just once
  # everything will be computed in the transformed space
  # (more efficient and identical final result)
  Q <- data$Q
  N <- nrow(data$data)
  M <- N-1
  Id <- diag(rep(1,N)) # NxN Identity matrix
                                        # adjacency matrix
  numadj <- sum(Q==-1)/2

  alphah <- prior$alphah
  alphac <- prior$alphac
  betah <- prior$betah
  betac <- prior$betac
  
  source("band.min.R")
  band.min.Q <- band.min(Q)
  permut <- band.min.Q$permut
  rev.permut <- band.min.Q$origpermut
  bw <- band.min.Q$bandwd

                                        # all of the following vectors and matrices are permuted according to above
  Y <- data$data$Y[permut]
  E <- data$data$E[permut]
  etahat <- log(Y/E)
  Vinv <- diag(Y)
  Q <- Q[permut, permut]
  transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
#  d <- transfmuhat # this is the same as "-0.5*D" in the paper
  D <- -2*t(transfmuhat)
  Zeros <- matrix(0, N, N)

  source("/HOME/grads/mharan/exact/sparse/band.chol.R") # for band choleski
  # end of setup
  
  # for each element in xs (tauhs), plug in mean of tauc
  for (i in 1:length(xs))
    {
      exptauh <- exp(xs[i])
      exptauc <- exp(ys.mean)
                                        # fast choleski decomposition of Sigmainv (precision matrix)
      U11 <- diag(sqrt(Y+exptauh))
      U12 <- diag(Y/sqrt(Y+exptauh))
      
      temp <- (Vinv+exptauc*Q) - diag(Y^2/(Y+exptauh))
      U22 <- chol.band(temp, bw) # band choleski decomp.
      U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
                                        #        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
      v <- backsolve(U, t(D)*-0.5, upper.tri = TRUE, transpose = TRUE)
      xhat <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
      
      piece1 <- (N/2+alphah-1)*log(exptauh)+(M/2+alphac-1)*log(exptauc) - exptauh/betah - exptauc/betac
      logdet <- -1*sum(log(diag(U))) # -1*log(det(Sigma^(-1))^(0.5))=log(det(Sigma)^(0.5))
      
      temp.val <- U%*%xhat
      piece2 <- -0.5*t(temp.val)%*%temp.val # -0.5*t(xhat)%*%C%*%xhat
      piece3 <- -0.5*D%*%xhat # -0.5*D%*%xhat
      
      xs.prof[i] <- piece1+logdet+piece2 + piece3 + xs[i]+ys.mean
    }

  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      exptauh <- exp(xs.mean)
      exptauc <- exp(ys[i])
                                        # fast choleski decomposition of Sigmainv (precision matrix)
      U11 <- diag(sqrt(Y+exptauh))
      U12 <- diag(Y/sqrt(Y+exptauh))
      
      temp <- (Vinv+exptauc*Q) - diag(Y^2/(Y+exptauh))
      U22 <- chol.band(temp, bw) # band choleski decomp.
      U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
                                        #        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
      v <- backsolve(U, t(D)*-0.5, upper.tri = TRUE, transpose = TRUE)
      xhat <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
      
      piece1 <- (N/2+alphah-1)*log(exptauh)+(M/2+alphac-1)*log(exptauc) - exptauh/betah - exptauc/betac
      logdet <- -1*sum(log(diag(U))) # -1*log(det(Sigma^(-1))^(0.5))=log(det(Sigma)^(0.5))
      
      temp.val <- U%*%xhat
      piece2 <- -0.5*t(temp.val)%*%temp.val # -0.5*t(xhat)%*%C%*%xhat
      piece3 <- -0.5*D%*%xhat # -0.5*D%*%xhat

      ys.prof[i] <- piece1+logdet+piece2 + piece3 + xs.mean+ys[i]
    }

  xs <- xs[!is.na(xs.prof)]
  xs.prof <- xs.prof[!is.na(xs.prof)]

  ys <- ys[!is.na(ys.prof)]
  ys.prof <- ys.prof[!is.na(ys.prof)]
  
  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green")

  return(list(xs=xs,ys=ys,
              xs.prof=exp(xs.prof-max(xs.prof)),
              ys.prof=exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

# log of determinant of a matrix
logdet <- function(mymat)
  {
    eigenval <- eigen(mymat,only.values=TRUE)

    # bullet-proofing the code by using try (to protect against complex eigen vals)
    pos.real <- try(all(eigenval$values > 0)) # if all eigen vals are positive
    if (is.null(class(pos.real))) #no error above, i.e. eigen values are real(?)
      {
        if (pos.real) # if all eigen values are positive AND real
          {
            logdetval <- sum(log(eigenval$values))
            if (logdetval==Inf)
              cat("logdet is Inf\n")
            if (logdetval==(-Inf))
              cat("logdet is -Inf\n")
            
            return(logdetval)
          }
        else
          stop("logdet:non-pos eigen value\n") # error detected => non-pos eigen val
      }
    else
      stop("logdet:non-real eigen value\n") # error detected => complex eigen val
  }

## 2008 modification
logdet=function(mymat)
  {
    detres=determinant(mymat)
    if (detres$sign<0)
      {
        cat("hello !!!\n")
        stop("logdet:logdet error (sign of log determinant is",detres$sign,")\n")
      }
    else
      return(detres$modulus)
  }

# approximate log marginal distribution of (tauh,tauc)
logH <- function(tauh,tauc,data=toydata,prior=toyprior)
{
  alphah <- prior$alphah
  betah <- prior$betah
  alphac <- prior$alphac
  betac <- prior$betac
  Vinv <- diag(data$data$Y)
  muhat <- log(data$data$Y/data$data$E)
  Q <- data$Q
  N <- nrow(data$data)
  M<-N-1
  Id <- diag(rep(1,N))
  V <- diag(1/data$data$Y)

#  cat("tauh,tauc,(tauc/tauh)=",tauh,tauc,tauc/tauh,"\n")
  A <- solve(Id+(tauc/tauh)*Q+tauc*V%*%Q)%*%muhat
  thetahat <- rbind((tauc/tauh)*Q%*%A, A)
  Cmat <- rbind(cbind((Vinv+tauh*Id), Vinv),
             cbind(Vinv, (Vinv+tauc*Q)))
  Dmat <- cbind(-2*t(muhat)%*%Vinv,-2*t(muhat)%*%Vinv)
  
  piece1 <- (N/2+alphah-1)*log(tauh)+(M/2+alphac-1)*log(tauc)-tauh/betah-tauc/betac

#  print(tauh*Vinv+tauc*Vinv%*%Q+tauh*tauc*Q)
#  piece2 <- try(logdet(tauh*Vinv+tauc*Vinv%*%Q+tauh*tauc*Q))
  piece2 <- logdet(tauh*Vinv+tauc*Vinv%*%Q+tauh*tauc*Q)
  piece2 <- -0.5*piece2
  piece3 <- -0.5*(t(thetahat)%*%Cmat%*%thetahat+Dmat%*%thetahat)

  return(piece1+piece2+piece3)
}

logH.log <- function(tauh,tauc,data=toydata,prior=toyprior)
{
  exptauh <- exp(tauh)
  exptauc <- exp(tauc)

  piece1 <- logH(exptauh,exptauc,data,prior)
  piece4 <- tauh+tauc
  return(piece1+piece4)
}

# density of envelope (log-t bivariate)
logbivdlt <- function(tau,mu1,sigma1,t1.df,mu2,sigma2,t2.df)
  {
    tauh <- tau[1]
    tauc <- tau[2]
    
    logdlt(tauh,mu1,sigma1,t1.df)+ logdlt(tauc,mu2,sigma2,t2.df)
  }

# density of envelope (t bivariate)
logbivdt <- function(tau,mu1,sigma1,t1.df,mu2,sigma2,t2.df)
  {
    tauh <- tau[1]
    tauc <- tau[2]
    
    logdt.mod(tauh,mu1,sigma1,t1.df)+ logdt.mod(tauc,mu2,sigma2,t2.df)
  }

# input: xs (list of tauhs), ys (list of taucs)
showMargins <- function(xs,ys,color="red") {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

  z <- matrix(0,length(xs),length(ys))
  for (i in 1:dim(z)[1])
    for (j in 1:dim(z)[2])
        z[i,j] <- logH(c(xs[i],ys[j]))
  par(mfrow=c(2,1))
  persp(xs,ys,exp(z-max(z)), col=color)
  persp(xs,ys,exp(z-max(z)), col=color,theta=90)
#  persp(xs,ys,exp(z-max(z)), col=color,theta=180)
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

# input: xs (list of tauhs), ys (list of taucs)
# show marginal distribution of log-transformed params
showLogMargins <- function(xs,ys,data,prior,color="red",twoviews=T) {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

  z <- matrix(0,length(xs),length(ys))
  for (i in 1:dim(z)[1])
    for (j in 1:dim(z)[2])
      z[i,j] <- logH.log(xs[i],ys[j],data,prior)

  if (twoviews)
    {
      par(mfrow=c(1,2))
#      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")      
#      persp(xs,ys,exp(z-max(z)), col=color,theta=90,xlab="log(tauh)",ylab="log(tauc)",zlab="")
      persp(xs,ys,exp(z-max(z)), col=color,theta=90,xlab=expression(log(tau[c])),ylab=expression(log(tau[c])),zlab="")
      par(mfrow=c(1,1))
    }
  else
    {
      par(mfrow=c(1,1))
#      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
      persp(xs,ys,exp(z-max(z)), col=color,xlab=expression(log(tau[c])),ylab=expression(log(tau[c])),zlab="")
    }
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
  return(list(xs=xs,ys=ys,zs=exp(z-max(z))))
}

# input: xs (list of tauhs), ys (list of taucs)
# show envelope for log(tauh),log(tauc)|Y
showLogEnv <- function(xs,ys,mu1,sigma1,t.df1,mu2,sigma2,t.df2,color="red")
  {
    z <- matrix(0,length(xs),length(ys))
    for (i in 1:dim(z)[1])
      for (j in 1:dim(z)[2])
        z[i,j] <- logbivdlt(taucand,mu1,sigma1,t.df1,mu2,sigma2,t.df2)

    par(mfrow=c(2,1))
    persp(xs,ys,exp(z-max(z)), col=color)
    
    persp(xs,ys,exp(z-max(z)), col=color,theta=90)
  }

# input: xs (list of tauhs), ys (list of taucs)
# show profiles of approximate marginal dist (transformed)
# (log(tauh),log(tauc))|Y
showLogMargins.profile <- function(xs,ys,data,prior,start.val=2) {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

#  start.val <- 2 # this may need to be changed
  
  xs.prof <- rep(0,length(xs))
  ys.prof <- rep(0,length(ys))

  # for each element in xs (tauhs), maximize over tauc
  for (i in 1:length(xs))
    {
      opt <- try(optim(start.val, function(y) logH.log(xs[i],y,data,prior), control=list(fnscale=-1), method="BFGS"))
      if (is.null(class(opt))) # no error
        xs.prof[i] <- opt$value
      else
        xs.prof[i] <- NA
    }

  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      opt <- try(optim(start.val, function(x) logH.log(x,ys[i],data,prior), control=list(fnscale=-1), method="BFGS"))
      if (is.null(class(opt))) # no error
        ys.prof[i] <- opt$value
      else
        ys.prof[i] <- NA
#      print(opt)
#      cat("\n\n")
    }

  xs <- xs[!is.na(xs.prof)]
  xs.prof <- xs.prof[!is.na(xs.prof)]

  ys <- ys[!is.na(ys.prof)]
  ys.prof <- ys.prof[!is.na(ys.prof)]
  
  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green")

  return(list(xs=xs,ys=ys,
              xs.prof=exp(xs.prof-max(xs.prof)),
              ys.prof=exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

#library(integrate) # Jan.25, 2004

# obtain approx. marginal distributions for tauh, tauc resp.
# by integrating out the other parameter (tauc, tauh resp.)
# Note: this is on log scale (log(tauh), log(tauc))
showLogMargins.integ <- function(xs,ys) {

  xs.prof <- rep(0,length(xs))
  ys.prof <- rep(0,length(ys))

  # for each element in xs (tauhs), maximize over tauc
  for (i in 1:length(xs))
    {
      int.val <- adapt(1, lower=c(min(ys)), upper=c(max(ys)), minpts=100,maxpts=500,functn=function(y) logH.log(xs[i],y), eps=0.001)$value
      xs.prof[i] <- int.val
    }
  
  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      int.val <- adapt(1, lower=c(min(ys)), upper=c(max(ys)), minpts=100,maxpts=500,functn=function(x) logH.log(x,ys[i]), eps=0.001)$value
      ys.prof[i] <- int.val
    }
  
  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green")

  return(list(x=exp(xs.prof-max(xs.prof)),
              y=exp(ys.prof-max(ys.prof))))

#  return(rbind(exp(xs.prof-max(xs.prof)),
#               exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

### Feb, 2008

# input: xs (list of tauhs), ys (list of taucs)
# show profiles of approximate marginal dist (transformed)
# (log(tauh),log(tauc))|Y
# crude version: just look at values between min and max of xs and ys
showLogMargins.profile.crude <- function(xs,ys,xbounds,ybounds,data,prior,numevals=25) {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

#  start.val <- 2 # this may need to be changed
  
  xs.prof <- rep(-Inf,length(xs))
  ys.prof <- rep(-Inf,length(ys))

  xtryvals=seq(xbounds[1],xbounds[2],length=numevals)
  ytryvals=seq(ybounds[1],ybounds[2],length=numevals)
  # for each element in xs (tauhs), maximize over tauc
  for (i in 1:length(xs))
    {
      for (yval in ytryvals)
        {
          profval=logH.log(xs[i],yval,data,prior)
          if (profval>xs.prof[i]) # found a new maximum
            xs.prof[i]=profval
        }
    }

  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      for (xval in xtryvals)
        {
          profval=logH.log(xval,ys[i],data,prior)
          if (profval>ys.prof[i]) # found a new maximum
            ys.prof[i]=profval
        }
    }

  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue",type="l")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green",type="l")
  par(mfrow=c(1,1)) # reset
  
  return(list(xs=xs,ys=ys,
              xs.prof=exp(xs.prof-max(xs.prof)),
              ys.prof=exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

## a sparse matrix version of the above
showLogMargins.profile.crude.fast <- function(xs,ys,xbounds,ybounds,data,prior,numevals=25) {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

#  start.val <- 2 # this may need to be changed
  
  xs.prof <- rep(-Inf,length(xs))
  ys.prof <- rep(-Inf,length(ys))

  xtryvals=seq(xbounds[1],xbounds[2],length=numevals)
  ytryvals=seq(ybounds[1],ybounds[2],length=numevals)

  # do the setup below just once
  # everything will be computed in the transformed space
  # (more efficient and identical final result)
  Q <- data$Q
  N <- nrow(data$data)
  M <- N-1
  Id <- diag(rep(1,N)) # NxN Identity matrix
                                        # adjacency matrix
  numadj <- sum(Q==-1)/2

  alphah <- prior$alphah
  alphac <- prior$alphac
  betah <- prior$betah
  betac <- prior$betac
  
  source("band.min.R")
  band.min.Q <- band.min(Q)
  permut <- band.min.Q$permut
  rev.permut <- band.min.Q$origpermut
  bw <- band.min.Q$bandwd

                                        # all of the following vectors and matrices are permuted according to above
  Y <- data$data$Y[permut]
  E <- data$data$E[permut]
  etahat <- log(Y/E)
  Vinv <- diag(Y)
  Q <- Q[permut, permut]
  transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
#  d <- transfmuhat # this is the same as "-0.5*D" in the paper
  D <- -2*t(transfmuhat)
  Zeros <- matrix(0, N, N)

  source("/home/mharan/exact/band.chol.R") # for band choleski
  # end of setup

  ## for each element in xs (tauhs), maximize over tauc
  for (i in 1:length(xs))
    {
      for (yval in ytryvals)
        {
          profval=logH.log(xs[i],yval,data,prior)
          if (profval>xs.prof[i]) # found a new maximum
            xs.prof[i]=profval
        }
    }

  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      for (xval in xtryvals)
        {
          profval=logH.log(xval,ys[i],data,prior)
          if (profval>ys.prof[i]) # found a new maximum
            ys.prof[i]=profval
        }
    }

  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue",type="l")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green",type="l")
  par(mfrow=c(1,1)) # reset
  
  return(list(xs=xs,ys=ys,
              xs.prof=exp(xs.prof-max(xs.prof)),
              ys.prof=exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}
