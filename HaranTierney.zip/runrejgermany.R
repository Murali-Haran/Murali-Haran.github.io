exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R")
germany.data <- readSimpleData(paste(exactdir,"/germany",sep=""))
germany.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
germany.proppars <- list(multtdf=50,muh=5,sigmah=0.45,muc=2.9,sigmac=0.2,tdfh=50,tdfc=50)
germany.logbound <- -14581.31 # -14583.24
germany.mixprob <- list(logpi0=log(1),logpi1=-germany.logbound)
germany.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

############################################################################################################
## run rejection sampler
############################################################################################################
set.seed(1)
#rej <- rejsamp(100000,germany.proppars,coord=c(1,2,9,96,17,104,58,145),germany.data,germany.prior,logbound=-2866.039,changebound=FALSE,MAXTRY=10,FIXEDNUM=FALSE,outfile="rejsamp")
rej <- rejsamp(50000,germany.proppars,coord=c(1,2,9,96,17,104,58,145),germany.data,germany.prior,logbound=germany.logbound,changebound=FALSE,MAXTRY=10,FIXEDNUM=FALSE,outfile="germanyrejout") # NOTE: CHANGEBOUND IS FALSE HERE!!!!
write(rej$accrate,"germanyrejacc")
write(rej$newlogbound,"germanylogbound")
