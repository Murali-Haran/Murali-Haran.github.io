source("../multreg/mcse.R")
colo.data <- readSimpleData(paste(exactdir,"colocancer",sep=""))
colo.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
colo.proppars <- list(multtdf=50,muh=5.68,sigmah=0.7,muc=4.82,sigmac=0.7,tdfh=50,tdfc=50)
colo.logbound <- -4329.682
colo.mixprob <- list(logpi0=log(1),logpi1=-colo.logbound)

NUMSAMP <- 1000

## run until 100 samples returned
rej.time <- system.time(rej <- rejsamp(NUMSAMP,colo.proppars,coord=c(1,2,9,96,17,104,58,145),colo.data,colo.prior,logbound=colo.logbound,changebound=FALSE,FIXEDNUM=TRUE))
dput(rej,"colo.rej")
dput(rej.time,"colo.rej.time")

colo.temp.par <- list(p=0.5,q=0.5,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,colo.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),colo.data,colo.prior,colo.temp.par,colo.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"colo.perf1")
dput(perf.time,"colo.perf1.time")

colo.temp.par <- list(p=0.6,q=0.4,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,colo.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),colo.data,colo.prior,colo.temp.par,colo.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"colo.perf2")
dput(perf.time,"colo.perf2.time")

colo.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,colo.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),colo.data,colo.prior,colo.temp.par,colo.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"colo.perf3")
dput(perf.time,"colo.perf3.time")

colo.temp.par <- list(p=0.4,q=0.6,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,colo.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),colo.data,colo.prior,colo.temp.par,colo.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"colo.perf5")
dput(perf.time,"colo.perf5.time")
#> perf$acc
#[1] 0.04659832

#colo.temp.par <- list(p=0.8,q=0.2,nstar=1)  # for simulated tempering/perfect sampling
#perf.time <- system.time(perf <- perftemp(NUMSAMP,colo.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),colo.data,colo.prior,colo.temp.par,colo.mixprob,FIXEDNUM=TRUE))
###[1] 136.43   1.53 142.71   0.00   0.00
#dput(perf,"colo.perf4")
#dput(perf.time,"colo.perf4.time")

#colo.temp.par <- list(p=0.9,q=0.1,nstar=1)  # for simulated tempering/perfect sampling
#perf.time <- system.time(perf <- perftemp(NUMSAMP,colo.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),colo.data,colo.prior,colo.temp.par,colo.mixprob,FIXEDNUM=TRUE))
#dput(perf,"colo.perf6")
#dput(perf.time,"colo.perf6.time")
