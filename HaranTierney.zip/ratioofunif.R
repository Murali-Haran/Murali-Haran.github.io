## Sample using ratio of uniforms algorithm
## univariate case
## input: density, f, numsamples, n
## output: n samples from f

ratiou <- function(f,n)
  {
    notgen <- 1 # no sample returned
    xstar <- 
    ## sample from Unif(A), where A={(u,v):0 <= u <= \sqrt{f(v/u)}}
    while (notgen)
      {
        x <- unif(0,xstar)

Sample uniformly from set described by A using Markov chain. The chain
will be uniformly ergodic.  
v/u is a draw from f(.)
