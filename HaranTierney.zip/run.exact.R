breast.data <- readSimpleData(paste(exactdir,"breastcancer",sep=""))
breast.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
breast.proppars <- list(multtdf=50,muh=5.42,sigmah=0.6,muc=4.59,sigmac=0.7,tdfh=50,tdfc=50)
breast.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
breast.mixprob <- list(logpi0=log(1),logpi1=2869.809)
## run rejection sampler for breast cancer data
##rej <- rejsamp(1000,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-Inf,changebound=TRUE)
system.time(rej <- rejsamp(100000,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-2866.039,changebound=FALSE))
dput(rej,"rej1")
system.time(rej <- rejsamp(100000,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-2866.039,changebound=TRUE))
dput(rej,"rej2")
breast.temp.par <- list(p=0.99,q=0.98,nstar=1)  # for simulated tempering/perfect sampling
system.time(perf <- perftemp(100000,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob))
breast.temp.par <- list(p=0.4,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
system.time(perf2 <- perftemp(10000,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob))
dput(perf2,"perf2")
breast.temp.par <- list(p=0.6,q=0.4,nstar=1)  # for simulated tempering/perfect sampling
system.time(perf3 <- perftemp(10000,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob))
dput(perf3,"perf3")
breast.temp.par <- list(p=0.8,q=0.2,nstar=1)  # for simulated tempering/perfect sampling
system.time(perf4 <- perftemp(10000,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob))
dput(perf4,"perf4")
breast.temp.par <- list(p=0.51,q=0.2,nstar=1)  # for simulated tempering/perfect sampling
system.time(perf5 <- perftemp(10000,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob))
dput(perf5,"perf5")
