## function to estimate normalizing constant for
## a given posterior density
## input: parameters for proposal density
## multivariate-t (only need deg. of freedom), log-ts (mean,sd,df)
## = multtdf, (mu1,sigmah,tdfh), (mu2,sigmac,tdfc)
## input: number of samples for MC estimate
## output: normalizing constant

source("newmodel2.functions.R")

## estimate normalizing constant
findnorm <- function(NUMSAMP,proppars, data, prior,logCnum=0,logCden=0)
  {
    setup <- create.setup(data)
    logratio <- rep(NA,NUMSAMP)
    ratio <- rep(NA,NUMSAMP)
    
    for (i in 1:NUMSAMP)
      {
        samp <- seqsamp(proppars,setup)
        logP.val <- logP.rej(samp$samp,data,prior)+logCnum
        logR.val <- samp$logR.val+logCden
        logratio[i] <- logP.val-logR.val
        ratio[i] <- exp(logratio[i])
      }

#    est <- sum(ratio)/NUMSAMP
    est <- exp(logCden-logCnum)*sum(ratio)/NUMSAMP
    logest <- log(sum(ratio))+(logCden-logCnum)-log(NUMSAMP)
    return(list(ratio=ratio,est=est,logest=logest))
  }

## estimate normalizing constants using a version of Meng-Wong 1996, eqn 2.3
## logCnum,logCden are constants (on log scale) to help solve underflow issues
findnormMW <- function(NUMSAMP,proppars, data, prior,logCnum=0,logCden=0)
  {
    setup <- create.setup(data)

    logP.val <- rep(NA,NUMSAMP)
    for (i in 1:NUMSAMP)
      {
        samp <- seqsamp(proppars,setup) # sample from R
        logP.val[i] <- logP.rej(samp$samp,data,prior)
      }
    logP.val <- logP.val+logCnum
    P.val <- exp(logP.val)
    num <- sum(P.val)/NUMSAMP
    cat("num=",num,"\n")
    if (num==0)
      cat("WARNING: possible underflow (min. logP.val=",min(logP.val),"max.=",max(logP.val),")\n")
    
    samp <- blockMCMC(NUMSAMP,proppars,data,prior,retsamp=FALSE) # sample from P
    cat("check\n")
    logR.val <- samp$logRvec+logCden
    R.val <- exp(logR.val)
    den <- sum(R.val)/NUMSAMP

    cat("den=",den,"\n")
    if (den==0)
      cat("WARNING: possible underflow (min. logR.val=",min(logR.val),"max.=",max(logR.val),")\n")
    
    logratio <- (log(num)-logCnum)-(log(den)-logCden)
    
    return(list(est=exp(logratio),logest=logratio))
}    
  
## estimate bound (on log-scale) empirically by keeping maximum over several samples
findbound <- function(NUMSAMP,proppars,data,prior,startbound=-Inf)
  {
    multtdf <- proppars$multtdf
    muh <- proppars$muh
    sigmah <- proppars$sigmah
    muc <- proppars$muc
    sigmac <- proppars$sigmac
    tdfh <- proppars$tdfh
    tdfc <- proppars$tdfc
    
    logK <- startbound # starting value
    setup <- create.setup(data)
    ratio <- rep(NA,NUMSAMP)
    
    for (i in 1:NUMSAMP)
      {
        samp <- seqsamp(proppars,setup)
        logP.val <- logP.rej(samp$samp,data,prior)
        logR.val <- samp$logR.val
        logratio <- logP.val-logR.val
        if (logratio>logK)
          logK <- logratio
      }

    return(logK)
  }

## find normalizing constant for proposal
normconst.R <- function(N,proppars)
  {
    nu <- multtdf
    const.multt <- log(gamma((nu+2*N)/2))-log(gamma(nu/2))-(2*N/2)*log(nu*pi)
    const.logt1 <- log(gamma((tdfh+1)/2))-log(sigmah)-0.5*log(tdfh*pi)-log(gamma(tdfh/2))
    const.logt2 <- log(gamma((tdfc+1)/2))-log(sigmac)-0.5*log(tdfc*pi)-log(gamma(tdfc/2))
    return(const.multt+const.logt1+const.logt2)
  }

## estimate acceptance rate of proposal Y from independence chain
## (assume chain is already stationary)
## Important: multiply amount below by R(Y)/P(Y) to obtain acc.rate
findacc.indep <- function(NUMSAMP,proppars,data,prior,logC)
  {
    setup <- create.setup(data)
    logratio <- rep(NA,NUMSAMP)
    ratio <- rep(NA,NUMSAMP)
    
    for (i in 1:NUMSAMP)
      {
        samp <- seqsamp(proppars,setup)
        logP.val <- logP.rej(samp$samp,data,prior)
        logR.val <- samp$logR.val
        logratio[i] <- 2*(logP.val-logR.val)+logC # different from findnorm
        ratio[i] <- exp(logratio[i])
        cat("logP.val,logR.val,logratio=",logP.val,logR.val,logratio[i],"\n")
      }

#    est <- sum(ratio)/NUMSAMP
    est <- exp(-logC)*sum(ratio)/NUMSAMP# different from findnorm
    if (est==0)
      cat("WARNING: possible underflow (min. logratio=",min(logratio),"max.=",max(logratio),")\n")
    
    logest <- log(sum(ratio))-logC-log(NUMSAMP)# different from findnorm
    return(list(ratio=ratio,est=est,logest=logest))
  }

## slow evaluation of proposal at x
logR.slow <- function(x,proppars,setup)
  {
    tauh <- x[1]
    tauc <- x[2]
    thetaphi <- x[-c(1,2)]
     ## evaluating KERNEL of multivariate-t density at the sampled value
    Cmat <- rbind(cbind(setup$Vinv+tauh*setup$Id, setup$Vinv), cbind(setup$Vinv, setup$Vinv+tauc*setup$Q))
    Cmatinv <- solve(Cmat)
    sig <- Cmatinv*(multtdf/(multtdf-2)) # while correcting for degrees of freedom
    mu <- Cmatinv%*%(-0.5*setup$d)
    cat("sig=")
    print(sig)
    logR.THETA.val <- mymultt(thetaphi,mu,sig,multtdf,TRUE)
    logR.tauh.val <- logdlt.nor(tauh,muh,sigmah,tdfh)
    logR.tauc.val <- logdlt.nor(tauc,muc,sigmac,tdfc)
    logR.val <- logR.tauh.val+logR.tauc.val+logR.THETA.val
    cat("multt=",logR.THETA.val,"\n")
    
    return(logR.val)
  }
   
## fast evaluation of proposal at x
logR.fast <- function(x,proppars,setup)
  {
    tauh <- x[1]
    tauc <- x[2]
    theta <- x[3:length(x)]
    
    ## sample from appropriate multivariate-t, conditional on log-t
    ## setup <- create.setup(data=toydata)
    ## get matrices etc. with everything already permuted
    Q <- setup$Q
    Y <- setup$Y
    d <- setup$d
    Zeros <- setup$Zeros
    Id <- setup$Id
    permut <- setup$permut
    rev.permut <- setup$rev.permut
    Vinv <- setup$Vinv
    bw <- setup$bw
    N <- setup$N
    nu <- multtdf # for convenience

    theta.permut <- theta[permut]
    ## end setup
        
    ## fast choleski decomposition of Sigmainv (precision matrix)
    U <- fastchol(tauh,tauc,Y,Vinv,Q,Zeros,bw)
    ## if desired precision is sigmainv, the matrix in Multi-t=sigmainv*(nu/(nu-2))
    ## so, need to correct for degrees of freedom
    cor.df <- (nu/(nu-2))
    U <- U*sqrt(cor.df)

    v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
    m <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
    ## now need to 'correct back'
    ## m= cov.matrix*(nu-2)/nu * d, but we want, m=cov.matrix*d
    m <- m*nu/(nu-2)

    ## evaluating KERNEL of multivariate-t density at the sampled value
    logdet <- sum(log(diag(U))) # log(det(Sigma^(-1))^(0.5))
    cat("sigmainv=")
    print(t(U)%*%U)
    temp.val <- U%*%(theta.permut-m) # U%*%(r-m)
    temp.val <- t(temp.val)%*%temp.val # (r-m)^T B (r-m)
    kern.val <- -0.5*(nu+2*N)*log(1 + (1/nu)*temp.val)
    const.val <- log(gamma((nu+2*N)/2))-log(gamma(nu/2))-(2*N/2)*log(nu*pi)
    cat("kern.val=",kern.val,"\n")
    cat("logdet=",logdet,"\n")
    cat("const.val=",const.val,"\n")
    
    logR.THETA.val <- logdet+kern.val+const.val
    logR.tauh.val <- logdlt.nor(tauh,muh,sigmah,tdfh)
    logR.tauc.val <- logdlt.nor(tauc,muc,sigmac,tdfc)
    logR.val <- logR.tauh.val+logR.tauc.val+logR.THETA.val

    cat("multt=",logR.THETA.val,"\n")
    return(logR.val)
  }

## estimate mode of posterior based on Monte Carlo samples
findpostmode <- function(samp,data,prior)
  {
    currmode <- logP.rej(samp[1,],data,prior)
    currmodepar <- samp[1,]
    
    for (i in 2:dim(samp)[1])
      {
        val <- logP.rej(samp[i,],data,prior)
        if (val>currmode)
          {
            currmode <- logP.rej(samp[i,],data,prior)
            currmodepar <- samp[i,]
          }
      }

    return(list(par=currmodepar,val=currmode))
  }

findpostmeansd <- function(samp,data,prior)
  {
    meanval <- apply(samp,2,mean)
    sdval <- apply(samp,2,sd)
    return(list(mean=meanval,sd=sdval))
  }
                         
## compute choleski factor of covariance matrix, while accounting for
## degrees of freedom of multi-t distribution
fastchol <- function(tauh,tauc,Y,Vinv,Q,Zeros,bw)
{
  ## fast choleski decomposition of Sigmainv (precision matrix)
  U11 <- diag(sqrt(Y+tauh))
  U12 <- diag(Y/sqrt(Y+tauh))
  
  temp <- (Vinv+tauc*Q) - diag(Y^2/(Y+tauh))
  U22 <- chol.band(temp, bw) # band choleski decomp.
  U <- rbind(cbind(U11,U12), cbind(Zeros,U22))

  return(U)
}

mymultt <- function(x,mean,sigma,multtdf,logarithm=FALSE)
  {
    N <- length(x)
    A <- x-mean
    prec <- solve(sigma) # inefficient
    piece1 <- t(A)%*%prec%*%A
    logkern <- -0.5*(multtdf+N)*log(1+piece1/multtdf)
    logdet <- 0.5*determinant(prec,TRUE)$modulus[[1]]
    logconst <- log(gamma(0.5*(multtdf+N)))-0.5*N*log(multtdf*pi)-log(gamma(multtdf/2))

    val <- logdet+logconst+logkern

    cat('logkern=',logkern,"\n")
    cat("logdet=",logdet,"\n")
    cat("logconst=",logconst,"\n")
    
    if (logarithm)
      return(val)
    else
      return(exp(val))
  }

## functions for optimization and numerical integration
## need to set: multtdf,muh,sigmah,tdfh,muc,sigmac,tdfc,mysetup
neglogP.eval <- function(x)
  {
    val <- logP.rej(x,data,prior)
    ##    cat(x," ",-val,"\n")
#    cat(val," ")
    return(-val)
  }
logP.eval <- function(x)
  {
    val <- logP.rej(x,data,prior)
    return(val)
  }
P.eval <- function(x) return(exp(logP.rej(x,data,prior)))

logR.eval <- function(x)
  {
    val <- logR.fast(x,multtdf,muh,sigmah,tdfh,muc,sigmac,tdfc,setup=mysetup)
    return(val)
  }
neglogR.eval <- function(x)
  {
    val <- logR.fast(x,multtdf,muh,sigmah,tdfh,muc,sigmac,tdfc,setup=mysetup)
#    cat(-val," ")
    return(-1*val)
  }
R.eval <- function(x)
  {
    val <- logR.fast(x,multtdf,muh,sigmah,tdfh,muc,sigmac,tdfc,setup=mysetup)
    return(exp(val))
  }


mymultt.eval <- function(x)
  return(mymultt(x,multmean,multsigma,multtdf))

mymulttlog.eval <- function(x)
  return(mymultt(x,multmean,multsigma,multtdf,TRUE))

mymulttneglog.eval <- function(x)
  return(-1*mymultt(x,multmean,multsigma,multtdf,TRUE))
#lala <- adapt(3,rep(-10000,3), rep(10000,3),functn=mymultt.eval)

univ.eval <- function(x)
  return(mymultt(x,5,2,3))

univ.eval2 <- function(x)
  return(myunivt(x,5,2,3))

## IMPORTANT: third argument is variance (sigma^2)
myunivt <- function(x,mu,sigsq,tdf,logarithm=FALSE)
  {
    logkern <- -0.5*(tdf+1)*log(1+(((x-mu)^2)/sigsq)/tdf)
    logsig <- -0.5*log(sigsq)
    logconst <- log(gamma(0.5*(tdf+1)))-0.5*log(tdf*pi)-log(gamma(tdf/2))

    val <- logsig+logconst+logkern
##    cat('logkern=',logkern,"\n")
##    cat("logsig=",logsig,"\n")
##    cat("logconst=",logconst,"\n")
    

    if (logarithm)
      return(val)
    else
      return(exp(val))
  }
