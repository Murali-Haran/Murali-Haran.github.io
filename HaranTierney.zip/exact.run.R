data <- readSimpleData("breastcancer")
prior <- list(alphah=1,betah=100,alphac=1, betac=50)
proppars <- list(multtdf=50,muh=5.42,sigmah=0.6,muc=4.59,sigmac=0.7,tdfh=50,tdfc=50)
temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
mixprob <- list(logpi0=log(1),logpi1=2872) # prob of being in H0 versus H1 in stationary distr.

## rejection sampler
breast.rej <- rejsamp(NUMSAMP=100,proppars,data,prior,logbound=-2947.74)
