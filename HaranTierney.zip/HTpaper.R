exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R") # load in important functions
source("~/public_html/batchmeans.R") # read in batch means s.error estimation
source("plotting.R") # functions for plotting

############################################################################################################
## breast cancer data
############################################################################################################
#breast.data = readSimpleData(paste(exactdir,"breastcancer",sep=""))
breast.data = readSimpleData("breastcancer")
breast.prior = list(alphah=1,betah=100,alphac=1, betac=50)
breast.proppars = list(multtdf=50,muh=5.42,sigmah=0.6,muc=4.59,sigmac=0.7,tdfh=50,tdfc=50)
breast.logbound = -2869.809
breast.mixprob = list(logpi0=log(1),logpi1=-breast.logbound)
breast.temp.par = list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

## PLOTTING
## show bivariate (joint) log margins for breast cancer data
outLogMargins = showLogMargins.fast(seq(2,7,length=50),seq(2,7,length=50),data=breast.data,prior=breast.prior,twoviews=FALSE)
postscript("breastbiv.ps")
persp(outLogMargins$xs,outLogMargins$ys,exp(outLogMargins$z-max(outLogMargins$z)), col="red",xlab="",ylab="",zlab="",box=FALSE,axes=FALSE)
dev.off()

## show marginal (profile) log margins for breast cancer data
xs = seq(2,8,length=100)
ys = seq(2,8,length=100)
breast.prof = showLogMargins.profile.crude(xs,ys,c(2,8),c(2,8),data=breast.data,prior=breast.prior)  # showLogMargins.profile.fast(xs,ys)
xs.env = sapply(breast.prof$xs,function(x) dt.mod(x, meanlog=breast.proppars$muh,breast.proppars$sigmah))
ys.env = sapply(breast.prof$ys,function(x) dt.mod(x, meanlog=breast.proppars$muc,breast.proppars$sigmac))

postscript("breasttauh.ps")
plot(breast.prof$xs, breast.prof$xs.prof,type="l",xlab=expression(log(tau[h])),ylab="",cex.lab=2.5)
lines(breast.prof$xs, xs.env,col="green")
dev.off()
postscript("breasttauc.ps")
plot(breast.prof$ys, breast.prof$ys.prof,type="l",xlab=expression(log(tau[c])),ylab="",cex.lab=2.5)
lines(breast.prof$ys, ys.env,col="green")
dev.off()

## converted ps to eps using ps2epsi 

## algorithms are run from:
## HTpaper.breast.run.R
## HTpaper.infant.run.R

############################################################################################################
## infant mortality: plotting
############################################################################################################
xs = seq(3,8,length=50)
ys = seq(1,5,length=50)

system.time((infant.outLogMargins = showLogMargins.fast(xs,ys,data=infant.data,prior=infant.prior,twoviews=FALSE)))
#   user  system elapsed 
#314.682 114.695 430.450 
system.time((infant.prof = showLogMargins.profile.crude(xs,ys,c(min(xs),max(xs)),c(min(ys),max(ys)),data=infant.data,prior=infant.prior)))# showLogM
#    user   system  elapsed 
#1161.886  143.089 1310.677 
dput(infant.outLogMargins,"infant.outLogMargins")
dput(infant.prof,"infant.prof")

postscript("infantbiv.ps")
# infant.outLogMargins=dget("infant.outLogMargins")
persp(infant.outLogMargins$xs,infant.outLogMargins$ys,exp(infant.outLogMargins$z-max(infant.outLogMargins$z)), col="red",xlab="",ylab="",zlab="",box=FALSE,axes=FALSE,theta=90)
dev.off()

## get proposal parameters from plots above
infant.proppars = list(multtdf=50,muh=5.45,sigmah=0.55,muc=3.0,sigmac=0.4,tdfh=50,tdfc=50)
xs.env = sapply(infant.prof$xs,function(x) dt.mod(x, meanlog=infant.proppars$muh,infant.proppars$sigmah))
ys.env = sapply(infant.prof$ys,function(x) dt.mod(x, meanlog=infant.proppars$muc,infant.proppars$sigmac))

postscript("infanttauh.ps")
plot(infant.prof$xs, infant.prof$xs.prof,type="l",xlab=expression(log(tau[h])),ylab="",cex.lab=2.5)
lines(infant.prof$xs, xs.env,col="green")
dev.off()
postscript("infanttauc.ps")
plot(infant.prof$ys, infant.prof$ys.prof,type="l",xlab=expression(log(tau[c])),ylab="",cex.lab=2.5)
lines(infant.prof$ys, ys.env,col="green")
dev.off()

