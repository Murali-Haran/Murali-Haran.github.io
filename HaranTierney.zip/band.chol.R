if (!exists("exactdir"))
  exactdir <- "/home/u1/mharan/exact/" # location of directory with functions for exact sampling
# compiling shared library into R
#R SHLIB dpbtrf.f

# can now load it into "R"
#dyn.load("/HOME/grads/mharan/exact/sparse/dpbtrf.so")
dyn.load(paste(exactdir,"/dpbtrf.so",sep=""))
#is.loaded(symbol.For("dpbtrfmod"))
#[1] TRUE
#is.loaded(symbol.For("dpbtrf"))
#[1] TRUE
#source("bandstore.R")
# given matrix, mat and number of band diagonals, numsuperdiag
# return choleski decomposition, D, s.t. t(D) D
band.chol <- function(mat,numsuperdiag)
  {
    N <- dim(mat)[1] # order of matrix
    KD <- numsuperdiag # number of super diagonals in the matrix
    LDAB <- KD + 1 
    INFO <- 0
    STRLEN <- 1

    # convert matrix into band storage scheme vector version
    AB <- mattobandstore(mat,KD)
    print(AB)
    res <- .Fortran("dpbtrfmod", as.integer(N), as.integer(KD), AB=as.double(AB),as.integer(LDAB), as.integer(INFO))$AB

    return(bandstoretomat(res,KD))
  }

# faster version (do the band storage conversion in FORTRAN, not in R)
# dbptrfmod2 takes in the matrix, mat, and returns the choleski
# decomposition, L, of mat, s.t. L^t L = mat
chol.band <- function(mat,bw)
  {
    N <- dim(mat)[1] # order of matrix
    KD <- bw # number of super diagonals (bandwidth) of matrix
    LDAB <- KD + 1 
    INFO <- 0
    STRLEN <- 1

    # convert matrix into band storage scheme vector version
    mat <- c(mat) # convert to a vector for FORTRAN
    res <- .Fortran("dpbtrfmod2", as.integer(N), as.integer(KD), MAT=as.double(mat),as.integer(LDAB), as.integer(INFO))$MAT
    res <- matrix(res,N,N)

    return(res)
  }

# test above procedure

#myQ <-matrix(c(3,-1,-1, 0,0,-1,0,0,-1,2,-1, 0, 0, 0, 0, 0,-1, -1, 4,-1,0,-1,0,0,0,0,-1,4,-1,-1,-1,0,0,0,0,-1,4,-1,-1,-1,-1,0,-1,-1,-1,4,0,0,0,0,0,-1,-1,0,3,-1,0,0,0,0,-1,0,-1,2),8,8)
#mydat <- c(14,83,13,16,15,6,25,13)
#testmat <- as.matrix(myQ + diag(mydat))
#val <- band.chol(testmat,5)

# running through gdb
#Program received signal SIGSEGV, Segmentation fault.
#0x080c147e in SET_VECTOR_ELT (x=0x0, i=0, v=0x8bf5248) at memory.c:2169
#2169    SEXP (SET_VECTOR_ELT)(SEXP x, int i, SEXP v) { CHECK_OLD_TO_NEW(x, v); return VECTOR_ELT(x, i) =v; }
