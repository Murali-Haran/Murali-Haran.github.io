# functions for sampling from Model 2
# model with two variance components

# read in functions for multivariate-t generation and density
source("multt.R")
# read in functions for log-t generation and density
source("lt.R")

options(show.error.messages = TRUE)

# from smrf.R
readSimpleData <-  function(name) {
    data <- read.table(paste(name, ".data.R", sep=""));
    names(data) <- c("Y","E")
    N <- nrow(data)
    Q <- matrix(scan(paste(name,".Q",sep="")), N, N)
    list(data=data, Q=Q)
}
#toyprior <- list(alphah=1,betah=100,alphac=1, betac=50)
#toyprior <- list(alphah=0.25, betah=0.00025, alphac=0.25,betac=0.0005) #vague priors
# Plot 2-d picture of approximate log-transformed marginal distributions
# fast version using sparse matrix algorithms
showLogMargins.fast <- function(xs,ys,color="red",twoviews=T,data=toydata,prior=toyprior)
{
  # do the setup below just once
  # everything will be computed in the transformed space
  # (more efficient and identical final result)
  Q <- data$Q
  N <- nrow(data$data)
  M <- N-1
  Id <- diag(rep(1,N)) # NxN Identity matrix
                                        # adjacency matrix
  numadj <- sum(Q==-1)/2

  alphah <- prior$alphah
  alphac <- prior$alphac
  betah <- prior$betah
  betac <- prior$betac
  
  source("band.min.R")
  band.min.Q <- band.min(Q)
  permut <- band.min.Q$permut
  rev.permut <- band.min.Q$origpermut
  bw <- band.min.Q$bandwd

                                        # all of the following vectors and matrices are permuted according to above
  Y <- data$data$Y[permut]
  E <- data$data$E[permut]
  etahat <- log(Y/E)
  Vinv <- diag(Y)
  Q <- Q[permut, permut]
  transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
#  d <- transfmuhat # this is the same as "-0.5*D" in the paper
  D <- -2*t(transfmuhat)
  Zeros <- matrix(0, N, N)

  source("/HOME/grads/mharan/exact/sparse/band.chol.R") # for band choleski
  # end of setup
  
  z <- matrix(0,length(xs),length(ys))
  
  for (i in 1:dim(z)[1])
    for (j in 1:dim(z)[2])
      {
        exptauh <- exp(xs[i])
        exptauc <- exp(ys[j])
                                        # fast choleski decomposition of Sigmainv (precision matrix)
        U11 <- diag(sqrt(Y+exptauh))
        U12 <- diag(Y/sqrt(Y+exptauh))
        
        temp <- (Vinv+exptauc*Q) - diag(Y^2/(Y+exptauh))
        U22 <- chol.band(temp, bw) # band choleski decomp.
        U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
#        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
        v <- backsolve(U, t(D)*-0.5, upper.tri = TRUE, transpose = TRUE)
        xhat <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d

        piece1 <- (N/2+alphah-1)*log(exptauh)+(M/2+alphac-1)*log(exptauc) - exptauh/betah - exptauc/betac
        logdet <- -1*sum(log(diag(U))) # -1*log(det(Sigma^(-1))^(0.5))=log(det(Sigma)^(0.5))

#        sigmainv <- rbind(cbind(Vinv+exptauh*Id, Vinv), cbind(Vinv, Vinv + exptauc*Q))
        temp.val <- U%*%xhat
        piece2 <- -0.5*t(temp.val)%*%temp.val # -0.5*t(xhat)%*%C%*%xhat
        piece3 <- -0.5*D%*%xhat # -0.5*D%*%xhat
        z[i,j] <- piece1+logdet+piece2 + piece3 + xs[i]+ys[j] # last two pieces added due to Jacobian of log-trans
      }

  if (twoviews)
    {
      par(mfrow=c(1,2))
      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
      
      persp(xs,ys,exp(z-max(z)), col=color,theta=90,xlab="log(tauh)",ylab="log(tauc)",zlab="")
    }
  else
    {
      par(mfrow=c(1,1))
      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
    }
  return(list(xs=xs,ys=ys,zs=exp(z-max(z))))
}

# faster version of showLogMargins.profile
# with a major difference: no optimizing - use mean of other variable instead
# of maximizing w.r.t. the otther variable
# input: xs (list of tauhs), ys (list of taucs)
# show profiles of approximate marginal dist (transformed)
# (log(tauh),log(tauc))|Y
showLogMargins.profile.fast <- function(xs,ys,start.val=2,data=toydata,prior=toyprior)
{
  xs.prof <- rep(0,length(xs))
  ys.prof <- rep(0,length(ys))

  xs.mean <- mean(xs)
  ys.mean <- mean(ys)

  # do the setup below just once
  # everything will be computed in the transformed space
  # (more efficient and identical final result)
  Q <- data$Q
  N <- nrow(data$data)
  M <- N-1
  Id <- diag(rep(1,N)) # NxN Identity matrix
                                        # adjacency matrix
  numadj <- sum(Q==-1)/2

  alphah <- prior$alphah
  alphac <- prior$alphac
  betah <- prior$betah
  betac <- prior$betac
  
  source("band.min.R")
  band.min.Q <- band.min(Q)
  permut <- band.min.Q$permut
  rev.permut <- band.min.Q$origpermut
  bw <- band.min.Q$bandwd

                                        # all of the following vectors and matrices are permuted according to above
  Y <- data$data$Y[permut]
  E <- data$data$E[permut]
  etahat <- log(Y/E)
  Vinv <- diag(Y)
  Q <- Q[permut, permut]
  transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
#  d <- transfmuhat # this is the same as "-0.5*D" in the paper
  D <- -2*t(transfmuhat)
  Zeros <- matrix(0, N, N)

  source("/HOME/grads/mharan/exact/sparse/band.chol.R") # for band choleski
  # end of setup
  
  # for each element in xs (tauhs), plug in mean of tauc
  for (i in 1:length(xs))
    {
      exptauh <- exp(xs[i])
      exptauc <- exp(ys.mean)
                                        # fast choleski decomposition of Sigmainv (precision matrix)
      U11 <- diag(sqrt(Y+exptauh))
      U12 <- diag(Y/sqrt(Y+exptauh))
      
      temp <- (Vinv+exptauc*Q) - diag(Y^2/(Y+exptauh))
      U22 <- chol.band(temp, bw) # band choleski decomp.
      U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
                                        #        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
      v <- backsolve(U, t(D)*-0.5, upper.tri = TRUE, transpose = TRUE)
      xhat <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
      
      piece1 <- (N/2+alphah-1)*log(exptauh)+(M/2+alphac-1)*log(exptauc) - exptauh/betah - exptauc/betac
      logdet <- -1*sum(log(diag(U))) # -1*log(det(Sigma^(-1))^(0.5))=log(det(Sigma)^(0.5))
      
      temp.val <- U%*%xhat
      piece2 <- -0.5*t(temp.val)%*%temp.val # -0.5*t(xhat)%*%C%*%xhat
      piece3 <- -0.5*D%*%xhat # -0.5*D%*%xhat
      
      xs.prof[i] <- piece1+logdet+piece2 + piece3 + xs[i]+ys.mean
    }

  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      exptauh <- exp(xs.mean)
      exptauc <- exp(ys[i])
                                        # fast choleski decomposition of Sigmainv (precision matrix)
      U11 <- diag(sqrt(Y+exptauh))
      U12 <- diag(Y/sqrt(Y+exptauh))
      
      temp <- (Vinv+exptauc*Q) - diag(Y^2/(Y+exptauh))
      U22 <- chol.band(temp, bw) # band choleski decomp.
      U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
                                        #        v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
      v <- backsolve(U, t(D)*-0.5, upper.tri = TRUE, transpose = TRUE)
      xhat <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
      
      piece1 <- (N/2+alphah-1)*log(exptauh)+(M/2+alphac-1)*log(exptauc) - exptauh/betah - exptauc/betac
      logdet <- -1*sum(log(diag(U))) # -1*log(det(Sigma^(-1))^(0.5))=log(det(Sigma)^(0.5))
      
      temp.val <- U%*%xhat
      piece2 <- -0.5*t(temp.val)%*%temp.val # -0.5*t(xhat)%*%C%*%xhat
      piece3 <- -0.5*D%*%xhat # -0.5*D%*%xhat

      ys.prof[i] <- piece1+logdet+piece2 + piece3 + xs.mean+ys[i]
    }

  xs <- xs[!is.na(xs.prof)]
  xs.prof <- xs.prof[!is.na(xs.prof)]

  ys <- ys[!is.na(ys.prof)]
  ys.prof <- ys.prof[!is.na(ys.prof)]
  
  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green")

  return(list(xs=xs,ys=ys,
              xs.prof=exp(xs.prof-max(xs.prof)),
              ys.prof=exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

# log of determinant of a matrix
logdet <- function(mymat)
  {
    eigenval <- eigen(mymat,only.values=TRUE)

    # bullet-proofing the code by using try (to protect against complex eigen vals)
    pos.real <- try(all(eigenval$values > 0)) # if all eigen vals are positive
    if (is.null(class(pos.real))) #no error above, i.e. eigen values are real(?)
      {
        if (pos.real) # if all eigen values are positive AND real
          {
            logdetval <- sum(log(eigenval$values))
            if (logdetval==Inf)
              cat("logdet is Inf\n")
            if (logdetval==(-Inf))
              cat("logdet is -Inf\n")
            
            return(logdetval)
          }
        else
          stop("logdet:non-pos eigen value\n") # error detected => non-pos eigen val
      }
    else
      stop("logdet:non-real eigen value\n") # error detected => complex eigen val
  }

# approximate log marginal distribution of (tauh,tauc)
logH <- function(tauh,tauc,data=toydata,prior=toyprior)
{
  alphah <- prior$alphah
  betah <- prior$betah
  alphac <- prior$alphac
  betac <- prior$betac
  Vinv <- diag(data$data$Y)
  muhat <- log(data$data$Y/data$data$E)
  Q <- data$Q
  N <- nrow(data$data)
  M<-N-1
  Id <- diag(rep(1,N))
  V <- diag(1/data$data$Y)

#  cat("tauh,tauc,(tauc/tauh)=",tauh,tauc,tauc/tauh,"\n")
  A <- solve(Id+(tauc/tauh)*Q+tauc*V%*%Q)%*%muhat
  thetahat <- rbind((tauc/tauh)*Q%*%A, A)
  Cmat <- rbind(cbind((Vinv+tauh*Id), Vinv),
             cbind(Vinv, (Vinv+tauc*Q)))
  Dmat <- cbind(-2*t(muhat)%*%Vinv,-2*t(muhat)%*%Vinv)
  
  piece1 <- (N/2+alphah-1)*log(tauh)+(M/2+alphac-1)*log(tauc)-tauh/betah-tauc/betac

#  print(tauh*Vinv+tauc*Vinv%*%Q+tauh*tauc*Q)

  piece2 <- try(logdet(tauh*Vinv+tauc*Vinv%*%Q+tauh*tauc*Q))
  if (is.null(class(piece2)))
    piece2 <- -0.5*piece2
  else
    stop("logH:logdet error\n")
  piece3 <- -0.5*(t(thetahat)%*%Cmat%*%thetahat+Dmat%*%thetahat)

  return(piece1+piece2+piece3)
}

logH.log <- function(tauh,tauc,data=toydata,prior=toyprior)
{
  exptauh <- exp(tauh)
  exptauc <- exp(tauc)

  piece1 <- logH(exptauh,exptauc,data,prior)
  piece4 <- tauh+tauc
  return(piece1+piece4)
}

# density of envelope (log-t bivariate)
logbivdlt <- function(tau,mu1,sigma1,t1.df,mu2,sigma2,t2.df)
  {
    tauh <- tau[1]
    tauc <- tau[2]
    
    logdlt(tauh,mu1,sigma1,t1.df)+ logdlt(tauc,mu2,sigma2,t2.df)
  }

# density of envelope (t bivariate)
logbivdt <- function(tau,mu1,sigma1,t1.df,mu2,sigma2,t2.df)
  {
    tauh <- tau[1]
    tauc <- tau[2]
    
    logdt.mod(tauh,mu1,sigma1,t1.df)+ logdt.mod(tauc,mu2,sigma2,t2.df)
  }

# input: xs (list of tauhs), ys (list of taucs)
showMargins <- function(xs,ys,color="red") {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

  z <- matrix(0,length(xs),length(ys))
  for (i in 1:dim(z)[1])
    for (j in 1:dim(z)[2])
        z[i,j] <- logH(c(xs[i],ys[j]))
  par(mfrow=c(2,1))
  persp(xs,ys,exp(z-max(z)), col=color)
  persp(xs,ys,exp(z-max(z)), col=color,theta=90)
#  persp(xs,ys,exp(z-max(z)), col=color,theta=180)
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

# input: xs (list of tauhs), ys (list of taucs)
# show marginal distribution of log-transformed params
showLogMargins <- function(xs,ys,color="red",twoviews=T) {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

  z <- matrix(0,length(xs),length(ys))
  for (i in 1:dim(z)[1])
    for (j in 1:dim(z)[2])
      z[i,j] <- logH.log(xs[i],ys[j])

  if (twoviews)
    {
      par(mfrow=c(1,2))
      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
      
      persp(xs,ys,exp(z-max(z)), col=color,theta=90,xlab="log(tauh)",ylab="log(tauc)",zlab="")
    }
  else
    {
      par(mfrow=c(1,1))
      persp(xs,ys,exp(z-max(z)), col=color,xlab="log(tauh)",ylab="log(tauc)",zlab="")
    }
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
  return(list(xs=xs,ys=ys,zs=exp(z-max(z))))
}

# input: xs (list of tauhs), ys (list of taucs)
# show envelope for log(tauh),log(tauc)|Y
showLogEnv <- function(xs,ys,mu1,sigma1,t.df1,mu2,sigma2,t.df2,color="red")
  {
    z <- matrix(0,length(xs),length(ys))
    for (i in 1:dim(z)[1])
      for (j in 1:dim(z)[2])
        z[i,j] <- logbivdlt(taucand,mu1,sigma1,t.df1,mu2,sigma2,t.df2)

    par(mfrow=c(2,1))
    persp(xs,ys,exp(z-max(z)), col=color)
    
    persp(xs,ys,exp(z-max(z)), col=color,theta=90)
  }

# input: xs (list of tauhs), ys (list of taucs)
# show profiles of approximate marginal dist (transformed)
# (log(tauh),log(tauc))|Y
showLogMargins.profile <- function(xs,ys,start.val=2) {
#    phihat <- log(data$data$Y / data$data$E)
#    y<-sapply(x,function(x) logpost(phihat,x))
#    plot(x,exp(y-max(y)),type="l")

#  start.val <- 2 # this may need to be changed
  
  xs.prof <- rep(0,length(xs))
  ys.prof <- rep(0,length(ys))

  # for each element in xs (tauhs), maximize over tauc
  for (i in 1:length(xs))
    {
      opt <- try(optim(start.val, function(y) logH.log(xs[i],y), control=list(fnscale=-1), method="BFGS"))
      if (is.null(class(opt))) # no error
        xs.prof[i] <- opt$value
      else
        xs.prof[i] <- NA
    }

  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      opt <- try(optim(start.val, function(x) logH.log(x,ys[i]), control=list(fnscale=-1), method="BFGS"))
      if (is.null(class(opt))) # no error
        ys.prof[i] <- opt$value
      else
        ys.prof[i] <- NA
#      print(opt)
#      cat("\n\n")
    }

  xs <- xs[!is.na(xs.prof)]
  xs.prof <- xs.prof[!is.na(xs.prof)]

  ys <- ys[!is.na(ys.prof)]
  ys.prof <- ys.prof[!is.na(ys.prof)]
  
  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green")

  return(list(xs=xs,ys=ys,
              xs.prof=exp(xs.prof-max(xs.prof)),
              ys.prof=exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

#library(integrate) # Jan.25, 2004

# obtain approx. marginal distributions for tauh, tauc resp.
# by integrating out the other parameter (tauc, tauh resp.)
# Note: this is on log scale (log(tauh), log(tauc))
showLogMargins.integ <- function(xs,ys) {

  xs.prof <- rep(0,length(xs))
  ys.prof <- rep(0,length(ys))

  # for each element in xs (tauhs), maximize over tauc
  for (i in 1:length(xs))
    {
      int.val <- adapt(1, lower=c(min(ys)), upper=c(max(ys)), minpts=100,maxpts=500,functn=function(y) logH.log(xs[i],y), eps=0.001)$value
      xs.prof[i] <- int.val
    }
  
  # for each element in ys (taucs), maximize over tauh
  for (i in 1:length(ys))
    {
      int.val <- adapt(1, lower=c(min(ys)), upper=c(max(ys)), minpts=100,maxpts=500,functn=function(x) logH.log(x,ys[i]), eps=0.001)$value
      ys.prof[i] <- int.val
    }
  
  par(mfrow=c(2,1))
  plot(xs, exp(xs.prof-max(xs.prof)),col="blue")
  plot(ys, exp(ys.prof-max(ys.prof)),col="green")

  return(list(x=exp(xs.prof-max(xs.prof)),
              y=exp(ys.prof-max(ys.prof))))

#  return(rbind(exp(xs.prof-max(xs.prof)),
#               exp(ys.prof-max(ys.prof))))
  
#    zz<-sapply(x, logLapMargin)
#    lines(x,exp(zz-max(zz)),col="green")
}

logP.rej <- function(samp,data=toydata,prior=toyprior)
  {
    alphah <- prior$alphah
    betah <- prior$betah
    alphac <- prior$alphac
    betac <- prior$betac

    N <- nrow(data$data)
    M <- N-1
    Y <- data$data$Y
    E <- data$data$E
    Q <- data$Q
   
    tauh <- samp[1]
    tauc <- samp[2]
    theta <- samp[3:(2+N)]
    phi <- samp[(2+N+1):(2+2*N)]

    piece1 <- sum((theta+phi)*Y-E*exp(theta+phi))
    piece2 <- (N/2+alphah-1)*log(tauh)-tauh/betah+(M/2+alphac-1)*log(tauc)-tauc/betac
    piece3 <- -0.5*tauh*sum(theta^2) - 0.5*tauc*t(phi)%*%Q%*%phi

    return(piece1+piece2+piece3)
  }

logQ.rej <- function(samp,mu.mat,var.mat,multt.df,data=toydata,prior=toyprior)
{
    alphah <- prior$alphah
    betah <- prior$betah
    alphac <- prior$alphac
    betac <- prior$betac

    N <- nrow(data$data)
    M <- N-1
    Y <- data$data$Y
    E <- data$data$E
    Q <- data$Q
    Vinv <- diag(data$data$Y)
    V <- diag(1/data$data$Y)
    muhat <- log(data$data$Y/data$data$E)
    Id <- diag(rep(1,N)) # NxN Identity matrix

    tauh <- samp[1]
    tauc <- samp[2]
    theta <- samp[3:(2+N)]
    phi <- samp[(2+N+1):(2+2*N)]
    THETA <- samp[3:(2+2*N)]

    A <- solve(Id+(tauc/tauh)*Q+tauc*V%*%Q)%*%muhat
    THETAHAT <- rbind((tauc/tauh)*Q%*%A, A)
    Cmat <- rbind(cbind((Vinv+tauh*Id), Vinv),
                  cbind(Vinv, (Vinv+tauc*Q)))
    Dmat <- cbind(-2*t(muhat)%*%Vinv,-2*t(muhat)%*%Vinv)
      
    piece1 <- try(logdmultt(THETA,mu.mat,var.mat,multt.df))#-0.5*logdet(var.mat)-t(THETA-mu.mat)%*%solve(var.mat)%*%(THETA-mu.mat)
    if (!(is.null(class(piece1)))) # if there is an error with logdmultt computation
      stop("logQ.rej:logdmultt error\n")
    
    piece2 <- (N/2+alphah-1)*log(tauh)-tauh/betah+(M/2+alphac-1)*log(tauc)-tauc/betac

    piece3 <- try(logdet(tauh*Vinv+tauc*Vinv%*%Q+tauh*tauc*Q))
    if (is.null(class(piece3)))
      piece3 <- -0.5*piece3
    else  # if there is an error with logdet computation
      stop("logQ.rej:logdet error\n")
    
    piece4 <- -0.5*t(THETAHAT)%*%Cmat%*%THETAHAT+Dmat%*%THETAHAT

    return(piece1+piece2+piece3+piece4)
}

logQ.rej.onestage <- function(samp,mu.mat,var.mat,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,data=toydata,prior=toyprior)
{
#    alphah <- prior$alphah
#    betah <- prior$betah
#    alphac <- prior$alphac
#    betac <- prior$betac

  N <- nrow(data$data)
#    M <- N-1
#    Y <- data$data$Y
#    E <- data$data$E
#    Q <- data$Q
#    Vinv <- diag(data$data$Y)
#    V <- diag(1/data$data$Y)
#    muhat <- log(data$data$Y/data$data$E)
#    Id <- diag(rep(1,N)) # NxN Identity matrix

  tauh <- samp[1]
  tauc <- samp[2]
  theta <- samp[3:(2+N)]
  phi <- samp[(2+N+1):(2+2*N)]
  THETA <- samp[3:(2+2*N)]
  
#    A <- solve(Id+(tauc/tauh)*Q+tauc*V%*%Q)%*%muhat
#    THETAHAT <- rbind((tauc/tauh)*Q%*%A, A)
#    Cmat <- rbind(cbind((Vinv+tauh*Id), Vinv),
#                  cbind(Vinv, (Vinv+tauc*Q)))
#    temp <- -2*t(muhat)%*%Vinv
#    Dmat <- cbind(temp,temp)
      
  piece1 <- logbivdlt(c(tauh,tauc),mu1,sigma1,t.df1,mu2,sigma2,t.df2)
  piece2 <- try(logdmultt(THETA,mu.mat,var.mat,multt.df))
#  cat("logQ.THETA.val(old)\n",piece2,"\n")
#  cat("logQ.tau.val(old)\n",piece1,"\n")
  
  if (!is.null(class(piece2)))
    stop("logQ.rej.onestage: logdmultt error\n")

  return(piece1+piece2)
}

# Oct.20th: identical to above, but takes in precision matrix, prec.mat
# rather than covariance matrix, var.mat
logQ.rej.onestage.prec <- function(samp,mu.mat,prec.mat,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,data=toydata,prior=toyprior)
{
  N <- nrow(data$data)
  tauh <- samp[1]
  tauc <- samp[2]
  theta <- samp[3:(2+N)]
  phi <- samp[(2+N+1):(2+2*N)]
  THETA <- samp[3:(2+2*N)]
  
  piece1 <- logbivdlt(c(tauh,tauc),mu1,sigma1,t.df1,mu2,sigma2,t.df2)
  piece2 <- try(logdmultt.prec(THETA,mu.mat,prec.mat,multt.df)) #Oct.20th: only change
  
  if (!is.null(class(piece2)))
    stop("logQ.rej.onestage: logdmultt error\n")
  
  return(piece1+piece2)
}

# Feb.27, 2002.
# Rejection sampling the approximate margin
# function to sample tauh,tauc (note: we are NOT sampling in log-scale)
# bivariate log-t proposal
sampleTau.lt <- function(NUMSAMP = 10000,mu1 = 1,sigma1=1,t.df1=5,mu2 = 2,sigma2=1,t.df2=5, K1 = log(2))
{
  numit.Tauc <- 0
  notenv <- 1 # if 1, then there is at least one sample outside envelope

  while (notenv) # while there is at least one sample produced outside the envelope
    {
      samples <- c()
      acc <- 0 # count number accepted
      logprob <- c() # keep track of log(acceptance prob of each sample)
      NUMgensamples <- 0 # number of samples generated
      notenv <- 0 # assume no samples outside envelope at top of loop
      for (i in 1:NUMSAMP)
        {
          taucand <- c(rlt(1,meanlog=mu1,sdlog=sigma1,t.df1),
                       rlt(1,meanlog=mu2,sdlog=sigma2,t.df2))
          
          NUMgensamples <- NUMgensamples + 1
#          cat("rlt sample=",taucand,"\n")
          H.val <- logH(taucand) # approx. log density
          G.val <- K1 + logbivdlt(taucand,mu1,sigma1,t.df1,mu2,sigma2,t.df2) # envelope
          logprob.val <- H.val-G.val
          logprob <- c(logprob,logprob.val)
          
          if (logprob.val>0) # if log(H)-log(G) > 0, this is not an envelope
            {
              cat("sampleTau: NOT AN ENVELOPE (H.val=",H.val,"G.val=",G.val,") AT ",taucand,"\n")
              
              notenv <- 1
            }
          else
            {
              U <- runif(1)
              if (log(U) < logprob.val)
                {
                  samples <- rbind(samples,taucand)
                                        #              cat("accept ",taucand[1]," ",taucand[2]," ")
                                        #              cat("U=",U," h(T)=",H.val,"G.val=",G.val,"\n")
                  acc <- acc+1
                }
            }
          
          if (notenv)
            {
              K1 <- K1 + max(logprob) # increase the constant until an envelope is found
              numit.Tauc <- numit.Tauc+1
              break
            }
        }
      
      cat("numit.Tauc=",numit.Tauc,"\n")

      if ((notenv!=0) && (acc==0)) # if everything is within the envelope and no sample is accepted
        cat("zero acceptance rate: decrease the value of K1 (try K1=",K1+max(logprob)," for instance)\n")
    }
  
#  return(list(samples=samples,acc=acc,notenv=notenv,NUMgensamples=NUMgensamples,logprob=logprob,K1=K1,numit.Tauc=numit.Tauc))
  return(list(samples=samples,acc=acc,notenv=notenv,NUMgensamples=NUMgensamples,K1=K1,numit.Tauc=numit.Tauc))
}

# this version exits the loop as soon as a 'non-envelope' sample is found
# and automatically adjusts the constant, K2 
# the tau's were sampled from a bivariate-LT(mu1,sigma1,df1,mu2,sigma2,df2) (log-t)
sampleTHETA.lt <- function(tau,multt.df,K2,data=toydata,prior=toyprior)
  {
    Vinv <- diag(data$data$Y)
    V <- diag(1/data$data$Y)
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    A <- matrix(0,numadj,N)
    muhat <- c(log(data$data$Y/data$data$E),rep(0,N+numadj))

    k <- 0
    for (i in 1:N)
      for (j in i:N)
        if (Q[i,j]==-1)
          {
            k <- k+1
            A[k,i] <- -1
            A[k,j] <- 1
          }
#    print(A)
# create design matrix
    X <- rbind(cbind(Id,Id),
               cbind(-1*Id,matrix(0,N,N)), 
               cbind(matrix(0,numadj,N),A))
#    print(X)      
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    while (notenv) # while there is at least one sample produced outside the envelope
      {
        notenv <- 0 # assume envelope works ok at the start
        numacc <- 0
        logprob <- c()
        
        samp.EXACT <- c() # to hold accepted samples

        allsamp <- c()

        taulength <- dim(tau)[1] # number of (tauh,tauc) pairs
        
        for (i in 1:taulength)
          {
            tauh <- tau[i,1]
            tauc <- tau[i,2]
            cat("tauh,tauc=",tauh,tauc,"\n")
#            gammainv.mat <- diag(c(data$data$Y, rep(tauh,N), rep(tauc,numadj)))#commented out Dec.6,2002

            var.mat <- solve(t(X)%*%gammainv.mat%*%X)
            mu.mat <- var.mat%*%(t(X)%*%gammainv.mat%*%muhat)

            samp <- c(tauh,tauc,rmultt(mu.mat,var.mat,multt.df))
            logprob.val <- logP.rej(samp,data,prior)-logQ.rej(samp,mu.mat,var.mat,multt.df,data,prior)-K2
            logprob <- c(logprob,logprob.val)
            
            if (logprob.val>0)
              {
                cat("not in envelope (log-scale prob=",logprob.val,")\n")
                notenv <- notenv + 1
                notenv <- 1
                break
              }
            else
              {
#                cat("woof\n")
#                acc.prob <- exp(acc.prob)
                if (log(runif(1))<logprob.val)
                  {
                    samp.EXACT <- rbind(samp.EXACT,samp)
                    numacc <- numacc+1
                  }
              }
          }
        
        if (notenv)
          {
            K2 <- K2 + max(logprob) # increase the constant until an envelope is found
            numit <- numit+1
            cat("new K2=",K2,"\n")
          }
        
        cat("numit=",numit,"\n")
        
      }

    if (numacc==0)
      cat("zero acceptance rate: decrease the value of K2 (try K2=",max(logprob)+K2," for instance)\n")
      
#    return(list(samples=samp.EXACT,acc=numacc,notenv=notenv,logprob=logprob,NUMtauc=length(tauc),K2=K2,allsamp=allsamp))
    return(list(samples=samp.EXACT,acc=numacc,notenv=notenv,logprob=logprob,NUMtauc=length(tauc),K2=K2))
  }

# the tau's were sampled from a bivariate-LT(mu1,sigma1,df1,mu2,sigma2,df2) (log-t)
# then, the (theta,phi)s are sampled conditional on the taus from a Multi-t
# a SINGLE accept-reject step is done to sample from the correct distribution
sampleTHETA.lt2 <- function(NUMSAMP,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,K2,data=toydata,prior=toyprior,changeK=F)
  {
    Vinv <- diag(data$data$Y)
    V <- diag(1/data$data$Y)
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    etahat <- log(data$data$Y/data$data$E)
    muhat <- c(etahat,rep(0,N+numadj))
    Y <- data$data$Y
    
#    print(X)      
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
        
    while (notenv) # while there is at least one sample produced outside the envelope
      {
        notenv <- 0 # assume envelope works ok at the start
        numacc <- 0
        logprob <- c()
        
        samp.EXACT <- c() # to hold accepted samples

        allsamp <- c()

#        taulength <- dim(tau)[1] # number of (tauh,tauc) pairs

        for (i in 1:NUMSAMP)
          {
            taucand <- c(rlt(1,meanlog=mu1,sdlog=sigma1,t.df1),
                       rlt(1,meanlog=mu2,sdlog=sigma2,t.df2))
            tauh <- taucand[1]
            tauc <- taucand[2]

            # Dec.8th version (faster than above since only one matrix inversion)
            A22 <- solve(Vinv + tauc*Q - diag(Y*Y/(Y+tauh))) # use sparse matrix alg. for this
            A12 <- -diag(Y/(Y+tauh))%*%A22
            A11 <- diag(1/(Y+tauh))-A12%*%diag(Y/(Y+tauh))
            A21 <- t(A12)
            
            var.mat <- rbind(cbind(A11, A12),cbind(A21,A22))
            
            if (is.null(class(var.mat))) # only proceed if no error, else generate a new sample
              {
                mu.mat <- var.mat%*%transfmuhat
                samp <- c(tauh,tauc,rmultt(mu.mat,var.mat,multt.df))
                logP.val <- logP.rej(samp,data,prior)
                logQ.val <- try(logQ.rej.onestage(samp,mu.mat,var.mat,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,data,prior))
                logprob.val <- logP.val-logQ.val-K2
                logprob <- c(logprob,logprob.val)
                if (logprob.val>0)
                  {
                    cat("not in envelope (log-scale prob=",logprob.val,")\n")
                    notenv <- notenv + 1
                    notenv <- 1
                    if (changeK) # if we are to fix upper bound, quit this loop immediately
                      break
                  }
                else
                  {
                    if (log(runif(1))<logprob.val)
                      {
                        samp.EXACT <- rbind(samp.EXACT,samp)
                        numacc <- numacc+1
                      }
                  }
              }
          }
        
        if (!changeK) # if empirical bound is not to be updated
          {
            if (notenv)
              {
                cat("warning:",notenv,"sample(s) generated outside envelope\n")
              }
            notenv <- 0 # pretend no samples were generated outside the envelope, exit loop
          }
            
        if (notenv) # if at least one sample was generated outside envelope(and bound is to be updated)
          {
            K2 <- K2 + max(logprob) # increase the constant until an envelope is found
            numit <- numit+1
            cat("new K2=",K2,"\n")
          }
        
        cat("numit=",numit,"\n")
      }
    if (numacc==0)
      cat("zero acceptance rate: decrease the value of K2 (try K2=",max(logprob)+K2," for instance)\n")
    return(list(samples=samp.EXACT,acc=numacc,notenv=notenv,NUMSAMP=NUMSAMP,K2=K2,numit=numit,accrate=numacc/NUMSAMP,logprob=logprob))
  }

# Dec.20, 2002
# same as sampleTHETA.lt2, but
# sparse matrix algorithms are used to speed things up
rej.sparse <- function(NUMSAMP,multt.df,mu1,sigma1,t.df1,mu2,sigma2,t.df2,K2,data=toydata,prior=toyprior,changeK=F)
  {
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    nu <- multt.df
    
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    # find permutation that minimizes bandwidth: done only once
    source("band.min.R")
    band.min.Q <- band.min(Q)
    permut <- band.min.Q$permut
    rev.permut <- band.min.Q$origpermut
    bw <- band.min.Q$bandwd
    
    # all of the following vectors and matrices are permuted according to above
    Y <- data$data$Y[permut]
    E <- data$data$E[permut]
    etahat <- log(Y/E)
    Vinv <- diag(Y)
    Q <- Q[permut, permut]
    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
    d <- transfmuhat
    Zeros <- matrix(0, N, N)
          
    source("band.chol.R") # for band choleski

    while (notenv) # while there is at least one sample produced outside the envelope
      {
        notenv <- 0 # assume envelope works ok at the start
        numacc <- 0
        logprob <- c()
       
        samp.EXACT <- c() # to hold accepted samples

        allsamp <- c()

#        taulength <- dim(tau)[1] # number of (tauh,tauc) pairs

        for (i in 1:NUMSAMP)
          {
            taucand <- c(rlt(1,meanlog=mu1,sdlog=sigma1,t.df1),
                         rlt(1,meanlog=mu2,sdlog=sigma2,t.df2))
            tauh <- taucand[1]
            tauc <- taucand[2]
            
            # fast choleski decomposition of Sigmainv (precision matrix)
            U11 <- diag(sqrt(Y+tauh))
            U12 <- diag(Y/sqrt(Y+tauh))

            temp <- (Vinv+tauc*Q) - diag(Y^2/(Y+tauh))
            U22 <- chol.band(temp, bw) # band choleski decomp.
            U <- rbind(cbind(U11,U12), cbind(Zeros,U22))

            # if desired precision is sigmainv, the matrix in Multi-t=sigmainv*(nu/(nu-2))
            # so, need to correct for degrees of freedom
            cor.df <- (nu/(nu-2))
            U <- U*sqrt(cor.df)

            v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
            m <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
            # now need to 'correct back'
            # m= cov.matrix*(nu-2)/nu * d, but we want, m=cov.matrix*d
            m <- m*nu/(nu-2)
            
            z <- as.matrix(rnorm(2*N)) # normal(0,1) r.v.s
            y <- backsolve(U, z, upper.tri = TRUE, transpose = FALSE)#y~N(0,B^(-1))
            s <- rchisq(1,nu)
            
            w <- y/sqrt(s/nu) # w ~ MT(0, B^(-1))
            r <- m+w # r ~ MT(m, B^(-1))
            x <- r[c(rev.permut, N+rev.permut)] # x ~ MT(A^(-1)b, A^(-1))
            samp <- c(tauh, tauc,x)
            logP.val <- logP.rej(samp,data,prior)

            # evaluating the multivariate-t density at the sampled value
            logdet <- sum(log(diag(U))) # log(det(Sigma^(-1))^(0.5))
            temp.val <- U%*%(r-m) # U%*%(r-m)
            temp.val <- t(temp.val)%*%temp.val # (r-m)^T B (r-m)

            # important: note, in formula below, we have 2N (not N), because
            # dimension of Multi-t is 2N
            logQ.THETA.val <- logdet-0.5*(nu+2*N)*log(1 + (1/nu)*temp.val) 
            logQ.tau.val <- logbivdlt(c(tauh,tauc),mu1,sigma1,t.df1,mu2,sigma2,t.df2)
            logQ.val <- logQ.tau.val+logQ.THETA.val

            logprob.val <- logP.val-logQ.val-K2
                    
            logprob <- c(logprob,logprob.val)
            if (logprob.val>0)
              {
                cat("not in envelope (log-scale prob=",logprob.val,")\n")
                notenv <- notenv + 1
                notenv <- 1
                if (changeK) # if we are to fix upper bound, quit this loop immediately
                  break
              }
            else
              {
                if (log(runif(1))<logprob.val)
                  {
                    samp.EXACT <- rbind(samp.EXACT,as.numeric(samp))
                    numacc <- numacc+1
                  }
              }
          }
        
        if (!changeK) # if empirical bound is not to be updated
          {
            if (notenv)
              {
                cat("warning:",notenv,"sample(s) generated outside envelope\n")
              }
            notenv <- 0 # pretend no samples were generated outside the envelope, exit loop
          }
            
        if (notenv) # if at least one sample was generated outside envelope(and bound is to be updated)
          {
            K2 <- K2 + max(logprob) # increase the constant until an envelope is found
            numit <- numit+1
            cat("new K2=",K2,"\n")
          }
        
        cat("numit=",numit,"\n")
      }

    if (numacc==0)
      cat("zero acceptance rate: decrease the value of K2 (try K2=",max(logprob)+K2," for instance)\n")

    notenv <- sum(logprob>0) # count number of samples outside envelope
    if (notenv>0)
      addlogK <- max(logprob)
    else
      addlogK <- 0 # no need to fix the bounding constant

    if (numacc>0)
      return(list(samp=as.matrix(samp.EXACT),acc=numacc,notenv=notenv,NUMSAMP=NUMSAMP,K2=K2,numit=numit,accrate=numacc/NUMSAMP,addlogK=addlogK))
    else
      return(list(samp=c(),acc=numacc,notenv=notenv,NUMSAMP=NUMSAMP,K2=K2,numit=numit,accrate=numacc/NUMSAMP,addlogK=addlogK))
  }

# univariate MCMC
univ <- function(NUMSAMP,adjvect,data=toydata,prior=toyprior,thin=10)
  {
    # tuning parameters for Random Walk MCMC
    sd.theta <- 0.1
    sd.phi <- 0.1

    Y <- data$data$Y
    E <- data$data$E
    
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    
    alphah <- prior$alphah
    betah <- prior$betah
    alphac <- prior$alphac
    betac <- prior$betac

    tauh <- rep(0,NUMSAMP)
    tauc <- rep(0,NUMSAMP)
    theta <- matrix(0,NUMSAMP,N)
    phi <- matrix(0,NUMSAMP,N)

    # starting values
    tauh[1] <- 1
    tauc[1] <- 1

    theta[1,] <- rnorm(N)
    phi[1,] <- rnorm(N)
    
    for (i in 2:NUMSAMP)
      {
        prev <- i-1

        # Gibbs sample tauh, tauc
        tauh[i] <- rgamma(1,shape=N/2+alphah, scale=(1/(sum(theta[prev,]^2)/2 + 1/betah)))

        sum.adj <- sum(phi[prev,]*(Q%*%phi[prev,]))
        tauc[i] <- rgamma(1,shape=M/2+alphac, scale=(1/(sum.adj/2 + 1/betac)))

#        cat("shape=",N/2+alphah,",",M/2+alphac,"\n")
#        cat("scale=",(1/(sum(theta^2)/2 + 1/betah)),",",(1/(sum.adj/2 + 1/betah)),"\n")
        
        # default values at next iteration are the current values of the chain
        # (unless proposed values are accepted below)
        theta[i,] <- theta[prev,]
        phi[i,] <- phi[prev,]

        # sampling the theta_is using Random-Walk Metropolis
        for (j in 1:N)
          {
            logalpha.den <- theta[i,j]*Y[j]-E[j]*exp(theta[i,j]+phi[i,j])-(tauh[i]*theta[i,j]^2)/2

            prop <- rnorm(1, mean=theta[i,j], sd=sd.theta)
            logalpha.num <- prop*Y[j]-E[j]*exp(prop+phi[i,j])-(tauh[i]*prop^2/2)
            
            logalpha <- logalpha.num - logalpha.den
#            cat("logalpha.num=",logalpha.num,"\n")
#            cat("logalpha.den=",logalpha.den,"\n")
#            cat("logalpha=",logalpha,"\n")

            U <- runif(1)
            if (log(U)<logalpha) # if U<alpha, accept proposal (else stay with curr.value)
              theta[i,j] <- prop
          }

        # sampling the phi_is  using Random-Walk Metropolis
        for (j in 1:N)
          {
            sum.adj <- 0
            for (k in seq(1,length(adjvect), by=2))
              {
                if (adjvect[k]==j) # if adjacency pair (j,?) is found
                  sum.adj <- sum.adj+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
                if (adjvect[k+1]==j) # if adjacency pair (?,j) is found
                  sum.adj <- sum.adj+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
              }

#            sum.adj <- sum(phi[prev,]*(Q%*%phi[prev,]))
            logalpha.den <- phi[i,j]*Y[j]-E[j]*exp(theta[i,j]+phi[i,j])-(tauc[i]*sum.adj)/2

            prop <- rnorm(1, mean=phi[i,j], sd=sd.phi)
            sum.adj.prop <- 0
            phi[i,j] <- prop # temporarily for calculations below
            for (k in seq(1,length(adjvect), by=2))
              {
                if (adjvect[k]==j) # if adjacency pair (j,?) is found
                  sum.adj.prop <- sum.adj.prop+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
                if (adjvect[k+1]==j) # if adjacency pair (?,j) is found
                  sum.adj.prop <- sum.adj.prop+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
              }

#            sumadj.prop <- sum(phi[prev,]*(Q%*%phi[prev,]))
            logalpha.num <- phi[i,j]*Y[j]-E[j]*exp(theta[i,j]+phi[i,j])-(tauc[i]*sum.adj.prop)/2

            logalpha <- logalpha.num - logalpha.den
            
            U <- runif(1)
            if (log(U)<logalpha) # if U<alpha, accept proposal (else stay with curr.value)
              phi[i,j] <- prop
            else
              phi[i,j] <- phi[prev,j] 
          }
      }
    
    thin.ind <- seq(1,NUMSAMP,by=thin) # index with samples thinned out
    return(list(NUMSAMP=NUMSAMP,samp=cbind(tauh[thin.ind],tauc[thin.ind],theta[thin.ind],phi[thin.ind])))
  }            
            
# function to compute statistics from output - these are printed to screen
model2stats <- function(out)
{
  if (!is.null(out$samples))
    samp <- out$samples
  else
    samp <- out
  
  meanlist <- apply(samp,2,mean)
  sdlist <- apply(samp,2,sd)
  N <- (length(samp[1,])-2)/2
  
  for (i in 3:(N+2))
    cat("theta",(i-2)," ",meanlist[i]," ",sdlist[i],"\n")
  for (i in (N+3):(2*N+2))
    cat("phi",(i-(N+2))," ",meanlist[i]," ",sdlist[i],"\n")

  cat("tau_h",meanlist[1]," ",sdlist[1],"\n")
  cat("tau_c",meanlist[2]," ",sdlist[2],"\n")

  if (!is.null(out$samples))
    cat("number of samples=",out$acc,",","acc rate=",out$acc/out$NUMSAMP,"\n")
  else
    cat("number of samples=",dim(out)[1],"\n")
  
  return(list(means=meanlist,sds=sdlist))
}


# new version with better formatting
model2stats <- function(out,getMCse=TRUE)
{
  if (!is.null(out$samples))
    samp <- out$samples
  else
    samp <- out
  
  meanlist <- apply(samp,2,mean)
  sdlist <- apply(samp,2,sd)
  N <- (length(samp[1,])-2)/2
  NUMSAMP <- dim(samp)[1]

  stat.mat <- cbind(meanlist[3:(2*N+2)], sdlist[3:(2*N+2)]) #only thetas,phis
  dimnames(stat.mat) <- c(list(c(paste("theta",1:N,sep="_"), paste("phi",1:N,sep="_")), c("mean","sd")))

  print(stat.mat)
  cat("tau_h",meanlist[1]," ",sdlist[1],"\n")
  cat("tau_c",meanlist[2]," ",sdlist[2],"\n")

  if (!is.null(out$samples))
    cat("number of samples=",out$acc,",","acc rate=",out$acc/out$NUMSAMP,"\n")
  else
    cat("number of samples=",dim(out)[1],"\n")

  if (getMCse)
    {
      mean.MCse <- sdlist/sqrt(NUMSAMP)
      print(sdlist)
      print(sqrt(NUMSAMP))
      sd.MCse <- sqrt(apply(apply(samp,2,function(x) x^2), 2,  sd)/sqrt(NUMSAMP)) # s.dev. of X^2 for each parameter (column) 
    }

  if (getMCse)
    return(list(means=meanlist,sds=sdlist,mean.MCse=mean.MCse,sd.MCse=sd.MCse))
  else
    return(list(means=meanlist,sds=sdlist))
}

# input: samp (matrix of samples, each column corresponding to some
# variable, and rows corresponding to different samples)
# output: ESS (effective sample sizes)
# using initial monotone positive sequence estimator (Geyer, 1992)
stats.MCMC <- function(samp,ind,times=-1)
  {
    MAXLAG <- 50 # never compute more than lag MAXLAG
    if (times>0) # if timing provided, compute ES/s
      calcESpersec<- TRUE
    else
      calcESpersec<- FALSE
    
    ESS <- rep(0,length(ind))
    AC1 <- rep(0,length(ind))
    AC5 <- rep(0,length(ind))
    AC10 <- rep(0,length(ind))
    
    NUMSAMP <- dim(samp)[1] # number of rows
    auto.time <- rep(0,length(ind))
               
    for (i in ind) # for each parameter of interest
      {
        acfs <- acf(samp[,i], type="correlation",plot=FALSE,lag.max=MAXLAG)$acf[,,1]

        Gammas <- acfs[1: (length(acfs)-1)] + acfs[2:length(acfs)]

        k <- 1
        while ((k<length(Gammas)) && (Gammas[k+1]>0) && (Gammas[k]>=Gammas[k+1]))
          k <- k+1

        auto.time[i] <- sum(acfs[1:k])
        ESS[i] <- NUMSAMP/auto.time[i]
        AC1[i] <- acfs[2]
        AC5[i] <- acfs[6]
        AC10[i] <- acfs[11]
      }

    if (calcESpersec)
      return(list(ESS=ESS,auto=auto.time,ESpersec=ESS/times,AC1=AC1,AC5=AC5,AC10,AC10))
    else
      return(list(ESS=ESS,auto=auto.time,AC1=AC1,AC5=AC5,AC10=AC10))
  }
