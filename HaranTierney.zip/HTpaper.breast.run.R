exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R") # load in important functions

breast.data = readSimpleData("breastcancer")
breast.prior = list(alphah=1,betah=100,alphac=1, betac=50)
breast.proppars = list(multtdf=50,muh=5.42,sigmah=0.6,muc=4.59,sigmac=0.7,tdfh=50,tdfc=50)
breast.logbound = -2869.809
breast.mixprob = list(logpi0=log(1),logpi1=-breast.logbound)
breast.temp.par = list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

## ALGORITHMS
## run uniformly ergodic block MCMC (independence chain)
N=100000 #10000
#set.seed(1)
#mcmc.time=system.time((mcmcout=blockMCMC(NUMSAMP=N,proppars=breast.proppars,coord=c(1,2,9,96,17,104,58,145),data=breast.data,prior=breast.prior,outfile="mcmcout.breast",writeevery=1)))
#write(mcmcout$accrate,"mcmcacc.breast")
#write(mcmc.time,"mcmctime.breast")

## run rejection sampler
#set.seed(1)
#rej.time=system.time((rejout = rejsamp(N,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-2866.039,changebound=FALSE,outfile="rejout.breast")))
#write(rejout$accrate,"rejacc.breast")
#write(rej.time,"rejtime.breast")

## run univariate MCMC
N=100000
startsamp=genstartval(breast.data,proppars=breast.proppars)
breast.adjvect=scan("breastcancer.adjvect")
breast.univ.mod2.time <- system.time((breast.univ.mod2 <- univ(N,adjvect=breast.adjvect, data=breast.data,prior=breast.prior,coord=c(1,2,9,96,17,104,58,145),startval=startsamp$samp)))
write.table(breast.univ.mod2$samp,"univout.breast")
write(breast.univ.mod2.time,"univtime.breast")

## run perfect tempering sampler

## look at results
univout.breast=read.table("univout.breast")
mcmcout.breast=read.table("mcmcout.breast")
rejout.breast=read.table("rejout.breast")
postscript("breastresults.ps")
densvals=c(density(univout.breast[,1])$y, density(mcmcout.breast[,1])$y, density(rejout.breast[,1])$y)
plot(density(univout.breast[,1]),col="green",main="Posteriors from several algorithms",xlab=expression(tau[h]),ylab="",cex.lab=2,ylim=c(min(densvals), max(densvals)))
lines(density(mcmcout.breast[,1]),col="blue",lty=2)
lines(density(rejout.breast[,1]),col="red",lty=5)
dev.off()

##write(mcmcout$samp,"outsamp")
