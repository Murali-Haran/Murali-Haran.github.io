exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R")
#source("~/public_html/batchmeans.R")
breast.data <- readSimpleData(paste(exactdir,"/breastcancer",sep=""))
breast.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
breast.proppars <- list(multtdf=50,muh=5.42,sigmah=0.6,muc=4.59,sigmac=0.7,tdfh=50,tdfc=50)
breast.logbound <- -2869.809
breast.mixprob <- list(logpi0=log(1),logpi1=-breast.logbound)
breast.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

############################################################################################################
## run block MCMC (independence chain)
############################################################################################################
set.seed(1)
#mcmcout=blockMCMC(NUMSAMP=100000,proppars=breast.proppars,coord=c(1,2,9,96,17,104,58,145),data=breast.data,prior=breast.prior,outfile="mcmcsamp",writeevery=100)
mcmcrun=blockMCMC(NUMSAMP=100000,proppars=breast.proppars,coord=c(1,2,9,96,17,104,58,145),data=breast.data,prior=breast.prior,outfile="mcmcout",writeevery=1)
write(mcmcrun$accrate,"mcmcacc")
