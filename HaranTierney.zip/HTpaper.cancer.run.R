exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R") # load in important functions

cancer.data = readSimpleData("cancer")
cancer.prior = list(alphah=1,betah=100,alphac=1, betac=50)
cancer.proppars <- list(multtdf=50,muh=4.3,sigmah=2.1,muc=-0.95,sigmac=0.4,tdfh=50,tdfc=50)
cancer.logbound <- 4195.395
cancer.mixprob <- list(logpi0=log(1),logpi1=-cancer.logbound)
cancer.temp.par = list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

## ALGORITHMS
## run uniformly ergodic block MCMC (independence chain)
N=100 #10000
set.seed(1)
mcmc.time=system.time((mcmcout=blockMCMC(NUMSAMP=N,proppars=cancer.proppars,coord=c(1,2,9,96,17,104,58,145),data=cancer.data,prior=cancer.prior,outfile="mcmcout.cancer",writeevery=1)))
write(mcmcout$accrate,"mcmcacc.cancer")
write(mcmc.time,"mcmctime.cancer")

## run rejection sampler
set.seed(1)
rej.time=system.time((rejout = rejsamp(N,cancer.proppars,coord=c(1,2,9,96,17,104,58,145),cancer.data,cancer.prior,logbound=-2866.039,changebound=FALSE,outfile="rejout.cancer")))
write(rejout$accrate,"rejacc.cancer")
write(rej.time,"rejtime.cancer")

## run univariate MCMC
startsamp=genstartval(cancer.data,proppars=cancer.proppars)
cancer.adjvect=scan("cancercancer.adjvect")
cancer.univ.mod2.time <- system.time((cancer.univ.mod2 <- univ(N,adjvect=cancer.adjvect, data=cancer.data,prior=cancer.prior,coord=c(1,2,9,96,17,104,58,145),startval=startsamp$samp)))
write.table(cancer.univ.mod2$samp,"univout.cancer")
write(cancer.univ.mod2.time,"univtime.cancer")

## run perfect tempering sampler

## look at results
univout.cancer=read.table("univout.cancer")
mcmcout.cancer=read.table("mcmcout.cancer")
rejout.cancer=read.table("rejout.cancer")
postscript("cancerresults.ps")
densvals=c(density(univout.cancer[,1])$y, density(mcmcout.cancer[,1])$y, density(rejout.cancer[,1])$y)
plot(density(univout.cancer[,1]),col="green",main="Posteriors from several algorithms",xlab=expression(tau[h]),ylab="",cex.lab=2,ylim=c(min(densvals), max(densvals)))
lines(density(mcmcout.cancer[,1]),col="blue",lty=2)
lines(density(rejout.cancer[,1]),col="red",lty=5)
dev.off()

##write(mcmcout$samp,"outsamp")

