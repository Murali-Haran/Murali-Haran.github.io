#exactdir = "/home6/muh10/exact/"
if (!exists("exactdir"))
  exactdir <- "/home/mharan/exact" # location of directory with functions for exact sampling
# read in functions for multivariate-t generation and density
source(paste(exactdir,"/multt.R",sep=""))
# read in functions for log-t generation and density
source(paste(exactdir,"/lt.R",sep=""))
# read in functions for band matrix operations
source(paste(exactdir,"/band.min.R",sep=""))
source(paste(exactdir,"/band.chol.R",sep=""))

options(show.error.messages = TRUE)

readSimpleData <-  function(name) {
    data <- read.table(paste(name, ".data.R", sep=""));
    names(data) <- c("Y","E")
    N <- nrow(data)
    Q <- matrix(scan(paste(name,".Q",sep="")), N, N)
    list(data=data, Q=Q)
}

create.setup <- function(data)
  {
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    # find permutation that minimizes bandwidth: done only once
    band.min.Q <- band.min(Q)
    permut <- band.min.Q$permut
    rev.permut <- band.min.Q$origpermut
    bw <- band.min.Q$bandwd
    
    # all of the following vectors and matrices are permuted according to above
    Y <- data$data$Y[permut]
    E <- data$data$E[permut]
    etahat <- log(Y/E)
    Vinv <- diag(Y)
    Q <- Q[permut, permut]
    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
    d <- transfmuhat
    Zeros <- matrix(0, N, N)

    setup <- list(Q=Q,N=N,Vinv=Vinv,numadj=numadj,Y=Y,E=E,d=d,Zeros=Zeros,Id=Id,permut=permut,rev.permut=rev.permut,bw=bw)
#    setup <- list(X=X,numadj=numadj,muhat=muhat,N=N)

    return(setup)
  }

## sequential sampler to produce a single draw from proposal distribution
## if evaluatedens=TRUE, also evaluate the proposal density at proposed value
## note: proposal density includes all the normalizing constants
seqsamp <- function(proppars,setup,evaluatedens=TRUE)
  {
    multtdf <- proppars$multtdf
    muh <- proppars$muh
    sigmah <- proppars$sigmah
    muc <- proppars$muc
    sigmac <- proppars$sigmac
    tdfh <- proppars$tdfh
    tdfc <- proppars$tdfc

    ## sample from log-t densities
    tauh <- rlt(1,meanlog=muh,sdlog=sigmah,tdfh)
    tauc <- rlt(1,meanlog=muc,sdlog=sigmac,tdfc)
    ## sample from appropriate multivariate-t, conditional on log-t
    ## setup <- create.setup(data=toydata)
    ## get matrices etc. with everything already permuted
    Q <- setup$Q
    Y <- setup$Y
    d <- setup$d
    Zeros <- setup$Zeros
    Id <- setup$Id
    permut <- setup$permut
    rev.permut <- setup$rev.permut
    Vinv <- setup$Vinv
    bw <- setup$bw
    N <- setup$N
    nu <- multtdf # for convenience
    ## end setup
        
    ## fast choleski decomposition of Sigmainv (precision matrix)
    U11 <- diag(sqrt(Y+tauh))
    U12 <- diag(Y/sqrt(Y+tauh))
    
    temp <- (Vinv+tauc*Q) - diag(Y^2/(Y+tauh))
    U22 <- chol.band(temp, bw) # band choleski decomp.
    U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
    ## if desired precision is sigmainv, the matrix in Multi-t=sigmainv*(nu/(nu-2))
    ## so, need to correct for degrees of freedom
    cor.df <- (nu/(nu-2))
    U <- U*sqrt(cor.df)
        
    v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
    m <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
    ## now need to 'correct back'
    ## m= cov.matrix*(nu-2)/nu * d, but we want, m=cov.matrix*d
    m <- m*nu/(nu-2)
    
    z <- as.matrix(rnorm(2*N)) # normal(0,1) r.v.s
    y <- backsolve(U, z, upper.tri = TRUE, transpose = FALSE)#y~N(0,B^(-1))
    s <- rchisq(1,nu)
    
    w <- y/sqrt(s/nu) # w ~ MT(0, B^(-1))
    r <- m+w # r ~ MT(m, B^(-1))
    x.new <- r[c(rev.permut, N+rev.permut)] # x ~ MT(A^(-1)b, A^(-1))
    samp <- c(tauh, tauc,x.new)

    if (any(apply(as.matrix(samp),1,is.na)))
      cat("NA in sample\n")
    ## DONE SAMPLING

    if (evaluatedens) # compute logR at proposal (do this right away for efficiency reasons)
      {
        ## evaluating KERNEL of multivariate-t density at the sampled value
        logdet <- sum(log(diag(U))) # log(det(Sigma^(-1))^(0.5))
        temp.val <- U%*%(r-m) # U%*%(r-m)
        temp.val <- t(temp.val)%*%temp.val # (r-m)^T B (r-m)
##        const.val <- log(gamma((nu+2*N)/2))-log(gamma(nu/2))-(2*N/2)*log(nu*pi) July 7th change
        const.val <- lgamma((nu+2*N)/2)-lgamma(nu/2)-(2*N/2)*log(nu*pi) # July 7th: use lgamma for numerical stability
        logR.THETA.val <- logdet-0.5*(nu+2*N)*log(1 + (1/nu)*temp.val)+const.val
        logR.tauh.val <- logdlt.nor(tauh,muh,sigmah,tdfh)
        logR.tauc.val <- logdlt.nor(tauc,muc,sigmac,tdfc)
        logR.val <- logR.tauh.val+logR.tauc.val+logR.THETA.val
      }
    else
      logR.val <- FALSE 

    return(list(samp=samp,logR.val=logR.val))
 }

## rejection sampling algorithm using sparse matrix operations
## if changebound=TRUE, rerun rejection sampler with new bounds until no out-of-sample bounds are found
## rej <- rejsamp(1000,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-Inf,changebound=TRUE)
## rej <- rejsamp(1000,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=-2866.039,changebound=FALSE)
## if FIXEDNUM is TRUE, run until NUMITER samples are obtained
rejsamp <- function(NUMITER,proppars,coord,data,prior,logbound,changebound=FALSE,MAXTRY=10,FIXEDNUM=FALSE,outfile)
  {
    setup <- create.setup(data)
    ## initialize output file
    write("",outfile) #accept modified May 1, 2007
    
    MAXNUMITER <- 100000000 # a very large number
    if (is.na(coord[1])) # default: all parameters are monitored
      coord <- 1:((2*setup$N)+2)
    nummonitor=length(coord)
    
    newlogbound <- logbound # initialize (in case there are bound violations)
    numtry <- 1
    runflag <- TRUE # as long as TRUE, keep running the while loop
    if (FIXEDNUM)
      {
        NUMSAMP <- NUMITER # number of samples wanted is set to NUMITER
        NUMITER <- MAXNUMITER # number of iterations is set to large number
      }
    while (runflag && (numtry<MAXTRY))# if changebound is TRUE, need to check that there are no bound violations, and that maximum number of attempts has not been exceeded
      {
        cat("attempt ",numtry," with log(bound)=",newlogbound,"\n")
##        samp <- c() # initialize matrix of samples modified May 1, 2007
        numacc <- 0
        notinenv <- 0# initialize
        for (i in 1:NUMITER)
          {
            prop <- seqsamp(proppars,setup)
            logP.val <- logP.rej(prop$samp,data,prior)
            logR.val <- prop$logR.val
            logratio <- logP.val-logR.val
            U <- runif(1)
            if (logratio>logbound)  # keep track of bound violations
              {
                notinenv <- notinenv+1
                if (logratio>newlogbound)
                  newlogbound <- logratio # keep largest bound violation
                if (changebound) ## exit at first bound violation
                  {
                    logbound <- newlogbound
                    break
                  }
              }
            if (log(U)<(logratio-logbound)) # accept-reject step
              {
                numacc <- numacc+1
                ##samp <- rbind(samp,prop$samp[coord]) #accept # modified May 1, 2007
                write(prop$samp[coord],outfile,ncolumns=nummonitor,append=TRUE) #accept modified May 1, 2007
                if (FIXEDNUM) # if exit after fixed number of samples obtained
                  if (numacc==NUMSAMP) # done, exit
                    return(list(accrate=numacc/i,notinenv=notinenv,newlogbound=newlogbound)) #modified May 1, 2007
##                    return(list(samp=samp,acc=numacc/i,notinenv=notinenv,newlogbound=newlogbound)) modified May 1, 2007
              }
          }
        cat("num samples generated=",i,",numacc=",numacc,"\n")
        numtry <- numtry+1
        if ((!changebound) || (notinenv==0)) # if the bounds are not to be updated, or if no samples were out of bounds
          runflag <- FALSE # quit while loop

      }
    
    if (notinenv>0)
      cat("WARNING: rejection ratio bounds violated\n")
    if (numacc==0) # no samples returned
      cat("WARNING: no samples were accepted\n")
##    return(list(samp=as.matrix(samp),acc=numacc/NUMSAMP,notinenv=notinenv,newlogbound=newlogbound))
##    return(list(samp=samp,acc=numacc/i,notinenv=notinenv,newlogbound=newlogbound))  # May 1, 2007
    return(list(accrate=numacc/i,notinenv=notinenv,newlogbound=newlogbound)) # May 1, 2007
  }
