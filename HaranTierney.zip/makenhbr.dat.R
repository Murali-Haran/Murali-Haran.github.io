# program specifically written for Germany data set
# take in germany.graph, return file in the format
# of breastcancer.nhbr.dat

makeadjvect <- function(inpfile,NUMREGIONS,outpfile,addone=FALSE)
  {
    nhbrvec <- scan(inpfile)
    adjvect <- c()

    j <- 1
    for (i in 1:NUMREGIONS)
      {
        j <- j+1 # skip label for region
        numnhbr <- nhbrvec[j]
        cat("numnhbr=",numnhbr,"\n")
        nhbr <- nhbrvec[(j+1):(j+numnhbr)]

        if (addone)
          nhbr <- nhbr+1 # instead of 0,..NUMREGIONS-1, change to 1,..,NUMREGIONS
        
        for (k in 1:numnhbr)
          if (nhbr[k] > i) # this prevents repetitions 
            adjvect <- c(adjvect,i, nhbr[k])

        j <- j+numnhbr+1
      }
    
    sink(outpfile)
    for (i in 1:length(adjvect))
      if (adjvect[i] > 0)
        cat(adjvect[i],"");
    
    cat("\n")
    sink()
  }
# makeadjvect("../breastcancer/breastcancer.nhbr.dat",87,"out")
# makeadjvect("germany.graph",544,"germany.adjvect",addone=TRUE)
#mharan@iaasac:~/smcmc/germany2> wc germany.adjvect
#      1    2862   10835 germany.adjvect
# so, number of neighbors = 1431
#../makeQmatrix 544 1431 < germany.adjvect > germany.Q
# makeadjvect("germany2/germany.graph.quickfix",544,"germany.adjvect",addone=TRUE)
#mharan@iaasac:~/smcmc> wc germany.adjvect
#      1    2832   10774 germany.adjvect
# so, number of neighbors = 1416
#../makeQmatrix 544 1416 < germany.adjvect > germany.Q

# NOTE: above function works only if the regions and neighbors are
# IN ORDER, i.e., if ith row=ith region, which is not the case
# with Germany data;

## function below converts a valid Q matrix to a graph
## format of graph:  region1 nhbr1 nhbr2 ....
##                   region2 nhbr1 nhbr2 ....
Qtograph <- function(Qmat,outpfile)
  {
    NUMREGIONS = nrow(Qmat)

    regionlist=seq(1,NUMREGIONS)

    rowvals=Qmat[1,]
    nhbrlist=regionlist[rowvals==-1]
    write(c(1,nhbrlist),outpfile,append=FALSE)
    
    for (i in 2:NUMREGIONS)
      {
        rowvals=Qmat[i,]
        nhbrlist=regionlist[rowvals==-1]
        write(c(i,nhbrlist),outpfile,append=TRUE)
      }
  }

## function below converts a valid Q matrix to a list of pairwise adjacencies
## format:  regionX regionY regionZ regionW .... where (regionX,regionY) and (regionZ,regionW)
## are neighbors
## NOTE: a pair of neighbors should only show up once in the list
## e.g.  infant.Q = read.table("infant.Q")
##       Qtoadjvect(infant.Q,"infant.adjvect")  # this takes about 20secs, 1284 neighbor pairs
Qtoadjvect <- function(Qmat,outpfile)
  {
    NUMREGIONS = nrow(Qmat)
    regionlist=seq(1,NUMREGIONS)
    adjvec=c()
      
    for (i in 1:NUMREGIONS)
      {
        rowvals=Qmat[i,] # extract ith row
        nhbrlist=regionlist[(rowvals==-1) & (c(rep(FALSE,i), rep(TRUE,NUMREGIONS-i)))]
        for (nhbr in nhbrlist)
          adjvec=c(adjvec,i,nhbr)

      }
#    return(adjvec)
    cat(adjvec,file=outpfile)
  }

## count the number of neighbor pairs from a Q matrix
Qcountnhbrs <- function(Qmat)
  {
    NUMREGIONS = nrow(Qmat)
    regionlist=seq(1,NUMREGIONS)
    numnhbrs=0
    
    for (i in 1:NUMREGIONS)
      numnhbrs=numnhbrs + sum(Qmat[i,]==-1)

    cat("number of neighbor pairs=",numnhbrs/2,"\n")
  }
