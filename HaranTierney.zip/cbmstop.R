## function below is from fixedwidth directory, file cbm.R

## input: vals, a vector of N values (from a Markov chain), eps (s.error threshold)
## output: estimate of E(g(x)), length of chain (using stopping rule), skip=number of items to skip each time
## example of usage: cbmstop(mcmcout.colo$V1, 0.5, MINLEN=391000)  ## answer = 391876
## cbmstop(mcmcout.breast$V1, 0.5, MINLEN=525000) ## answer =525625
cbmstop <- function(vals,eps,skip=1,MINLEN=120,bs="sqroot",halfWidth=NA,alphalevel=0.05)
  {
##    MINLEN <- 120  # only start thresholding after 100 iterations
    chainlen <- length(vals)
    
    if (is.na(halfWidth)) # use threshold on MC s.error 
      for (i in seq(MINLEN,chainlen,by=skip))
        {
          bmres <- bm(vals[1:i],bs) # first i values
          if (bmres$se < eps)
            return(list(est=bmres$est,chainlen=i,se=bmres$se))
        }
    else ## else use threshold on halfwidth of C.I.
      for (i in seq(MINLEN,chainlen,by=skip))
        {
          bmres <- bm(vals[1:i],bs) # first i values
          ##          intervalhalf <- qt(1-(alphalevel/2),df=chainlen)*bmres$se # half the width of 95% CI
          intervalhalf <- qnorm(1-(alphalevel/2))*bmres$se # half the width of 95% CI
          
          if (intervalhalf < halfWidth)
            return(list(est=bmres$est,chainlen=i,se=bmres$se))
        }
      
    ## otherwise
    if (is.na(halfWidth))
      cat("chain not long enough (eps=",eps,",length=",chainlen,"s.error=",bmres$se,")\n")
    else
      cat("chain not long enough (halfWidth=",halfWidth,",length=",chainlen,"s.error=",bmres$se,")\n")
      
    return(list(est=bmres$est,chainlen=chainlen,se=bmres$se))
  }

## input: vals, a vector of N values (from a Markov chain), eps (s.error threshold)
## output: estimate of E(g(x)), length of chain (using stopping rule), skip=number of items to skip each time
sestop <- function(vals,eps,skip=1,MINLEN=120,bs="sqroot",halfWidth=NA,alphalevel=0.05)
  {
##    MINLEN <- 120  # only start thresholding after 100 iterations
    chainlen <- length(vals)
    
    if (is.na(halfWidth)) # use threshold on MC s.error 
      for (i in seq(MINLEN,chainlen,by=skip))
        {
          se <- sd(vals[1:i])/sqrt(i) # first i values
          if (se < eps)
            return(list(est=mean(vals[1:i]),chainlen=i,se=se))
        }
    else ## else use threshold on halfwidth of C.I.
      for (i in seq(MINLEN,chainlen,by=skip))
        {
          se <- sd(vals[1:i])/sqrt(i) # first i values
          ##          intervalhalf <- qt(1-(alphalevel/2),df=chainlen)*bmres$se # half the width of 95% CI
          intervalhalf <- qnorm(1-(alphalevel/2))*se # half the width of 95% CI
          
          if (intervalhalf < halfWidth)
            return(list(est=mean(vals[1:i]),chainlen=i,se=se))
        }
      
    ## otherwise
    if (is.na(halfWidth))
      cat("chain not long enough (eps=",eps,",length=",chainlen,"s.error=",se,")\n")
    else
      cat("chain not long enough (halfWidth=",halfWidth,",length=",chainlen,"s.error=",se,")\n")
      
    return(list(est=mean(vals[1:i]),chainlen=chainlen,se=se))
  }
