#exactdir = "/home6/muh10/exact/"
if (!exists("exactdir"))
  exactdir <- "/home/mharan/exact" # location of directory with functions for exact sampling
# read in functions for multivariate-t generation and density
source(paste(exactdir,"/multt.R",sep=""))
# read in functions for log-t generation and density
source(paste(exactdir,"/lt.R",sep=""))
# read in functions for band matrix operations
source(paste(exactdir,"/band.min.R",sep=""))
source(paste(exactdir,"/band.chol.R",sep=""))

readSimpleData <-  function(name) {
    data <- read.table(paste(name, ".data.R", sep=""));
    names(data) <- c("Y","E")
    N <- nrow(data)
    Q <- matrix(scan(paste(name,".Q",sep="")), N, N)
    list(data=data, Q=Q)
}

create.setup <- function(data)
  {
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    
    numit <- 0
    notenv <- 1 # if 1, then there is at least one sample outside envelope

    # find permutation that minimizes bandwidth: done only once
    band.min.Q <- band.min(Q)
    permut <- band.min.Q$permut
    rev.permut <- band.min.Q$origpermut
    bw <- band.min.Q$bandwd
    
    # all of the following vectors and matrices are permuted according to above
    Y <- data$data$Y[permut]
    E <- data$data$E[permut]
    etahat <- log(Y/E)
    Vinv <- diag(Y)
    Q <- Q[permut, permut]
    transfmuhat <- rbind(Vinv%*%etahat,Vinv%*%etahat) # added Dec.6th, stays fixed
    d <- transfmuhat
    Zeros <- matrix(0, N, N)

    setup <- list(Q=Q,N=N,Vinv=Vinv,numadj=numadj,Y=Y,E=E,d=d,Zeros=Zeros,Id=Id,permut=permut,rev.permut=rev.permut,bw=bw)
#    setup <- list(X=X,numadj=numadj,muhat=muhat,N=N)

    return(setup)
  }

## sequential sampler to produce a single draw from proposal distribution
## if evaluatedens=TRUE, also evaluate the proposal density at proposed value
## note: proposal density includes all the normalizing constants
seqsamp <- function(proppars,setup,evaluatedens=TRUE)
  {
    multtdf <- proppars$multtdf
    muh <- proppars$muh
    sigmah <- proppars$sigmah
    muc <- proppars$muc
    sigmac <- proppars$sigmac
    tdfh <- proppars$tdfh
    tdfc <- proppars$tdfc

    ## sample from log-t densities
    tauh <- rlt(1,meanlog=muh,sdlog=sigmah,tdfh)
    tauc <- rlt(1,meanlog=muc,sdlog=sigmac,tdfc)
    ## sample from appropriate multivariate-t, conditional on log-t
    ## setup <- create.setup(data=toydata)
    ## get matrices etc. with everything already permuted
    Q <- setup$Q
    Y <- setup$Y
    d <- setup$d
    Zeros <- setup$Zeros
    Id <- setup$Id
    permut <- setup$permut
    rev.permut <- setup$rev.permut
    Vinv <- setup$Vinv
    bw <- setup$bw
    N <- setup$N
    nu <- multtdf # for convenience
    ## end setup
        
    ## fast choleski decomposition of Sigmainv (precision matrix)
    U11 <- diag(sqrt(Y+tauh))
    U12 <- diag(Y/sqrt(Y+tauh))
    
    temp <- (Vinv+tauc*Q) - diag(Y^2/(Y+tauh))
    U22 <- chol.band(temp, bw) # band choleski decomp.
    U <- rbind(cbind(U11,U12), cbind(Zeros,U22))
    ## if desired precision is sigmainv, the matrix in Multi-t=sigmainv*(nu/(nu-2))
    ## so, need to correct for degrees of freedom
    cor.df <- (nu/(nu-2))
    U <- U*sqrt(cor.df)
        
    v <- backsolve(U, d, upper.tri = TRUE, transpose = TRUE)
    m <- backsolve(U, v, upper.tri = TRUE, transpose = FALSE)#m=B^(-1)d
    ## now need to 'correct back'
    ## m= cov.matrix*(nu-2)/nu * d, but we want, m=cov.matrix*d
    m <- m*nu/(nu-2)
    
    z <- as.matrix(rnorm(2*N)) # normal(0,1) r.v.s
    y <- backsolve(U, z, upper.tri = TRUE, transpose = FALSE)#y~N(0,B^(-1))
    s <- rchisq(1,nu)
    
    w <- y/sqrt(s/nu) # w ~ MT(0, B^(-1))
    r <- m+w # r ~ MT(m, B^(-1))
    x.new <- r[c(rev.permut, N+rev.permut)] # x ~ MT(A^(-1)b, A^(-1))
    samp <- c(tauh, tauc,x.new)

    if (any(apply(as.matrix(samp),1,is.na)))
      cat("NA in sample\n")
    ## DONE SAMPLING

    if (evaluatedens) # compute logR at proposal (do this right away for efficiency reasons)
      {
        ## evaluating KERNEL of multivariate-t density at the sampled value
        logdet <- sum(log(diag(U))) # log(det(Sigma^(-1))^(0.5))
        temp.val <- U%*%(r-m) # U%*%(r-m)
        temp.val <- t(temp.val)%*%temp.val # (r-m)^T B (r-m)
##        const.val <- log(gamma((nu+2*N)/2))-log(gamma(nu/2))-(2*N/2)*log(nu*pi) July 7th change
        const.val <- lgamma((nu+2*N)/2)-lgamma(nu/2)-(2*N/2)*log(nu*pi) # July 7th: use lgamma for numerical stability
        logR.THETA.val <- logdet-0.5*(nu+2*N)*log(1 + (1/nu)*temp.val)+const.val
        logR.tauh.val <- logdlt.nor(tauh,muh,sigmah,tdfh)
        logR.tauc.val <- logdlt.nor(tauc,muc,sigmac,tdfc)
        logR.val <- logR.tauh.val+logR.tauc.val+logR.THETA.val
      }
    else
      logR.val <- FALSE 

    return(list(samp=samp,logR.val=logR.val))
 }
## function to generate starting values from envelope distribution
genstartval=function(data,proppars)
  {
    setup <- create.setup(data)
    prop <- seqsamp(proppars,setup) # generate a new proposal

    return(prop)
  }


## univariate MCMC
## Note: This currently does not include beta parameters (regression coefficients)
univ <- function(NUMSAMP,adjvect,data=toydata,prior=toyprior,startval=c(),thin=1)
  {
    # tuning parameters for Random Walk MCMC
    sd.theta <- 0.1
    sd.phi <- 0.1

    Y <- data$data$Y
    E <- data$data$E
    
    Q <- data$Q
    N <- nrow(data$data)
    M <- N-1
    Id <- diag(rep(1,N)) # NxN Identity matrix
    # adjacency matrix
    numadj <- sum(Q==-1)/2
    
    alphah <- prior$alphah
    betah <- prior$betah
    alphac <- prior$alphac
    betac <- prior$betac

    tauh <- rep(NA,NUMSAMP)
    tauc <- rep(NA,NUMSAMP)
    theta <- matrix(NA,NUMSAMP,N)
    phi <- matrix(NA,NUMSAMP,N)
    cat("length=",length(tauh),length(tauc),length(theta),length(phi),"\n")

    ## starting values
    if (length(startval)==(2*N+2))
      {
        tauh[1] <- startval[1]
        tauc[1] <- startval[2]
        theta[1,] <- startval[3:(N+2)]
        phi[1,] <- startval[(N+3):(2*N+2)]
      }
    else # use default (bad) starting values
      {
        tauh[1] <- 1
        tauc[1] <- 1
        
        theta[1,] <- rnorm(N)
        phi[1,] <- rnorm(N)
      }
      
    for (i in 2:NUMSAMP)
      {
        prev <- i-1

        # Gibbs sample tauh, tauc
        tauh[i] <- rgamma(1,shape=N/2+alphah, scale=(1/(sum(theta[prev,]^2)/2 + 1/betah)))

        sum.adj <- sum(phi[prev,]*(Q%*%phi[prev,]))
        tauc[i] <- rgamma(1,shape=M/2+alphac, scale=(1/(sum.adj/2 + 1/betac)))

#        cat("shape=",N/2+alphah,",",M/2+alphac,"\n")
#        cat("scale=",(1/(sum(theta^2)/2 + 1/betah)),",",(1/(sum.adj/2 + 1/betah)),"\n")
        
        # default values at next iteration are the current values of the chain
        # (unless proposed values are accepted below)
        theta[i,] <- theta[prev,]
        phi[i,] <- phi[prev,]

        # sampling the theta_is using Random-Walk Metropolis
        for (j in 1:N)
          {
            logalpha.den <- theta[i,j]*Y[j]-E[j]*exp(theta[i,j]+phi[i,j])-(tauh[i]*theta[i,j]^2)/2

            prop <- rnorm(1, mean=theta[i,j], sd=sd.theta)
            logalpha.num <- prop*Y[j]-E[j]*exp(prop+phi[i,j])-(tauh[i]*prop^2/2)
            
            logalpha <- logalpha.num - logalpha.den
#            cat("logalpha.num=",logalpha.num,"\n")
#            cat("logalpha.den=",logalpha.den,"\n")
#            cat("logalpha=",logalpha,"\n")

            U <- runif(1)
            if (log(U)<logalpha) # if U<alpha, accept proposal (else stay with curr.value)
              theta[i,j] <- prop
          }

        # sampling the phi_is  using Random-Walk Metropolis
        print(theta[i,])
        print(phi[i,])
        for (j in 1:N)
          {
            sum.adj <- 0
            for (k in seq(1,length(adjvect), by=2))
              {
                if (adjvect[k]==j) # if adjacency pair (j,?) is found
                  {
                    cat("adj.pair=",phi[i,adjvect[k]],phi[i,adjvect[k+1]]," (",adjvect[k],",",adjvect[k+1],"\n")
                    sum.adj <- sum.adj+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
                  }
                if (adjvect[k+1]==j) # if adjacency pair (?,j) is found
                  {
                    cat("adj.pair=",phi[i,adjvect[k]],phi[i,adjvect[k+1]]," (",adjvect[k],",",adjvect[k+1],"\n")
                    sum.adj <- sum.adj+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
                  }
                cat("increment=",sum.adj," ")
              }
            cat("sum.adj=",sum.adj," ")
#            sum.adj <- sum(phi[prev,]*(Q%*%phi[prev,]))
            logalpha.den <- phi[i,j]*Y[j]-E[j]*exp(theta[i,j]+phi[i,j])-(tauc[i]*sum.adj)/2
            cat("logalpha.den=",logalpha.den,"\n")

            prop <- rnorm(1, mean=phi[i,j], sd=sd.phi)
            cat("prop=",prop,"\n")
            sum.adj.prop <- 0
            phi[i,j] <- prop # temporarily for calculations below
            for (k in seq(1,length(adjvect), by=2))
              {
                if (adjvect[k]==j) # if adjacency pair (j,?) is found
                  sum.adj.prop <- sum.adj.prop+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
                if (adjvect[k+1]==j) # if adjacency pair (?,j) is found
                  sum.adj.prop <- sum.adj.prop+(phi[i,adjvect[k]]-phi[i,adjvect[k+1]])^2
                cat("increment=",sum.adj.prop," ")
              }

#            sumadj.prop <- sum(phi[prev,]*(Q%*%phi[prev,]))
            cat("sum.adj.prop",sum.adj.prop," ")
            logalpha.num <- phi[i,j]*Y[j]-E[j]*exp(theta[i,j]+phi[i,j])-(tauc[i]*sum.adj.prop)/2

            logalpha <- logalpha.num - logalpha.den
            cat("logalpha.num",logalpha.num,phi[i,j],Y[j],E[j],phi[i,j]*Y[j],E[j]*exp(theta[i,j]+phi[i,j]),(tauc[i]*sum.adj.prop)/2,"\n")
            
            U <- runif(1)
            if (log(U)<logalpha) # if U<alpha, accept proposal (else stay with curr.value)
              phi[i,j] <- prop
            else
              phi[i,j] <- phi[prev,j] 
          }
      }

    thin.ind <- seq(1,NUMSAMP,by=thin) # index with samples thinned out
    return(list(NUMSAMP=NUMSAMP,samp=cbind(tauh[thin.ind],tauc[thin.ind],theta[thin.ind,],phi[thin.ind,])))
  }            
