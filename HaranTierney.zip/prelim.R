## work done to obtain necessary constants before
## running relevant programs
## for breastcancer data

blk <- blockMCMC(NUMSAMP=1000,proppars,coord=c(1,2,9,96,17,104,58,145),data,prior)
##exit without enough regenerations ( 0 vs 100 )
##max. log(prob.) of regeneration was  -2867.809
blk <- blockMCMC(10,proppars,data,prior,logC=-2867.809)
> blk$acc
[1] 0.3333333
> blk$avg
[1] 0.1689521

##system.time(blk <- blockMCMC(1000,proppars,data,prior,logC=-2867.809))
bmrs.indep <- comparebmrs.indep(NUMREPL=4,NUMREG=10,coord=6,logC=-2867.809,proppars,data,prior)
## independence chain
indep.bmrs.time <- system.time(indep.bmrs <-comparebmrs.indep(NUMREPL=50,NUMREG=100,coord=1,proppars,logC=-2867.809,data,prior))
dput(indep.bmrs.time,"indep.bmrs.time")


## estimate bounding constant for ratio log(P/R)
logK <- -2947.74 # -107.950

## simulated tempering chains
outp <- simtemp.reg(NUMREG=2,proppars,data,prior,temp.par,mixprob,coord=c(1,2,9,96,17,104,58,145),MAXSAMP=100,keepprob=TRUE)
> summary(outp$logprob01)
   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
  -2888   -2874   -2872   -2873   -2871   -2869
mixprob <- list(logpi0=log(1),logpi1=2872) # prob of being in H0 versus H1 in stationary distr.
outp <- simtemp.reg(NUMREG=2,MAXSAMP=100,coord=c(1,2,9,96,17,104,58,145),temp.par,mixprob,proppars,data,prior,keepprob=TRUE)

bmrs.sim.time <- system.time(bmrs.sim<-comparebmrs.sim(NUMREPL=5,NUMREG=3,MAXSAMP=1000,coord=c(1,2,9,96,17,104,58,145),temp.par,mixprob,proppars,data,prior))
dput(bmrs.sim.time,"bmrs.sim.time")

## independence chain
bmrs.indep.time <- system.time(bmrs.indep<-comparebmrs.indep(NUMREPL=5,NUMREG=5,MAXSAMP=1000,coord=c(1,2,9,96,17,104,58,145),proppars,logC=-2867.809,data,prior))
dput(bmrs.indep.time,"bmrs.indep.time")

#blk <- blockMCMC(100,proppars,data,prior,-108.5140)
