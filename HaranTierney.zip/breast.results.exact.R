if (!exists("exactdir"))
  exactdir <- "/home/mharan/exact/"
  ##exactdir <- "/home/u1/mharan/exact/" # location of directory with functions for exact sampling
# read in functions for multivariate-t generation and density
if (!exists("mcsedir"))
  mcsedir <- "/home/mharan/multreg/"
##  mcsedir <- "/home/u1/mharan/multreg/" # location of directory with functions for MC s.e.
source(paste(mcsedir,"mcse.R",sep=""))
 
breast.data <- readSimpleData(paste(exactdir,"breastcancer",sep=""))
breast.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
breast.proppars <- list(multtdf=50,muh=5.42,sigmah=0.6,muc=4.59,sigmac=0.7,tdfh=50,tdfc=50)
breast.logbound <- -2866.039 # -2868.301 -2869.809
breast.mixprob <- list(logpi0=log(1),logpi1=-breast.logbound)
NUMSAMP <- 1000

## run until 100 samples returned
rej.time <- system.time(rej <- rejsamp(NUMSAMP,breast.proppars,coord=c(1,2,9,96,17,104,58,145),breast.data,breast.prior,logbound=breast.logbound,changebound=FALSE,FIXEDNUM=TRUE))
dput(rej,"breast.rej")
dput(rej.time,"breast.rej.time")

breast.temp.par <- list(p=0.5,q=0.5,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"breast.perf1")
dput(perf.time,"breast.perf1.time")

breast.temp.par <- list(p=0.6,q=0.4,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"breast.perf2")
dput(perf.time,"breast.perf2.time")

breast.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"breast.perf3")
dput(perf.time,"breast.perf3.time")

breast.temp.par <- list(p=0.2,q=0.8,nstar=1)  # for simulated tempering/perfect sampling
perf.time <- system.time(perf <- perftemp(NUMSAMP,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob,FIXEDNUM=TRUE))
##[1] 136.43   1.53 142.71   0.00   0.00
dput(perf,"breast.perf5")
dput(perf.time,"breast.perf5.time")
#> perf$acc
#[1] 0.04659832

#breast.temp.par <- list(p=0.8,q=0.2,nstar=1)  # for simulated tempering/perfect sampling
#perf.time <- system.time(perf <- perftemp(NUMSAMP,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob,FIXEDNUM=TRUE))
###[1] 136.43   1.53 142.71   0.00   0.00
#dput(perf,"breast.perf4")
#dput(perf.time,"breast.perf4.time")

#breast.temp.par <- list(p=0.9,q=0.1,nstar=1)  # for simulated tempering/perfect sampling
#perf.time <- system.time(perf <- perftemp(NUMSAMP,breast.proppars,coord=c(1,2,9,87+9,17,87+17,58,87+58),breast.data,breast.prior,breast.temp.par,breast.mixprob,FIXEDNUM=TRUE))
#dput(perf,"breast.perf6")
#dput(perf.time,"breast.perf6.time")
