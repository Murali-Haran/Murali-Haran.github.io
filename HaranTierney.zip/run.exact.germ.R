if (!exists("exactdir"))
  exactdir <- "/home/u1/mharan/exact/" # location of directory with functions for exact sampling
# read in functions for multivariate-t generation and density
if (!exists("mcsedir"))
  mcsedir <- "/home/u1/mharan/multreg/" # location of directory with functions for MC s.e.
source(paste(mcsedir,"mcse.R",sep=""))
## set up work to run algorithms on Germany
## cancer data set (Knorr-Held and Rue)
germ.data <- readSimpleData(paste(exactdir,"germany",sep=""))
germ.prior <- list(alphah=1,betah=100,alphac=1, betac=100) ##JULY 15 CHANGED!!
germ.proppars <- list(multtdf=50,muh=5,sigmah=0.45,muc=2.9,sigmac=0.2,tdfh=50,tdfc=50)
germ.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
LOGBOUND <- -14583.24 # used to be -14589.59
germ.mixprob <- list(logpi0=log(1),logpi1=-LOGBOUND) # prob of being in H0 versus H1 in stationary distr.
rej.time <- system.time(rej <- rejsamp(100000,germ.proppars,coord=c(1,2,9,544+9,17,544+17,58,544+58),germ.data,germ.prior,logbound=LOGBOUND,changebound=FALSE))
dput(rej,"rej1.germ.short")
dput(rej.time,"rej1.germ.short.time")
# 147.7215 = 2 hrs27mins.
germ.temp.par <- list(p=0.4,q=0.3,nstar=1)  # for simulated tempering/perfect sampling
perf2.time <- system.time(perf2 <- perftemp(300000,germ.proppars,coord=c(1,2,9,544+9,17,544+17,58,544+58),germ.data,germ.prior,germ.temp.par,germ.mixprob))
dput(perf2,"perf2.germ.short")
dput(perf2.time,"perf2.germ.short.time")

germ.temp.par <- list(p=0.6,q=0.4,nstar=1)  # for simulated tempering/perfect sampling
perf3.time <- system.time(perf3 <- perftemp(300000,germ.proppars,coord=c(1,2,9,544+9,17,544+17,58,544+58),germ.data,germ.prior,germ.temp.par,germ.mixprob))
dput(perf3,"perf3.germ.short")
dput(perf3.time,"perf3.germ.short.time")

rej.time <- system.time(rej <- rejsamp(100000,germ.proppars,coord=c(1,2,9,544+9,17,544+17,58,544+58),germ.data,germ.prior,logbound=LOGBOUND,changebound=TRUE))
dput(rej,"rej2.germ.short")
dput(rej.time,"rej2.germ.short.time")
