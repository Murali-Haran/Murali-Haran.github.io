
##http://www.isds.duke.edu/courses/Spring02/sta376/eg/surv/mcmc2.s

#ratio-of-uniforms for sampling from exp(1):
#  R={(u,v): 0<=u<=1, 0<=v<=2}
#  C={(u,v): 0<=u<=sqrt(f(v/u))}
#  Sample from R, reject those not in C, return v/u.
sampexp<-function(){
  accept<-0
  while (accept==0){
    u<-runif(1)
    v<-runif(1)*(2/exp(1))
      if (u<=exp(-0.5*(v/u))) accept<-1
  }
  return(v/u)
}

plot.ru.exp<-function(){
  postscript("rat.of.unif.ps")
  par(mfrow=c(2,1))
  plot(c(0,1),c(0,2/exp(1)),xlab="U",ylab="V",type="n")
  u<-seq(0.001,1,length=999)
  lines(u,-2*u*log(u))
  title("Acceptance Region for Ratio-of-Uniforms Method:  Exp(1)",cex=0.9)
  text(0.5,0.25,"C (area=0.5)",cex=1.5)
  text(0.85,0.70,"R (area=0.7358)",cex=1.5)
  se<-numeric(5000)
  for (i in 1:5000) se[i]<-sampexp()
  hist(se,prob=T,xlab="theta")
  x<-seq(0,max(se),length=300)
  lines(x,exp(-x))
  title("Ratio-of-Uniforms Sample from Exp(1)")
  #Distribution of #of iterations to get 1 acceptance:
  # Min. 1st Qu. Median  Mean 3rd Qu. Max. 
  #    1       2      3 4.067       5   28
  dev.off()
  return()
}
#-------------------------------------------------------
ghat<-0.73521128
lhat<-sum(oc$dead)/sum((oc$survtime)^ghat)
#> lhat
#[1] 0.1135993

#conditional loglikelihood:
llg<-function(gam,lam,t=oc$survtime,d=oc$dead){
  sd<-sum(d)
  sdlt<-crossprod(d,log(t))
  stg<-as.vector(apply(outer(t,gam,FUN="^"),2,sum))
  return(713+sd*(log(gam)+log(lam)) + (gam-1)*sdlt - lam*stg)
}
#llg(ghat,lhat)=1.024675
#> exp(0.5*llg(ghat,lhat))
#         [,1] 
#[1,] 1.669188
#> pi.b(ghat)
#         [,1] 
#[1,] 1.669188


 #COMPONENTWISE CHAIN:  GIBBS W/ RATIO OF UNIFORMS FOR GAMMA:
mc4<-function(t0=c(ghat,lhat),bb,dd,numiter=100){
  samp<-matrix(0,ncol=3,nrow=numiter)
  gam<-t0[1]
  lam<-t0[2]
  for (i in 1:numiter){
    lam<-rgamma(1,shape=sum(oc$dead)+1)/sum(oc$survtime^gam)
    accept<-0
    numtry<-0
    while (accept==0){
      if (numtry==10000) stop("too many attempts!")
      u<-runif(1)*bb
      v<-runif(1)*dd
      numtry<-numtry+1
      if (log(u)<=0.5*llg(v/u,lam)) accept<-1
    }
    if (floor(i/100)==(i/100)) cat(i,"\n")
    gam<-v/u
    samp[i,]<-c(gam,lam,numtry)
  }
  return(list(samp=samp))
}

#COMPONENTWISE CHAINS; ARS for gamma component
chain31<-mc4(bb=b,dd=d,numiter=1000)
#> summary(chain31$samp[,3])
# Min. 1st Qu. Median  Mean 3rd Qu. Max. 
#p    1      10     23 63.63      50 7199

postscript("chains31.ps")
par(mfrow=c(3,1))
plot.chain(chain31,ttl="Componentwise, Ratio-of-Uniforms")
dev.off()

ll<-function(gamma,t=oc$survtime,d=oc$dead){
  sd<-sum(d)
  sdlt<-crossprod(d,log(t))
  stg<-sum(t^gamma)
  slttg<-crossprod(log(t),t^gamma)
  l<-sd/stg
  return(sd*(log(l)+log(gamma)-1) + (gamma-1)*sdlt )
}

pi.b<-function(gamma,t=oc$survtime,d=oc$dead){
  sd<-sum(d)
  sdlt<-crossprod(d,log(t))
  stg<-sum(t^gamma)
  l<-sd/stg
  ll<-(713+sd*log(l)+sd*log(gamma) + (gamma-1)*sdlt -l*stg)
  return(exp(0.5*ll))
}

pi.d<-function(gamma,t=oc$survtime,d=oc$dead){
  sd<-sum(d)
  sdlt<-crossprod(d,log(t))
  stg<-sum(t^gamma)
  l<-sd/stg
  ll<-(713+sd*log(l)+(sd+2)*log(gamma) + (gamma-1)*sdlt -l*stg)
  return(exp(0.5*ll))
}

#derivative of log-likelihood
dldg.d<-function(gamma,t=oc$survtime,d=oc$dead){
  sd<-sum(d)
  sdlt<-crossprod(d,log(t))
  stg<-sum(t^gamma)
  slttg<-crossprod(log(t),t^gamma)
  return(0.5*((2+sd)/gamma + sdlt - (sd/stg)*slttg))
}

#second derivative of log-likelihood:
d2ldg2.d<-function(gamma,t=oc$survtime,d=oc$dead){
  sd<-sum(d)
  sdlt<-crossprod(d,log(t))
  stg<-sum(t^gamma)
  slttg<-crossprod(log(t),t^gamma)
  sl2ttg<-crossprod(log(t)*log(t),t^gamma)
  return(0.5*(-(2+sd)/(gamma*gamma)  - (sd/stg)*sl2ttg))
}

nr<-function(g0){
  i<-1
  epsilon<-1
  ghat<-g0
  while((i<100)&&(epsilon>10e-6)){
    last<-ghat
    ghat<-ghat-dldg.d(ghat)/d2ldg2.d(ghat)
    cat(paste(i,round(ghat,8),"\n",sep="\t"))
    i<-i+1
    epsilon<-abs((ghat-last)/last)
  }
  lhat<-sum(oc$dead)/sum(oc$survtime^ghat)
  return(c(ghat,lhat))
}

g.d<-nr(ghat)
#> g.d
#[1] 0.7413267 0.1120721
#
#> d<-pi.d(g.d[1])
#         [,1] 
#[1,] 1.232318
#> ghat
#[1] 0.7352113
#> b<-pi.b(ghat)
#         [,1] 
#[1,] 1.669188
