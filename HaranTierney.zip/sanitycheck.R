## sanity check: make sure results roughly make sense!
## May 2007
## check results from output for breastcancer data set
exactdir=system("pwd",TRUE) # return path
source("newmodel2.functions.R")
#source("~/public_html/batchmeans.R")
breast.data <- readSimpleData(paste(exactdir,"/breastcancer",sep=""))
breast.prior <- list(alphah=1,betah=100,alphac=1, betac=50)
breast.proppars <- list(multtdf=50,muh=5.42,sigmah=0.6,muc=4.59,sigmac=0.7,tdfh=50,tdfc=50)
breast.logbound <- -2869.809
breast.mixprob <- list(logpi0=log(1),logpi1=-breast.logbound)
breast.temp.par <- list(p=0.3,q=0.3,nstar=1)  # for simulated tempering/perfect sampling

############################################################################################################
## run block MCMC (independence chain)
############################################################################################################
set.seed(1)
#mcmcout=blockMCMC(NUMSAMP=100000,proppars=breast.proppars,coord=c(1,2,9,96,17,104,58,145),data=breast.data,prior=breast.prior,outfile="mcmcsamp",writeevery=100)
mcmcout=blockMCMC(NUMSAMP=1000,proppars=breast.proppars,coord=NA,data=breast.data,prior=breast.prior,outfile="mcmcsamp",writeevery=1)
write(mcmcout$accrate,"mcmcacc")
mcmcsamp=read.table("mcmcsamp")

NUMSAMP=nrow(mcmcsamp)
NUMSITES=nrow(breast.data$data)
sampmu=matrix(NA,NUMSAMP,NUMSITES)
for (j in 1:NUMSITES)
  sampmu[,j]=mcmcsamp[,2+j]+mcmcsamp[,2+NUMSITES+j] # add 2 because first two columns are precision parameters
## posterior predictive for each Y
postpred=matrix(NA,NUMSAMP,NUMSITES)
for (i in 1:NUMSAMP)
  for (j in 1:NUMSITES)
  postpred[i,j]=rpois(1,breast.data$data$E[j]*exp(sampmu[i,j]))
           
ptestimate=apply(postpred,2,mean)
lowerCI = apply(postpred,2,function(x) return(quantile(x,probs=c(0.025))))
upperCI = apply(postpred,2,function(x) return(quantile(x,probs=c(0.975))))

plot(seq(1,NUMSITES),breast.data$data$Y,type="l",xlab="x",ylab="y",main="95% interval (green); mean (red); data (black)") # simple plot of realization
lines(seq(1,NUMSITES),ptestimate,col="red") # superimpose estimates/predictions
lines(seq(1,NUMSITES),lowerCI,col="green") # superimpose estimates/predictions
lines(seq(1,NUMSITES),upperCI,col="green") # superimpose estimates/predictions
