# functions for log-t distribution

# this modified function allows for 3 params to be specified for the
# t-distribution 
rt.mod <- function(n,meanlog=0,sdlog=1,t.df=5)
  {
    val <- rt(n, t.df)
    return(val*sdlog+meanlog)
  }

# this modified function allows for 3 params to be specified for the
# t-distribution
# it returns log(distrib.fn(x)) 
logdt.mod <- function(x,meanlog=0,sdlog=1,t.df=5)
  {
                                        #    val <- -x-(0.5*(t.df+1)*log(1 + ( ((x-meanlog)/sdlog)^2)/t.df) )
    val <- -0.5*(t.df+1)*log(1 + ( ((x-meanlog)/sdlog)^2)/t.df)
    return(val)
  }

dt.mod <- function(x,meanlog=0,sdlog=1,t.df=5)
  {
    exp(logdt.mod(x,meanlog,sdlog,t.df))
  }

# simple version (no check for numerical problems)
rlt <- function(n,meanlog=0,sdlog=1,t.df=5)
  return(exp(rt.mod(n,meanlog,sdlog,t.df)))

rlt <- function(n,meanlog=0,sdlog=1,t.df=5)
  {
    CEILING <- 10^8
    
    toobigORzero <- 1
    
    while (toobigORzero)
      {
        val <-exp(rt.mod(n,meanlog,sdlog,t.df))
        if ((val<CEILING) && (val>0))
          toobigORzero <- 0
        else
          cat("warning: discarded rlt value=",val,"\n")
      }  
    return(val)
  }    

# if we return consts + val, we return the true density
# if we return only val, we return the unnormalized density
logdlt <- function(x,meanlog=0,sdlog=1,t.df=5)
  {
    val <- -log(x)-(0.5*(t.df+1)*log(1 + ( ((log(x)-meanlog)/sdlog)^2)/t.df) )
    
#    consts <- log(gamma((t.df+1)/2))-log(sdlog)-0.5*log(t.df*pi)-log(gamma(t.df/2))
#    return(consts + val)
    return(val)
  }

## this version includes normalizing constants
logdlt.nor <- function(x,meanlog=0,sdlog=1,t.df=5)
  {
    val <- -log(x)-(0.5*(t.df+1)*log(1 + ( ((log(x)-meanlog)/sdlog)^2)/t.df) )
    
    consts <- log(gamma((t.df+1)/2))-log(sdlog)-0.5*log(t.df*pi)-log(gamma(t.df/2))
    return(consts + val)
  }

# if we return consts + val, we return the true density
# if we return only val, we return the unnormalized density
dlt <- function(x,meanlog=0,sdlog=1,t.df=5)
  {
    val <- -log(x)-(0.5*(t.df+1)*log(1 + ( ((log(x)-meanlog)/sdlog)^2)/t.df) )
    
#    consts <- log(gamma((t.df+1)/2))-log(sdlog)-0.5*log(t.df*pi)-log(gamma(t.df/2))
#    return(consts + val)
    return(exp(val))
  }

#dlt <- function(x,meanlog=0,sdlog=1,t.df=5)
#  {
#    val <- (1/x)*(1 + (1/t.df)*((log(x)-meanlog)/sdlog)^2)^(-(t.df+1)/2)
#    
#    return(val)
#  }

findmode.lt <- function(meanlog,sdlog)
  exp(meanlog-sdlog^2)

findsd.lt <- function(mode.lt,mn)
  sqrt(mn-log(mode.lt))

findmn.lt <- function(mode.lt,sdlog)
  log(mode.lt)+(sdlog*sdlog)

# density of envelope (log-t bivariate)
logbivdlt <- function(tau,mu1,sigma1,t1.df,mu2,sigma2,t2.df)
  {
    tauh <- tau[1]
    tauc <- tau[2]
    
    logdlt(tauh,mu1,sigma1,t1.df)+ logdlt(tauc,mu2,sigma2,t2.df)
  }

# density of envelope (t bivariate)
logbivdt <- function(tau,mu1,sigma1,t1.df,mu2,sigma2,t2.df)
  {
    tauh <- tau[1]
    tauc <- tau[2]
    
    logdt.mod(tauh,mu1,sigma1,t1.df)+ logdt.mod(tauc,mu2,sigma2,t2.df)
  }
